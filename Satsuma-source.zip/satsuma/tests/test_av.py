import unittest

import helpers
from helpers import HAVE_FFMPEG, TempDirCase, make_media
from satsuma.model import ConversionError, TargetUnreachable


@unittest.skipUnless(HAVE_FFMPEG, "FFmpeg not installed")
class AvTests(TempDirCase):
    @classmethod
    def setUpClass(cls):
        import tempfile
        from pathlib import Path
        cls.media_dir = Path(tempfile.mkdtemp(prefix="satsuma-media-"))
        cls.video, cls.audio = make_media(cls.media_dir)

    @classmethod
    def tearDownClass(cls):
        import shutil
        shutil.rmtree(cls.media_dir, ignore_errors=True)

    def conv(self, src, ext, **o):
        from satsuma.convert import av
        return av.convert(src, ext, self.ctx(**o))[0]

    def test_video_and_audio_conversions_are_playable(self):
        from satsuma.convert import av
        for ext in ("mkv", "webm", "mov"):
            with self.subTest(ext=ext):
                self.assertTrue(av.probe(self.conv(self.video, ext))["video"])
        for ext in ("mp3", "m4a", "flac", "ogg", "opus", "wav"):
            with self.subTest(ext=ext):
                self.assertTrue(av.probe(self.conv(self.audio, ext))["audio"])
        self.assertTrue(av.probe(self.conv(self.video, "mp3"))["audio"])      # extract audio from video

    def test_gif_from_video(self):
        out = self.conv(self.video, "gif", gif_fps=8, gif_width=160)
        self.assertGreater(out.stat().st_size, 1000)

    def test_video_size_target(self):
        out = self.conv(self.video, "mp4", target_size=120_000)
        self.assertLessEqual(out.stat().st_size, 120_000)

    def test_audio_size_target(self):
        for ext, limit in (("mp3", 60_000), ("opus", 40_000), ("m4a", 60_000)):
            with self.subTest(ext=ext):
                out = self.conv(self.audio, ext, target_size=limit)
                self.assertLessEqual(out.stat().st_size, limit)

    def test_unreachable_and_unsupported_targets(self):
        with self.assertRaises(TargetUnreachable):
            self.conv(self.video, "mp4", target_size=400)
        with self.assertRaises(ConversionError):
            self.conv(self.audio, "wav", target_size=10_000)

    def test_strip_metadata(self):
        from satsuma.convert import av
        ctx = self.ctx()
        out = av.strip_metadata(self.video, ctx)[0]
        tags = av.probe(out)["tags"]
        self.assertNotIn("title", tags)
        self.assertTrue(any("title" in n for n in ctx.report["metadata_removed"]))

    def test_audio_only_file_cannot_become_video(self):
        from satsuma.convert import av
        self.assertNotIn("mp4", [t.ext for t in av.targets(self.audio)])
        with self.assertRaises(ConversionError):
            self.conv(self.audio, "mp4")


if __name__ == "__main__":
    unittest.main()
