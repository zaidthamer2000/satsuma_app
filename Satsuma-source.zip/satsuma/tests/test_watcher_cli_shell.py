import io
import contextlib
import json
import unittest

import helpers
from helpers import TempDirCase, make_photo
from satsuma import cli, shell_integration
from satsuma.core import Step
from satsuma.watcher import FolderWatcher


class WatcherTests(TempDirCase):
    def test_new_files_are_processed_once_after_they_settle(self):
        watch = self.tmp / "inbox"
        watch.mkdir()
        make_photo(watch / "old.png", (40, 40))                         # existed before: ignored
        results = []
        w = FolderWatcher(watch, [Step("convert", "jpg")], on_result=lambda p, r: results.append((p.name, r.ok)),
                          settle=0.0)
        make_photo(watch / "new.png", (40, 40))
        (watch / "half.part").write_bytes(b"x")
        w.scan_once(now=0.0)                                            # first sight: remember the size
        self.assertEqual(results, [])
        w.scan_once(now=1.0)                                            # unchanged: process
        w.scan_once(now=2.0)                                            # never twice
        self.assertEqual(results, [("new.png", True)])
        self.assertEqual([p.name for p in (watch / "converted").iterdir()], ["new.jpg"])
        w.scan_once(now=3.0)                                            # its own output is not re-processed
        self.assertEqual(len(results), 1)

    def test_growing_file_waits(self):
        watch = self.tmp / "in2"
        watch.mkdir()
        w = FolderWatcher(watch, [Step("convert", "jpg")], settle=0.0)
        f = watch / "g.png"
        f.write_bytes(b"1")
        w.scan_once(now=0.0)
        f.write_bytes(b"12")                                            # size changed: still downloading
        self.assertEqual(w.scan_once(now=1.0), [])


class CliTests(TempDirCase):
    def run_cli(self, *args):
        out, err = io.StringIO(), io.StringIO()
        with contextlib.redirect_stdout(out), contextlib.redirect_stderr(err):
            code = cli.main(list(map(str, args)))
        return code, out.getvalue(), err.getvalue()

    def test_convert_compress_and_exit_codes(self):
        src = make_photo(self.tmp / "p.png", (300, 200))
        code, out, _ = self.run_cli("convert", src, "--to", "jpg", "--quality", "60", "--strip")
        self.assertEqual(code, 0)
        self.assertTrue((self.tmp / "p.jpg").exists())
        code, _, err = self.run_cli("convert", src, "--to", "xyz")
        self.assertEqual(code, 1)
        self.assertIn("FAIL", err)
        code, out, _ = self.run_cli("compress", src, "--size", "15KB", "--out", self.tmp / "o", "--json")
        self.assertEqual(code, 0)
        data = json.loads(out)
        self.assertTrue(data[0]["ok"])

    def test_listing_commands(self):
        code, out, _ = self.run_cli("presets")
        self.assertIn("upload_2mb", out)
        src = make_photo(self.tmp / "p.png", (60, 60))
        code, out, _ = self.run_cli("formats", src)
        self.assertIn("convert -> jpg", out)
        code, out, _ = self.run_cli("doctor", "--json")
        self.assertTrue(any(r["id"] == "ffmpeg" for r in json.loads(out)))

    def test_pdf_subcommand_and_preset(self):
        from helpers import make_image_pdf
        pdf = make_image_pdf(self.tmp / "d.pdf", pages=3)
        code, *_ = self.run_cli("pdf", "extract", pdf, "--pages", "2-3", "--suffix", "_x")
        self.assertEqual(code, 0)
        self.assertTrue((self.tmp / "d_x.pdf").exists())
        code, *_ = self.run_cli("preset", "upload_1mb", pdf, "--out", self.tmp / "po")
        self.assertEqual(code, 0)
        code, _, err = self.run_cli("preset", "nope", pdf)
        self.assertEqual(code, 1)

    def test_history_report_undo_commands(self):
        src = make_photo(self.tmp / "p.png", (60, 60))
        self.run_cli("convert", src, "--to", "bmp")
        code, out, _ = self.run_cli("history", "-n", "1")
        job_id = int(out.split()[0].lstrip("#"))
        code, out, _ = self.run_cli("report", job_id)
        self.assertIn("Network used: no", out)
        code, out, _ = self.run_cli("undo", job_id)
        self.assertIn("removed", out)
        self.assertFalse((self.tmp / "p.bmp").exists())


class FakeWinreg:
    HKEY_CURRENT_USER = "HKCU"
    REG_SZ = 1

    def __init__(self):
        self.keys = {}

    class _Key:
        def __init__(self, store, path):
            self.store, self.path = store, path

        def __enter__(self):
            return self

        def __exit__(self, *a):
            return False

    def CreateKey(self, root, path):
        self.keys.setdefault(path, {})
        return self._Key(self, path)

    def SetValueEx(self, key, name, _r, _t, value):
        self.keys[key.path][name] = value

    def DeleteKey(self, root, path):
        if path not in self.keys:
            raise FileNotFoundError(path)
        del self.keys[path]


class ShellTests(unittest.TestCase):
    def test_register_and_unregister_entries(self):
        reg = FakeWinreg()
        created = shell_integration.register(reg, command=r'"C:\Program Files\Satsuma\Satsuma.exe"')
        self.assertEqual(len(created), 3)
        cmd = reg.keys[shell_integration.KEY_OPEN + r"\command"][""]
        self.assertTrue(cmd.endswith('--gui "%1"'))
        self.assertIn("Satsuma.exe", reg.keys[shell_integration.KEY_OPEN]["Icon"])
        removed = shell_integration.unregister(reg)
        self.assertEqual(reg.keys, {})
        self.assertGreaterEqual(len(removed), 6)
        self.assertEqual(shell_integration.unregister(reg), [])          # idempotent


if __name__ == "__main__":
    unittest.main()
