import unittest

import helpers
from helpers import HAVE_REPORTLAB, TempDirCase, make_image_pdf, make_photo, make_text_pdf
from satsuma.convert import pdfs
from satsuma.model import ConversionError, TargetUnreachable


class PageSpecTests(unittest.TestCase):
    def test_specs(self):
        self.assertEqual(pdfs.parse_pages("1-3,5,8-", 10), [0, 1, 2, 4, 7, 8, 9])
        self.assertEqual(pdfs.parse_pages("3,1,2", 5), [2, 0, 1])
        self.assertEqual(pdfs.parse_pages("", 3), [0, 1, 2])
        self.assertEqual(pdfs.parse_pages("-2", 5), [0, 1])
        self.assertEqual(pdfs.parse_pages("4-2", 5), [3, 2, 1])

    def test_bad_specs(self):
        for bad in ("9", "0", "a-b", "1-99"):
            with self.subTest(spec=bad):
                with self.assertRaises(ConversionError):
                    pdfs.parse_pages(bad, 3)


class PdfToolTests(TempDirCase):
    def setUp(self):
        super().setUp()
        self.pdf = make_image_pdf(self.tmp / "scan.pdf", pages=3)

    def test_merge_split_extract(self):
        merged = pdfs.merge([self.pdf, self.pdf], self.ctx())[0]
        self.assertEqual(pdfs.page_count(merged), 6)
        parts = pdfs.split(self.pdf, self.ctx())
        self.assertEqual([p.name for p in parts], ["page_001.pdf", "page_002.pdf", "page_003.pdf"])
        picked = pdfs.extract_pages(self.pdf, self.ctx(page_spec="3,1"))[0]
        self.assertEqual(pdfs.page_count(picked), 2)

    def test_merge_needs_two_files(self):
        with self.assertRaises(ConversionError):
            pdfs.merge([self.pdf], self.ctx())

    def test_rotate_selected_pages_only(self):
        import pikepdf
        out = pdfs.rotate(self.pdf, self.ctx(angle=90, page_spec="2"))[0]
        with pikepdf.open(out) as pdf:
            self.assertEqual([int(p.obj.get("/Rotate", 0)) for p in pdf.pages], [0, 90, 0])

    def test_password_roundtrip(self):
        import pikepdf
        locked = self.tmp / "locked.pdf"
        with pikepdf.open(self.pdf) as pdf:
            pdf.save(locked, encryption=pikepdf.Encryption(user="s3cret", owner="owner"))
        with self.assertRaises(ConversionError):
            pdfs.split(locked, self.ctx())
        with self.assertRaises(ConversionError):
            pdfs.split(locked, self.ctx(password="wrong"))
        out = pdfs.unlock(locked, self.ctx(password="s3cret"))[0]
        self.assertEqual(pdfs.page_count(out), 3)       # opens without a password now

    def test_pdf_to_images(self):
        outs = pdfs.pdf_to_images(self.pdf, "jpg", self.ctx(render_dpi=50, page_spec="1-2"))
        self.assertEqual(len(outs), 2)
        from PIL import Image
        with Image.open(outs[0]) as im:
            self.assertEqual(im.format, "JPEG")

    def test_images_to_pdf(self):
        a = make_photo(self.tmp / "a.png", (300, 200))
        b = make_photo(self.tmp / "b.jpg", (200, 300), seed=2)
        out = pdfs.images_to_pdf([a, b], self.ctx())[0]
        self.assertEqual(pdfs.page_count(out), 2)

    def test_compress_reaches_target_or_says_why(self):
        big = make_image_pdf(self.tmp / "big.pdf", pages=4, size=(1200, 1600))
        original = big.stat().st_size
        target = max(20_000, original // 6)
        out = pdfs.compress(big, self.ctx(target_size=target))[0]
        self.assertLessEqual(out.stat().st_size, target)
        self.assertEqual(pdfs.page_count(out), 4)
        with self.assertRaises(TargetUnreachable):
            pdfs.compress(big, self.ctx(target_size=300))

    def test_scanned_pdf_has_no_text_layer(self):
        self.assertFalse(pdfs.has_text_layer(self.pdf))


@unittest.skipUnless(HAVE_REPORTLAB, "reportlab not installed")
class TextPdfTests(TempDirCase):
    def setUp(self):
        super().setUp()
        self.pdf = make_text_pdf(self.tmp / "text.pdf", pages=2)

    def test_text_extraction_and_layer_detection(self):
        self.assertTrue(pdfs.has_text_layer(self.pdf))
        texts = pdfs.extract_text(self.pdf)
        self.assertIn("quick brown fox", texts[0])
        self.assertIn("Chapter 2", texts[1])

    def test_txt_conversion(self):
        out = pdfs.convert(self.pdf, "txt", self.ctx())[0]
        self.assertIn("Chapter 1", out.read_text("utf-8-sig"))

    def test_word_conversion_builds_real_headings_and_text(self):
        from docx import Document
        out = pdfs.convert(self.pdf, "docx", self.ctx(pdf_word_mode="editable"))[0]
        doc = Document(out)
        heads = [p.text for p in doc.paragraphs if p.style.name.startswith("Heading")]
        self.assertIn("Chapter 1", heads)
        self.assertIn("quick brown fox", " ".join(p.text for p in doc.paragraphs))

    def test_arabic_paragraphs_are_marked_right_to_left(self):
        from docx import Document
        doc = Document()
        pdfs.add_text_paragraph(doc, "مرحبا بالعالم، هذا اختبار للنص العربي")
        pdfs.add_text_paragraph(doc, "Plain English paragraph")
        arabic, english = doc.paragraphs
        self.assertIsNotNone(arabic._p.pPr.find("{http://schemas.openxmlformats.org/wordprocessingml/2006/main}bidi"))
        self.assertIsNone(english._p.pPr.find("{http://schemas.openxmlformats.org/wordprocessingml/2006/main}bidi")
                          if english._p.pPr is not None else None)
        out = self.tmp / "ar.docx"
        doc.save(out)
        Document(out)                                    # re-opens: the XML is well-formed

    def test_rtl_detection(self):
        self.assertGreater(pdfs.rtl_ratio("مرحبا"), 0.9)
        self.assertEqual(pdfs.rtl_ratio("hello"), 0.0)
        self.assertEqual(pdfs.rtl_ratio("1234"), 0.0)


if __name__ == "__main__":
    unittest.main()
