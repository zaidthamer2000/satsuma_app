import tarfile
import unittest
import zipfile

import helpers
from helpers import TempDirCase, make_photo
from satsuma.convert import archives, fonts, metadata
from satsuma.model import ConversionError


class ArchiveTests(TempDirCase):
    def test_pack_and_extract_roundtrip_with_unicode(self):
        d = self.tmp / "folder"
        (d / "sub").mkdir(parents=True)
        (d / "a.txt").write_text("hi")
        (d / "sub" / "ب.txt").write_text("مرحبا", encoding="utf-8")
        for fmt in ("zip", "tar.gz"):
            with self.subTest(fmt=fmt):
                packed = archives.pack([d], fmt, self.ctx())[0]
                folder = archives.extract(packed, self.ctx())[0]
                names = sorted(p.relative_to(folder).as_posix() for p in folder.rglob("*") if p.is_file())
                self.assertEqual(names, ["folder/a.txt", "folder/sub/ب.txt"])

    def test_zip_slip_is_blocked(self):
        evil = self.tmp / "evil.zip"
        with zipfile.ZipFile(evil, "w") as z:
            z.writestr("../../escaped.txt", "x")
        with self.assertRaises(ConversionError):
            archives.extract(evil, self.ctx())
        self.assertFalse((self.tmp.parent / "escaped.txt").exists())

    def test_tar_traversal_is_blocked(self):
        evil = self.tmp / "evil.tar"
        payload = self.tmp / "p.txt"
        payload.write_text("x")
        with tarfile.open(evil, "w") as t:
            t.add(payload, arcname="../../escaped.txt")
        with self.assertRaises(ConversionError):
            archives.extract(evil, self.ctx())

    def test_damaged_zip_message(self):
        bad = self.tmp / "bad.zip"
        bad.write_bytes(b"PK\x03\x04garbage")
        with self.assertRaises(ConversionError):
            archives.extract(bad, self.ctx())

    def test_empty_pack_rejected(self):
        with self.assertRaises(ConversionError):
            archives.pack([], "zip", self.ctx())


class FontTests(TempDirCase):
    def find_font(self):
        from pathlib import Path
        for p in ("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", "C:/Windows/Fonts/arial.ttf",
                  "/System/Library/Fonts/Supplemental/Arial.ttf"):
            if Path(p).exists():
                return Path(p)
        self.skipTest("no TrueType font found")

    def test_ttf_to_woff_and_back(self):
        woff = fonts.convert(self.find_font(), "woff", self.ctx())[0]
        ttf = fonts.convert(woff, "ttf", self.ctx())[0]
        from fontTools.ttLib import TTFont
        self.assertIsNone(TTFont(str(ttf)).flavor)
        self.assertEqual(TTFont(str(woff)).flavor, "woff")


class MetadataTests(TempDirCase):
    def test_jpeg_gps_and_camera_removed_and_reported(self):
        from PIL import Image
        im = Image.new("RGB", (200, 150), (200, 100, 50))
        ex = Image.Exif()
        ex[271], ex[272], ex[305] = "Canon", "EOS", "Photoshop"
        gps = ex.get_ifd(0x8825)
        gps[1], gps[2] = "N", (35.0, 0.0, 0.0)
        src = self.tmp / "p.jpg"
        im.save(src, exif=ex)
        ctx = self.ctx()
        out = metadata.strip(src, ctx)[0]
        found = ctx.report["metadata_removed"]
        self.assertIn("GPS location", found)
        self.assertIn("camera make", found)
        with Image.open(out) as result:
            self.assertEqual([n for n in metadata.inspect_image(result) if "colour" not in n], [])
            self.assertEqual(result.size, (200, 150))

    def test_pdf_info_and_xmp_removed(self):
        import pikepdf
        from helpers import make_image_pdf
        from satsuma.convert import pdfs
        pdf_path = make_image_pdf(self.tmp / "m.pdf", pages=1)
        with pikepdf.open(pdf_path, allow_overwriting_input=True) as pdf:
            pdf.docinfo["/Author"] = "Ali"
            with pdf.open_metadata() as meta:
                meta["dc:creator"] = ["Ali"]
            pdf.save(pdf_path)
        out = metadata.strip(pdf_path, self.ctx())[0]
        with pikepdf.open(out) as pdf:
            self.assertEqual(dict(pdf.docinfo), {})
            self.assertNotIn("/Metadata", pdf.Root)

    def test_docx_author_removed_content_kept(self):
        from docx import Document
        d = Document()
        d.core_properties.author = "Ali"
        d.core_properties.title = "Secret plan"
        d.add_paragraph("body text")
        src = self.tmp / "m.docx"
        d.save(src)
        out = metadata.strip(src, self.ctx())[0]
        d2 = Document(out)
        self.assertEqual(d2.core_properties.author, "")
        self.assertEqual(d2.paragraphs[0].text, "body text")

    def test_unsupported_type_is_a_clear_error(self):
        txt = self.tmp / "a.txt"
        txt.write_text("x")
        self.assertFalse(metadata.supported(txt))
        with self.assertRaises(ConversionError):
            metadata.strip(txt, self.ctx())


class TranscriptFormatTests(unittest.TestCase):
    def test_srt_vtt_txt(self):
        from satsuma.convert import ai
        segs = [(0, 2.5, " مرحبا "), (2.5, 61.2005, "Hello"), (3700, 3701, "  ")]
        srt = ai.format_segments(segs, "srt")
        self.assertIn("00:00:02,500 --> 00:01:01,200", srt)
        self.assertNotIn("01:01:40", srt)                      # empty segment dropped
        self.assertTrue(ai.format_segments(segs, "vtt").startswith("WEBVTT"))
        self.assertEqual(ai.format_segments(segs, "txt"), "مرحبا\nHello\n")


if __name__ == "__main__":
    unittest.main()
