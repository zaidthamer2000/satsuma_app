import os
import shutil
import stat
import sys
import threading
import unittest

import helpers
from helpers import HAVE_REPORTLAB, TempDirCase, make_image_pdf, make_photo
from satsuma import core, history, presets
from satsuma.core import Step
from satsuma.model import Options


class CoreTests(TempDirCase):
    def setUp(self):
        super().setUp()
        self.photo = make_photo(self.tmp / "صورة 1.png", (400, 300))     # Arabic + space in the name

    def test_convert_names_never_overwrite_and_originals_stay(self):
        before = self.photo.read_bytes()
        r1 = core.run_job([self.photo], [Step("convert", "jpg")])
        r2 = core.run_job([self.photo], [Step("convert", "jpg")])
        self.assertTrue(r1.ok and r2.ok, (r1.error, r2.error))
        self.assertEqual([p.name for p in r1.outputs], ["صورة 1.jpg"])
        self.assertEqual([p.name for p in r2.outputs], ["صورة 1 (1).jpg"])
        self.assertEqual(self.photo.read_bytes(), before)

    def test_same_format_is_refused_with_hint(self):
        r = core.run_job([self.photo], [Step("convert", "png")])
        self.assertFalse(r.ok)
        self.assertIn("compress", r.error)

    def test_missing_source_and_unknown_action(self):
        self.assertIn("not found", core.run_job([self.tmp / "nope.png"], [Step("convert", "jpg")]).error)
        self.assertFalse(core.run_job([self.photo], [Step("explode")]).ok)
        self.assertFalse(core.run_job([], [Step("convert", "jpg")]).ok)

    def test_output_folder_and_suffix(self):
        out = self.tmp / "out"
        r = core.run_job([self.photo], [Step("compress")], Options(target_size=20_000, out_dir=out))
        self.assertTrue(r.ok)
        self.assertEqual(r.outputs[0].parent, out)
        self.assertTrue(r.outputs[0].name.endswith("_compressed.png"))
        r = core.run_job([self.photo], [Step("convert", "webp")], Options(suffix="_web", out_dir=out))
        self.assertEqual(r.outputs[0].name, "صورة 1_web.webp")

    def test_chain_runs_all_steps_and_keeps_only_the_final_result(self):
        steps = [Step("convert", "jpg"), Step("strip_metadata")]
        r = core.run_job([self.photo], steps, Options(out_dir=self.tmp / "chain"))
        self.assertTrue(r.ok, r.error)
        self.assertEqual(len(r.outputs), 1)
        self.assertEqual(len(list((self.tmp / "chain").iterdir())), 1)

    def test_every_preset_for_images_works(self):
        for p in presets.for_paths([self.photo]):
            with self.subTest(preset=p.id):
                if p.id in ("scan_searchable",) and not helpers.HAVE_TESSERACT:
                    continue
                if p.id == "scan_searchable" and "ara" not in __import__("satsuma.convert.ocr", fromlist=["x"]).installed_languages():
                    continue
                r = core.run_job([self.photo], p.steps, p.apply(Options(out_dir=self.tmp / p.id)), log=False)
                self.assertTrue(r.ok, r.error)

    def test_batch_isolates_failures(self):
        bad = self.tmp / "broken.png"
        bad.write_bytes(b"nope")
        good = make_photo(self.tmp / "good.png", (100, 100))
        results = core.run_batch([bad, good], [Step("convert", "jpg")])
        self.assertEqual([r.ok for r in results], [False, True])

    def test_cancel_leaves_nothing_behind(self):
        pdf = make_image_pdf(self.tmp / "d.pdf", pages=1)
        cancel = threading.Event()
        r = core.run_job([pdf, pdf, pdf], [Step("pdf_merge")], Options(out_dir=self.tmp / "cx"),
                         cancel=cancel, progress=lambda f, m: cancel.set())
        self.assertTrue(r.cancelled)
        self.assertEqual(list((self.tmp / "cx").glob("*")) if (self.tmp / "cx").exists() else [], [])
        leftovers = [d for d in os.listdir(os.path.dirname(str(helpers._HOME))) if d.startswith("satsuma-") and "test" not in d]
        self.assertEqual(leftovers, [])

    def test_failed_job_leaves_no_partial_output(self):
        r = core.run_job([self.photo], [Step("compress")], Options(target_size=30, out_dir=self.tmp / "fx"))
        self.assertFalse(r.ok)
        self.assertEqual(list((self.tmp / "fx").glob("*")) if (self.tmp / "fx").exists() else [], [])

    @unittest.skipIf(sys.platform == "win32" or (hasattr(os, "geteuid") and os.geteuid() == 0),
                     "needs a non-root POSIX user")
    def test_read_only_folder_falls_back_to_documents(self):
        ro = self.tmp / "ro"
        ro.mkdir()
        src = make_photo(ro / "p.png", (50, 50))
        os.chmod(ro, stat.S_IREAD | stat.S_IEXEC)
        try:
            r = core.run_job([src], [Step("convert", "jpg")])
            self.assertTrue(r.ok, r.error)
            self.assertNotEqual(r.outputs[0].parent, ro)
            self.assertTrue(any("not writable" in w for w in r.warnings))
        finally:
            os.chmod(ro, stat.S_IRWXU)

    def test_offers_for_mixed_and_multiple_files(self):
        pdf = make_image_pdf(self.tmp / "d.pdf", pages=1)
        mixed = {(o.action, o.target) for o in core.offers([self.photo, pdf])}
        self.assertIn(("compress", None), mixed)
        self.assertNotIn(("convert", "docx"), mixed)
        self.assertIn(("pdf_merge", None), {(o.action, o.target) for o in core.offers([pdf, pdf])})
        self.assertIn(("images_to_pdf", None), {(o.action, o.target) for o in core.offers([self.photo])})
        self.assertEqual(core.offers([]), [])

    def test_offers_do_not_leak_between_kinds(self):
        pdf_targets = {o.target for o in core.offers([self.photo]) if o.action == "convert"}
        self.assertNotIn("docx", pdf_targets)
        self.assertNotIn("tar.gz", pdf_targets)


class HistoryTests(TempDirCase):
    def test_record_report_and_undo(self):
        src = make_photo(self.tmp / "a.png", (80, 80))
        r = core.run_job([src], [Step("convert", "jpg")])
        self.assertIsNotNone(r.job_id)
        job = history.get(r.job_id)
        self.assertTrue(job["report"]["processed_locally"])
        self.assertFalse(job["report"]["network_used"])
        self.assertIn("Network used: no", history.format_report(job["report"]))
        out = r.outputs[0]
        res = history.undo(r.job_id)
        self.assertEqual(len(res["removed"]), 1)
        self.assertFalse(out.exists())
        self.assertTrue(src.exists())

    def test_undo_keeps_files_changed_afterwards(self):
        src = make_photo(self.tmp / "a.png", (80, 80))
        r = core.run_job([src], [Step("convert", "jpg")])
        with open(r.outputs[0], "ab") as f:
            f.write(b"edited by the user")
        res = history.undo(r.job_id)
        self.assertEqual(res["removed"], [])
        self.assertTrue(r.outputs[0].exists())
        self.assertIn("modified", res["skipped"][0][1])

    def test_user_presets_roundtrip(self):
        mine = presets.Preset("mine", "Mine", "لي", [Step("convert", "webp")], {"quality": 50}, ("image",), builtin=False)
        presets.save_user([mine])
        self.assertEqual(presets.find("mine").options["quality"], 50)
        presets.save_user([])
        with self.assertRaises(KeyError):
            presets.find("mine")


if __name__ == "__main__":
    unittest.main()
