"""Satsuma's promise: files never leave the computer. These tests enforce it."""
import re
import socket
import unittest
from pathlib import Path

import helpers
from helpers import TempDirCase, make_photo, make_image_pdf

PKG = Path(helpers.__file__).resolve().parent.parent / "satsuma"
NETWORK_WORDS = re.compile(r"^\s*(import|from)\s+(urllib\.request|urllib3|http\.client|socket|requests|httpx|aiohttp|ftplib|smtplib|ssl|websocket)\b", re.M)


class PrivacyTests(TempDirCase):
    def test_only_net_module_may_import_networking(self):
        offenders = []
        for f in PKG.rglob("*.py"):
            if f.name == "net.py":
                continue
            if NETWORK_WORDS.search(f.read_text(encoding="utf-8")):
                offenders.append(str(f.relative_to(PKG)))
        self.assertEqual(offenders, [], "only satsuma/net.py may use the network")

    def test_net_module_is_used_only_for_language_downloads(self):
        users = [f.name for f in PKG.rglob("*.py") if f.name != "net.py" and re.search(r"\bnet\b\.", f.read_text("utf-8"))]
        self.assertEqual(users, ["ocr.py"])

    def test_conversions_open_no_sockets(self):
        from satsuma import core
        from satsuma.core import Step
        from satsuma.model import Options
        real_connect, real_create = socket.socket.connect, socket.create_connection

        def forbid(*a, **k):
            raise AssertionError("network access attempted during a conversion")

        socket.socket.connect = forbid
        socket.create_connection = forbid
        try:
            photo = make_photo(self.tmp / "a.png", (80, 80))
            pdf = make_image_pdf(self.tmp / "d.pdf", pages=1)
            for src, steps in ((photo, [Step("convert", "webp")]), (photo, [Step("strip_metadata")]),
                               (pdf, [Step("compress")]), (pdf, [Step("convert", "png")])):
                r = core.run_job([src], steps, Options(out_dir=self.tmp / "o"), log=False)
                self.assertTrue(r.ok, r.error)
        finally:
            socket.socket.connect, socket.create_connection = real_connect, real_create


if __name__ == "__main__":
    unittest.main()
