"""A tiny stand-in for PySide6 so the window's Python logic can be tested without Qt installed.

It models the few widget behaviours the window relies on (values, combo boxes, tables, signals,
synchronous threads). It cannot judge how the window LOOKS - the Windows CI job runs the real thing.
"""
import inspect
import sys
import types


def _fit_args(fn, args):
    """Like Qt: a slot may take fewer arguments than the signal provides."""
    try:
        params = inspect.signature(fn).parameters.values()
    except (TypeError, ValueError):
        return args
    if any(p.kind == p.VAR_POSITIONAL for p in params):
        return args
    n = sum(1 for p in params if p.kind in (p.POSITIONAL_ONLY, p.POSITIONAL_OR_KEYWORD))
    return args[:n]


class _SigObj:
    def __init__(self):
        self.slots = []

    def connect(self, fn):
        self.slots.append(fn)

    def emit(self, *a):
        for fn in list(self.slots):
            fn(*_fit_args(fn, a))


class _SigDesc:
    def __set_name__(self, owner, name):
        self.name = "_sig_" + name

    def __get__(self, obj, owner=None):
        return self if obj is None else obj.__dict__.setdefault(self.name, _SigObj())


def Signal(*types):
    return _SigDesc()


class _ConstMeta(type):
    def __getattr__(cls, name):
        if name.startswith("__"):
            raise AttributeError(name)
        return name


class _Consts(metaclass=_ConstMeta):
    pass


class QObject:
    def __init__(self, parent=None):
        pass

    def __getattr__(self, name):
        if name.startswith("_"):                 # private state must be set explicitly, never faked
            raise AttributeError(name)
        return lambda *a, **k: None


class QRunnable:
    def __init__(self):
        pass


class QThread(QObject):
    def start(self):
        self.run()

    def wait(self, *a):
        return True


class QThreadPool:
    @staticmethod
    def globalInstance():
        return QThreadPool()

    def start(self, runnable):
        runnable.run()


class QTimer(QObject):
    timeout = Signal()

    def start(self, ms=0):
        self.started_with = ms


class QUrl:
    @staticmethod
    def fromLocalFile(p):
        return p


class QSettings:
    store = {}

    def __init__(self, *a):
        pass

    def value(self, key, default=None):
        return QSettings.store.get(key, default)

    def setValue(self, key, value):
        QSettings.store[key] = value


class _W(QObject):
    def __init__(self, *a, **k):
        super().__init__()
        self._enabled = True
        self._blocked = False
        self._text = a[0] if a and isinstance(a[0], str) else ""

    def setEnabled(self, v):
        self._enabled = bool(v)

    def isEnabled(self):
        return self._enabled

    def setText(self, t):
        self._text = t

    def text(self):
        return self._text

    def blockSignals(self, flag):
        self._blocked = flag

    def _emit(self, sig, *a):
        if not self._blocked:
            sig.emit(*a)

    def show(self):
        pass


class QLabel(_W):
    pass


class QPushButton(_W):
    clicked = Signal()


class QCheckBox(_W):
    toggled = Signal()

    def __init__(self, *a):
        super().__init__(*a)
        self._checked = False

    def setChecked(self, v):
        v = bool(v)
        if self._checked != v:
            self._checked = v
            self._emit(self.toggled, v)

    def isChecked(self):
        return self._checked


class _Num(_W):
    valueChanged = Signal()

    def __init__(self, *a, **k):
        super().__init__()
        self._v, self._min, self._max = 0, 0, 100

    def setRange(self, a, b):
        self._min, self._max = a, b

    def setValue(self, v):
        v = max(self._min, min(self._max, v))
        if v != self._v:
            self._v = v
            self._emit(self.valueChanged, v)

    def value(self):
        return self._v


class QSlider(_Num):
    pass


class QSpinBox(_Num):
    pass


class QDoubleSpinBox(_Num):
    pass


class QLineEdit(_W, metaclass=_ConstMeta):
    pass


class _Item:
    def __init__(self):
        self.enabled = True

    def setEnabled(self, v):
        self.enabled = v


class _Model:
    def __init__(self, combo):
        self.combo = combo

    def item(self, i):
        return self.combo._items[i][2]


class QComboBox(_W):
    currentIndexChanged = Signal()

    def __init__(self, *a):
        super().__init__()
        self._items, self._i, self._edit = [], -1, ""

    def addItem(self, text, data=None):
        self._items.append((text, data, _Item()))
        if self._i < 0:
            self._i = 0
            self._emit(self.currentIndexChanged, 0)

    def addItems(self, texts):
        for t in texts:
            self.addItem(t)

    def clear(self):
        self._items, self._i = [], -1

    def count(self):
        return len(self._items)

    def currentIndex(self):
        return self._i

    def setCurrentIndex(self, i):
        if i != self._i and 0 <= i < len(self._items):
            self._i = i
            self._emit(self.currentIndexChanged, i)

    def currentData(self):
        return self._items[self._i][1] if 0 <= self._i < len(self._items) else None

    def currentText(self):
        return self._edit or (self._items[self._i][0] if 0 <= self._i < len(self._items) else "")

    def setCurrentText(self, t):
        self._edit = t

    def model(self):
        return _Model(self)

    def itemText(self, i):
        return self._items[i][0]


class _LItem:
    def __init__(self, text):
        self.t = text


class QListWidget(_W, metaclass=_ConstMeta):
    def __init__(self, *a):
        super().__init__()
        self._rows, self._sel = [], []

    def addItem(self, t):
        self._rows.append(_LItem(t))

    def takeItem(self, r):
        return self._rows.pop(r)

    def row(self, item):
        return self._rows.index(item)

    def selectedItems(self):
        return list(self._sel)

    def clear(self):
        self._rows = []

    def count(self):
        return len(self._rows)


class QTableWidgetItem:
    def __init__(self, text=""):
        self._t = text

    def text(self):
        return self._t

    def setToolTip(self, t):
        self.tip = t


class _Row:
    def __init__(self, r):
        self._r = r

    def row(self):
        return self._r


class _SelModel:
    def __init__(self, t):
        self.t = t

    def selectedRows(self):
        return [_Row(r) for r in self.t.selected]


class QTableWidget(_W):
    def __init__(self, rows=0, cols=0):
        super().__init__()
        self._rows, self.cells, self.selected = rows, {}, []

    def setRowCount(self, n):
        self._rows = n
        self.cells = {k: v for k, v in self.cells.items() if k[0] < n}

    def rowCount(self):
        return self._rows

    def insertRow(self, r):
        self._rows += 1

    def setItem(self, r, c, item):
        self.cells[(r, c)] = item

    def item(self, r, c):
        return self.cells.get((r, c))

    def selectionModel(self):
        return _SelModel(self)

    def horizontalHeader(self):
        return QObject()


class QProgressBar(_W):
    _val = 0

    def setValue(self, v):
        self._val = v

    def value(self):
        return self._val


class QTabWidget(_W):
    currentChanged = Signal()

    def addTab(self, w, t):
        pass

    def setTabText(self, i, t):
        pass


class QMessageBox(metaclass=_ConstMeta):
    asked = []
    answer = "No"

    @staticmethod
    def question(*a, **k):
        QMessageBox.asked.append(a)
        return QMessageBox.answer

    @staticmethod
    def information(*a, **k):
        return None

    @staticmethod
    def warning(*a, **k):
        return None


class QFileDialog:
    @staticmethod
    def getOpenFileNames(*a, **k):
        return [], ""

    @staticmethod
    def getExistingDirectory(*a, **k):
        return ""


class QApplication(_W):
    _inst = None

    def __init__(self, *a):
        super().__init__()
        QApplication._inst = self

    @staticmethod
    def instance():
        return QApplication._inst or QApplication([])


class QLocalSocket(_W):
    def waitForConnected(self, ms):
        return False


class QLocalServer(_W):
    @staticmethod
    def removeServer(n):
        return True


class QDesktopServices:
    @staticmethod
    def openUrl(u):
        return True


def install():
    """Put the stub modules into sys.modules; returns a function that undoes it."""
    QSettings.store.clear()
    QMessageBox.asked.clear()
    QMessageBox.answer = "No"
    saved = {k: sys.modules.get(k) for k in ("PySide6", "PySide6.QtCore", "PySide6.QtGui", "PySide6.QtNetwork",
                                              "PySide6.QtWidgets", "satsuma.gui.app")}
    core = types.ModuleType("PySide6.QtCore")
    for n in ("QObject", "QRunnable", "QSettings", "QThread", "QThreadPool", "QTimer", "QUrl", "Signal"):
        setattr(core, n, globals()[n])
    core.Qt = _Consts
    gui = types.ModuleType("PySide6.QtGui")
    gui.QDesktopServices = QDesktopServices
    net = types.ModuleType("PySide6.QtNetwork")
    net.QLocalServer, net.QLocalSocket = QLocalServer, QLocalSocket
    wid = types.ModuleType("PySide6.QtWidgets")
    for n in ("QAbstractItemView", "QHeaderView"):
        setattr(wid, n, type(n, (_Consts,), {}))
    for n in ("QApplication", "QCheckBox", "QComboBox", "QDoubleSpinBox", "QFileDialog", "QGroupBox", "QLabel",
              "QLineEdit", "QListWidget", "QMessageBox", "QProgressBar", "QPushButton", "QSlider", "QSpinBox",
              "QTableWidget", "QTableWidgetItem", "QTabWidget"):
        setattr(wid, n, globals().get(n) or type(n, (_W,), {}))
    for n in ("QFormLayout", "QHBoxLayout", "QVBoxLayout", "QMainWindow", "QWidget", "QGroupBox"):
        setattr(wid, n, type(n, (_W,), {}))
    pkg = types.ModuleType("PySide6")
    mods = {"PySide6": pkg, "PySide6.QtCore": core, "PySide6.QtGui": gui, "PySide6.QtNetwork": net,
            "PySide6.QtWidgets": wid}
    sys.modules.update(mods)
    sys.modules.pop("satsuma.gui.app", None)

    def undo():
        for k, v in saved.items():
            if v is None:
                sys.modules.pop(k, None)
            else:
                sys.modules[k] = v
    return undo
