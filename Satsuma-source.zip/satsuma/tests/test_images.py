import io
import unittest

import helpers
from helpers import TempDirCase, make_photo
from PIL import Image
from satsuma.convert import images
from satsuma.model import ConversionError, TargetUnreachable


class ImageTests(TempDirCase):
    def setUp(self):
        super().setUp()
        self.photo = make_photo(self.tmp / "photo.png", (500, 400))

    def convert(self, src, fmt, **opts):
        ctx = self.ctx(**opts)
        out = images.convert(src, fmt, ctx)[0]
        return out, ctx

    def test_every_output_format_is_readable(self):
        for fmt in images.output_formats():
            if fmt == "png":
                continue
            with self.subTest(fmt=fmt):
                out, _ = self.convert(self.photo, fmt)
                self.assertGreater(out.stat().st_size, 100)
                if fmt != "pdf":
                    with Image.open(out) as im:
                        im.load()

    def test_transparency_is_flattened_onto_white_for_jpeg(self):
        src = make_photo(self.tmp / "a.png", (64, 64), alpha=True)
        out, _ = self.convert(src, "jpg")
        with Image.open(out) as im:
            self.assertEqual(im.mode, "RGB")
            self.assertGreater(sum(im.getpixel((1, 1))), 700)     # transparent corner became white

    def test_png_keeps_transparency_in_webp(self):
        src = make_photo(self.tmp / "a.png", (64, 64), alpha=True)
        out, _ = self.convert(src, "webp")
        with Image.open(out) as im:
            self.assertIn("A", im.mode)

    def test_target_size_is_respected_for_each_lossy_format(self):
        for fmt in ("jpg", "webp", "png"):
            with self.subTest(fmt=fmt):
                out, ctx = self.convert(self.photo, fmt, target_size=30_000)
                self.assertLessEqual(out.stat().st_size, 30_000)

    def test_impossible_target_is_reported_not_faked(self):
        with self.assertRaises(TargetUnreachable):
            self.convert(self.photo, "jpg", target_size=40)

    def test_size_limit_on_unsupported_format_is_a_clear_error(self):
        with self.assertRaises(ConversionError):
            self.convert(self.photo, "bmp", target_size=10_000)

    def test_max_side_resizes_keeping_ratio(self):
        out, _ = self.convert(self.photo, "jpg", max_side=250)
        with Image.open(out) as im:
            self.assertEqual(max(im.size), 250)
            self.assertAlmostEqual(im.width / im.height, 500 / 400, places=1)

    def test_exif_orientation_is_applied_and_metadata_stripped(self):
        im = Image.new("RGB", (100, 40), (10, 200, 30))
        exif = Image.Exif()
        exif[274] = 6                       # rotated 90 degrees
        exif[271] = "SecretCam"
        src = self.tmp / "rot.jpg"
        im.save(src, exif=exif)
        out, _ = self.convert(src, "png", strip_metadata=True)
        with Image.open(out) as r:
            self.assertEqual(r.size, (40, 100))
            self.assertNotIn(271, r.getexif())

    def test_animated_gif_becomes_animated_webp(self):
        frames = [Image.new("RGB", (32, 32), c) for c in ((255, 0, 0), (0, 255, 0), (0, 0, 255))]
        src = self.tmp / "a.gif"
        frames[0].save(src, save_all=True, append_images=frames[1:], duration=80, loop=0)
        out, _ = self.convert(src, "webp")
        with Image.open(out) as im:
            self.assertEqual(getattr(im, "n_frames", 1), 3)

    def test_ico_from_non_square_picture(self):
        out, _ = self.convert(self.photo, "ico")
        with Image.open(out) as im:
            self.assertEqual(im.size[0], im.size[1])

    def test_corrupt_file_gives_friendly_error(self):
        bad = self.tmp / "bad.jpg"
        bad.write_bytes(b"not an image")
        with self.assertRaises(ConversionError):
            self.convert(bad, "png")

    def test_estimate_matches_real_size(self):
        from satsuma.model import Options
        o = Options(quality=60)
        est = images.estimate_size(self.photo, "jpg", o)
        out, _ = self.convert(self.photo, "jpg", quality=60)
        self.assertEqual(est, out.stat().st_size)

    def test_compress_picks_a_sensible_format(self):
        bmp, _ = self.convert(self.photo, "bmp")
        ctx = self.ctx()
        out = images.compress(bmp, ctx)[0]
        self.assertEqual(out.suffix, ".jpg")

    def test_upscale_and_basic_background_removal(self):
        ctx = self.ctx(scale=2)
        out = images.upscale(self.photo, ctx)[0]
        with Image.open(out) as im:
            self.assertEqual(im.size, (1000, 800))
        from satsuma import engines
        if engines.have_module("cv2") and not engines.have_module("rembg"):
            out = images.remove_background(self.photo, self.ctx())[0]
            with Image.open(out) as im:
                self.assertEqual(im.mode, "RGBA")


if __name__ == "__main__":
    unittest.main()
