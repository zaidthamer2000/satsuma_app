import os
import threading
import unittest

import helpers
from helpers import TempDirCase
from satsuma import util


class UtilTests(TempDirCase):
    def test_parse_and_format_sizes(self):
        self.assertEqual(util.parse_size("2MB"), 2 * 1024 ** 2)
        self.assertEqual(util.parse_size("1.5m"), int(1.5 * 1024 ** 2))
        self.assertEqual(util.parse_size("500 kb"), 500 * 1024)
        self.assertEqual(util.parse_size("300"), 300)
        with self.assertRaises(ValueError):
            util.parse_size("lots")
        self.assertEqual(util.human_size(0), "0 B")
        self.assertEqual(util.human_size(1536 * 1024), "1.5 MB")

    def test_safe_stem_handles_windows_rules(self):
        self.assertEqual(util.safe_stem("CON"), "_CON")
        self.assertEqual(util.safe_stem("a:b?c*"), "a_b_c_")
        self.assertEqual(util.safe_stem("name. "), "name")
        self.assertEqual(util.safe_stem("   "), "file")
        self.assertEqual(util.safe_stem("صورة"), "صورة")
        self.assertLessEqual(len(util.safe_stem("x" * 500)), 120)

    def test_claim_path_never_overwrites(self):
        a = util.claim_path(self.tmp, "report", "pdf")
        b = util.claim_path(self.tmp, "report", ".pdf")
        self.assertEqual(a.name, "report.pdf")
        self.assertEqual(b.name, "report (1).pdf")

    def test_claim_path_is_race_free(self):
        names, lock = [], threading.Lock()

        def worker():
            p = util.claim_path(self.tmp, "same", "txt")
            with lock:
                names.append(p.name)

        threads = [threading.Thread(target=worker) for _ in range(24)]
        [t.start() for t in threads]
        [t.join() for t in threads]
        self.assertEqual(len(set(names)), 24)

    def test_move_into_place_replaces_placeholder(self):
        src = self.tmp / "src.bin"
        src.write_bytes(b"data")
        dst = util.claim_path(self.tmp, "dst", "bin")
        util.move_into_place(src, dst)
        self.assertEqual(dst.read_bytes(), b"data")
        self.assertFalse(src.exists())

    def test_run_cmd_reports_missing_program_and_timeout(self):
        from satsuma.model import MissingEngine, ConversionError
        with self.assertRaises(MissingEngine):
            util.run_cmd(["definitely-not-a-real-program-xyz"])
        import sys
        with self.assertRaises(ConversionError):
            util.run_cmd([sys.executable, "-c", "import time; time.sleep(30)"], timeout=0.5)

    def test_run_cmd_cancel(self):
        import sys
        from satsuma.model import Cancelled, Context, Options
        ctx = Context(Options(), self.tmp)
        threading.Timer(0.4, ctx.cancel.set).start()
        with self.assertRaises(Cancelled):
            util.run_cmd([sys.executable, "-c", "import time; time.sleep(30)"], ctx)

    def test_ascii_workdir_and_unicode_paths(self):
        with util.workdir(ascii_only=True) as w:
            p = w / "ملف.txt"
            p.write_text("x", encoding="utf-8")
            self.assertTrue(p.exists())
        self.assertFalse(w.exists())


if __name__ == "__main__":
    unittest.main()
