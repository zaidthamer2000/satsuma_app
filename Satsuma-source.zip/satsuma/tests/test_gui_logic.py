"""Exercises the window's logic with a Qt stand-in (see qt_stub.py)."""
import importlib
import unittest

import helpers
from helpers import TempDirCase, make_photo, make_image_pdf

try:
    import PySide6  # noqa: F401
    REAL_QT = True
except ImportError:
    REAL_QT = False


@unittest.skipIf(REAL_QT, "real PySide6 present - see test_gui_smoke.py")
class GuiLogicTests(TempDirCase):
    def setUp(self):
        super().setUp()
        import qt_stub
        self.undo = qt_stub.install()
        self.addCleanup(self.undo)
        self.qt = qt_stub
        self.app = importlib.import_module("satsuma.gui.app")
        self.win = self.app.MainWindow()
        self.photo = make_photo(self.tmp / "صورة.png", (300, 200))

    def pick(self, action, target=None):
        box = self.win.action_box
        for i, item in enumerate(box._items):
            if item[1] == (action, target):
                box.setCurrentIndex(i)
                return
        self.fail(f"{action}/{target} not offered: {[i[0] for i in box._items]}")

    def test_adding_files_fills_the_action_list(self):
        self.win.add_paths([self.photo])
        self.assertEqual(self.win.files, [self.photo])
        self.assertEqual(self.win.list.count(), 1)
        self.pick("convert", "webp")
        self.assertTrue(self.win.btn_start.isEnabled())
        self.win.add_paths([self.photo])                       # duplicates are ignored
        self.assertEqual(len(self.win.files), 1)

    def test_running_a_conversion_end_to_end(self):
        self.win.add_paths([self.photo])
        self.pick("convert", "webp")
        self.win.quality.setValue(60)
        self.win.start()
        self.assertIsNone(self.win.worker)
        self.assertEqual(self.win.results.rowCount(), 1)
        self.assertTrue((self.tmp / "صورة.webp").exists())
        self.assertEqual(self.win.results.item(0, 1).text(), "Done")

    def test_size_limit_option_and_output_folder(self):
        self.win.add_paths([self.photo])
        self.pick("compress")
        self.win.limit_check.setChecked(True)
        self.win.limit_unit.setCurrentIndex(0)          # KB
        self.win.limit_value.setValue(12)
        self.win.out_dir = self.tmp / "out"
        o = self.win.collect_options()
        self.assertEqual(o.target_size, 12 * 1024)
        self.win.start()
        out = list((self.tmp / "out").iterdir())
        self.assertEqual(len(out), 1)
        self.assertLessEqual(out[0].stat().st_size, 12 * 1024)

    def test_preset_selection_sets_widgets_and_runs(self):
        self.win.add_paths([self.photo])
        box = self.win.preset_box
        idx = [i for i, it in enumerate(box._items) if it[1] == "whatsapp_photo"][0]
        box.setCurrentIndex(idx)
        self.assertEqual(self.win.quality.value(), 80)
        self.assertEqual(self.win.max_side.value(), 1600)
        self.assertTrue(self.win.strip_check.isChecked())
        self.assertFalse(self.win.action_box.isEnabled())
        self.win.start()
        self.assertTrue((self.tmp / "صورة.jpg").exists())

    def test_pdf_options_enable_correctly(self):
        pdf = make_image_pdf(self.tmp / "d.pdf", pages=3)
        self.win.add_paths([pdf])
        self.pick("pdf_rotate")
        self.assertTrue(self.win.angle.isEnabled())
        self.assertTrue(self.win.pages.isEnabled())
        self.assertFalse(self.win.quality.isEnabled())
        self.pick("pdf_unlock")
        self.assertFalse(self.win.angle.isEnabled())
        self.assertTrue(self.win.password.isEnabled())

    def test_no_files_means_nothing_to_start(self):
        self.assertFalse(self.win.btn_start.isEnabled())
        self.win.start()
        self.assertEqual(self.win.results.rowCount(), 0)

    def test_language_switch_to_arabic(self):
        self.win.add_paths([self.photo])
        self.win.lang_box.setCurrentIndex(1)
        self.assertEqual(self.win.lang, "ar")
        labels = [i[0] for i in self.win.action_box._items]
        self.assertTrue(any("تحويل" in t for t in labels))
        self.assertEqual(self.win.btn_start.text(), "ابدأ")

    def test_missing_ocr_language_asks_before_downloading(self):
        self.win.add_paths([self.photo])
        if not any(i[1] == ("ocr", "txt") and i[2].enabled for i in self.win.action_box._items):
            self.skipTest("OCR not available")
        self.pick("ocr", "txt")
        self.win.ocr_langs.setCurrentText("zzz_missing")
        self.qt.QMessageBox.asked.clear()
        self.qt.QMessageBox.answer = "No"
        self.win.start()
        self.assertEqual(len(self.qt.QMessageBox.asked), 1)
        self.assertEqual(self.win.results.item(0, 1).text(), "Failed")

    def test_remove_and_clear(self):
        b = make_photo(self.tmp / "b.png", (40, 40))
        self.win.add_paths([self.photo, b])
        self.win.list._sel = [self.win.list._rows[0]]
        self.win.remove_selected()
        self.assertEqual(self.win.files, [b])
        self.win.clear_files()
        self.assertEqual(self.win.files, [])

    def test_folder_drop_expands_to_files(self):
        folder = self.tmp / "dropped"
        (folder / "sub").mkdir(parents=True)
        make_photo(folder / "a.png", (30, 30))
        make_photo(folder / "sub" / "b.png", (30, 30))
        (folder / ".hidden").write_text("x")
        names = sorted(p.name for p in self.app.expand_paths([folder]))
        self.assertEqual(names, ["a.png", "b.png"])

    def test_history_and_components_tabs_render(self):
        self.win.add_paths([self.photo])
        self.pick("convert", "bmp")
        self.win.start()
        self.win.refresh_history()
        self.assertGreaterEqual(self.win.hist.rowCount(), 1)
        self.win.refresh_components()
        self.assertGreater(self.win.comp.rowCount(), 5)
        self.win.hist.selected = [0]
        self.win._undo_selected_history()
        self.assertFalse((self.tmp / "صورة.bmp").exists())

    def test_batched_paths_from_explorer(self):
        self.win.queue_paths([str(self.photo)])
        self.win.queue_paths([str(self.photo)])
        self.win.add_timer.timeout.emit()
        self.assertEqual(len(self.win.files), 1)


@unittest.skipUnless(REAL_QT, "PySide6 not installed")
class GuiSmokeTests(TempDirCase):
    """With the real Qt (headless): the window builds and converts a file."""

    def test_window_converts_a_file(self):
        import os
        os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
        from PySide6.QtWidgets import QApplication
        from satsuma.gui.app import MainWindow
        app = QApplication.instance() or QApplication([])
        win = MainWindow()
        photo = make_photo(self.tmp / "p.png", (120, 80))
        win.add_paths([photo])
        for i in range(win.action_box.count()):
            if win.action_box.itemData(i) == ("convert", "webp"):
                win.action_box.setCurrentIndex(i)
        win.start()
        win.worker.wait(20000)
        app.processEvents()
        self.assertTrue((self.tmp / "p.webp").exists())
        win.lang_box.setCurrentIndex(1)
        app.processEvents()
        self.assertEqual(win.lang, "ar")


if __name__ == "__main__":
    unittest.main()
