import unittest

import helpers
from helpers import HAVE_PANDOC, HAVE_SOFFICE, TempDirCase
from satsuma.convert import documents
from satsuma.model import MissingEngine


class RoutingTests(unittest.TestCase):
    def test_target_lists(self):
        from pathlib import Path
        self.assertIn("pdf", [t.ext for t in documents.targets(Path("a.docx"))])
        self.assertIn("docx", [t.ext for t in documents.targets(Path("a.md"))])
        self.assertEqual(documents.targets(Path("a.png")), [])


@unittest.skipUnless(HAVE_PANDOC, "Pandoc not installed")
class PandocTests(TempDirCase):
    def test_markdown_to_docx_html_txt_with_arabic(self):
        md = self.tmp / "n.md"
        md.write_text("# Title\n\nHello **world**\n\nمرحبا بالعالم\n", encoding="utf-8")
        for ext in ("docx", "html", "epub", "txt"):
            with self.subTest(ext=ext):
                out = documents.convert(md, ext, self.ctx())[0]
                self.assertGreater(out.stat().st_size, 20)
        txt = documents.convert(md, "txt", self.ctx())[0].read_text("utf-8")
        self.assertIn("مرحبا بالعالم", txt)


@unittest.skipUnless(HAVE_SOFFICE, "LibreOffice not installed")
class LibreOfficeTests(TempDirCase):
    def test_docx_to_pdf_and_back_to_text(self):
        from docx import Document
        from satsuma.convert import pdfs
        d = Document()
        d.add_heading("Report", 1)
        d.add_paragraph("Body text for conversion.")
        src = self.tmp / "in.docx"
        d.save(src)
        pdf = documents.convert(src, "pdf", self.ctx())[0]
        self.assertEqual(pdfs.page_count(pdf), 1)
        self.assertIn("Body text", pdfs.extract_text(pdf)[0])

    def test_csv_to_xlsx_keeps_arabic(self):
        try:
            import openpyxl
        except ImportError:
            self.skipTest("openpyxl not installed")
        src = self.tmp / "d.csv"
        src.write_text("name,qty\nتفاح,3\npear,5\n", encoding="utf-8")
        out = documents.convert(src, "xlsx", self.ctx())[0]
        ws = openpyxl.load_workbook(out).active
        self.assertEqual(ws["A2"].value, "تفاح")

    def test_work_files_with_unicode_names(self):
        from docx import Document
        src = self.tmp / "تقرير.docx"
        d = Document()
        d.add_paragraph("نص")
        d.save(src)
        out = documents.convert(src, "pdf", self.ctx())[0]
        self.assertTrue(out.exists())


class MissingEngineTests(unittest.TestCase):
    def test_unavailable_route_raises_clean_error(self):
        from pathlib import Path
        if documents._route("mobi", "epub"):
            self.skipTest("Calibre is installed")
        from satsuma.model import Context, Options
        import tempfile
        with self.assertRaises(MissingEngine):
            documents.convert(Path("x.mobi"), "epub", Context(Options(), Path(tempfile.gettempdir())))


if __name__ == "__main__":
    unittest.main()
