import os
import unittest

import helpers
from helpers import HAVE_REPORTLAB, HAVE_TESSERACT, TempDirCase, make_text_pdf
from satsuma.convert import ocr
from satsuma.model import MissingLanguage


class LanguageDataTests(TempDirCase):
    def test_missing_language_is_reported_with_its_code(self):
        if not HAVE_TESSERACT:
            self.skipTest("Tesseract not installed")
        with self.assertRaises(MissingLanguage) as cm:
            ocr.ensure_languages("zzz_not_a_language")
        self.assertEqual(cm.exception.languages, ["zzz_not_a_language"])

    def test_download_uses_a_mirror_and_validates_codes(self):
        mirror = self.tmp / "mirror"
        mirror.mkdir()
        (mirror / "qqq.traineddata").write_bytes(b"x" * 2048)
        old = ocr.TESSDATA_URLS
        ocr.TESSDATA_URLS = ["file:///nonexistent-dir/{lang}.traineddata",      # first address fails -> next is tried
                             "file://" + mirror.as_posix() + "/{lang}.traineddata"]
        try:
            path = ocr.download_language("qqq")
            self.assertEqual(path.stat().st_size, 2048)
            from satsuma.model import ConversionError
            with self.assertRaises(ConversionError):
                ocr.download_language("../../etc/passwd")
            with self.assertRaises(ConversionError):
                ocr.download_language("missing")
        finally:
            ocr.TESSDATA_URLS = old
            for f in ocr.tessdata_dir().glob("qqq.*"):
                f.unlink()


@unittest.skipUnless(HAVE_TESSERACT and HAVE_REPORTLAB, "Tesseract/reportlab not installed")
class OcrTests(TempDirCase):
    def setUp(self):
        super().setUp()
        if "eng" not in ocr.installed_languages():
            self.skipTest("English OCR data not installed")
        self.pdf = make_text_pdf(self.tmp / "t.pdf", pages=1)

    def test_text_docx_and_searchable_pdf(self):
        from docx import Document
        from satsuma.convert import pdfs
        txt = ocr.convert(self.pdf, "txt", self.ctx(ocr_langs="eng", render_dpi=150))[0]
        self.assertIn("quick brown fox", txt.read_text("utf-8-sig").replace("\n", " "))
        docx = ocr.convert(self.pdf, "docx", self.ctx(ocr_langs="eng"))[0]
        self.assertIn("quick brown fox", " ".join(p.text for p in Document(docx).paragraphs))
        sp = ocr.convert(self.pdf, "pdf", self.ctx(ocr_langs="eng"))[0]
        self.assertTrue(pdfs.has_text_layer(sp))
        self.assertEqual(pdfs.page_count(sp), 1)

    def test_auto_mode_uses_text_layer_for_normal_pdf(self):
        from satsuma.convert import pdfs
        ctx = self.ctx()
        pdfs.convert(self.pdf, "docx", ctx)
        self.assertNotIn("Tesseract OCR", ctx.engines)


class DocxFromTextTests(TempDirCase):
    def test_ocr_paragraphs_join_wrapped_lines(self):
        self.assertEqual(ocr._paragraphs("one\ntwo\n\nthree"), ["one two", "three"])

    def test_arabic_ocr_text_becomes_rtl_docx(self):
        from docx import Document
        out = self.tmp / "o.docx"
        ocr.texts_to_docx(["مرحبا بكم في البرنامج\nالسطر الثاني", "Second page"], out)
        doc = Document(out)
        self.assertEqual(len(doc.paragraphs) >= 2, True)
        self.assertIn("مرحبا", doc.paragraphs[0].text)


if __name__ == "__main__":
    unittest.main()
