"""PyInstaller entry point: no arguments -> window; otherwise the command line."""
import sys

from satsuma.cli import main

if __name__ == "__main__":
    sys.exit(main())
