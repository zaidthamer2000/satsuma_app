# -*- mode: python ; coding: utf-8 -*-
# Build:  pyinstaller packaging/satsuma.spec --noconfirm --clean
# Produces dist/Satsuma/Satsuma.exe (window) and dist/Satsuma/satsuma-cli.exe (command line).
import os
from PyInstaller.utils.hooks import collect_data_files, collect_dynamic_libs, collect_submodules

root = os.path.abspath(os.path.join(SPECPATH, ".."))
datas, binaries, hidden = [], [], []


def grab(module, data=True, libs=False, subs=False):
    """Collect a package's data/DLLs if it is installed (optional packages are simply skipped)."""
    try:
        __import__(module)
    except Exception:
        return
    if data:
        datas.extend(collect_data_files(module))
    if libs:
        binaries.extend(collect_dynamic_libs(module))
    if subs:
        hidden.extend(collect_submodules(module))


grab("pdfminer")                       # CMap tables used to read PDF text
grab("pdfplumber")
grab("docx")                           # default Word template
grab("pypdfium2", libs=True)
grab("pypdfium2_raw", libs=True)
grab("pikepdf", libs=True)
grab("pillow_heif", libs=True)
grab("pdf2docx", subs=True)
grab("faster_whisper")
grab("rembg", subs=True)

tools = os.path.join(root, "tools")
if os.path.isdir(tools):
    datas.append((tools, "tools"))

a = Analysis([os.path.join(SPECPATH, "entry.py")], pathex=[root], binaries=binaries, datas=datas,
             hiddenimports=hidden, excludes=["tkinter", "matplotlib", "IPython", "pytest"], noarchive=False)
pyz = PYZ(a.pure)
icon = os.path.join(SPECPATH, "satsuma.ico")
icon = icon if os.path.exists(icon) else None

gui = EXE(pyz, a.scripts, [], exclude_binaries=True, name="Satsuma", console=False, icon=icon, upx=False)
cli = EXE(pyz, a.scripts, [], exclude_binaries=True, name="satsuma-cli", console=True, icon=icon, upx=False)
coll = COLLECT(gui, cli, a.binaries, a.datas, strip=False, upx=False, name="Satsuma")
