# Builds Satsuma.exe on Windows 10/11.  Run from the repository root:
#   powershell -ExecutionPolicy Bypass -File packaging\build_windows.ps1
$ErrorActionPreference = "Stop"
python -m venv .venv
.\.venv\Scripts\python -m pip install --upgrade pip
.\.venv\Scripts\python -m pip install -r requirements-dev.txt
Write-Host "Running tests..."
.\.venv\Scripts\python -m unittest discover -s tests
if ($LASTEXITCODE -ne 0) { throw "Tests failed - not building." }
.\.venv\Scripts\python -m PyInstaller packaging\satsuma.spec --noconfirm --clean
Write-Host "Smoke test of the built program..."
.\dist\Satsuma\satsuma-cli.exe doctor
if ($LASTEXITCODE -ne 0) { throw "The built program does not start." }
if (Get-Command iscc -ErrorAction SilentlyContinue) {
    iscc packaging\installer.iss
    Write-Host "Installer: dist\Satsuma-Setup-1.0.0.exe"
} else {
    Write-Host "Inno Setup (iscc) not found - skipped the installer. The portable folder is dist\Satsuma"
}
