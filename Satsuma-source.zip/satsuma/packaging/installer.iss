; Inno Setup script - build with:  iscc packaging\installer.iss   (after PyInstaller has created dist\Satsuma)
#define AppName "Satsuma"
#define AppVersion "1.0.0"

[Setup]
AppId={{6C1D0E55-4C0B-4F43-9B6A-5A7F3E2B9D10}
AppName={#AppName}
AppVersion={#AppVersion}
DefaultDirName={autopf}\{#AppName}
DefaultGroupName={#AppName}
PrivilegesRequired=lowest
PrivilegesRequiredOverridesAllowed=dialog
OutputDir=..\dist
OutputBaseFilename=Satsuma-Setup-{#AppVersion}
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
UninstallDisplayIcon={app}\Satsuma.exe

[Languages]
Name: "english"; MessagesFile: "compiler:Default.isl"

[Tasks]
Name: "desktopicon"; Description: "Create a desktop shortcut"; Flags: unchecked
Name: "shellmenu"; Description: "Add 'Convert with Satsuma' to the right-click menu"; Flags: checkedonce

[Files]
Source: "..\dist\Satsuma\*"; DestDir: "{app}"; Flags: recursesubdirs ignoreversion createallsubdirs

[Icons]
Name: "{group}\{#AppName}"; Filename: "{app}\Satsuma.exe"
Name: "{autodesktop}\{#AppName}"; Filename: "{app}\Satsuma.exe"; Tasks: desktopicon

[Run]
Filename: "{app}\satsuma-cli.exe"; Parameters: "shell register"; Flags: runhidden; Tasks: shellmenu
Filename: "{app}\Satsuma.exe"; Description: "Start Satsuma"; Flags: nowait postinstall skipifsilent

[UninstallRun]
Filename: "{app}\satsuma-cli.exe"; Parameters: "shell unregister"; Flags: runhidden; RunOnceId: "UnregisterShell"
