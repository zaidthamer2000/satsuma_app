"""Watch a folder and run a preset on every new file (polling: no extra dependency, works everywhere)."""
from __future__ import annotations

import os
import threading
import time
from pathlib import Path
from typing import Callable, Optional

from .core import Step, run_job
from .model import Options, Result

PARTIAL_SUFFIXES = {".part", ".crdownload", ".tmp", ".download", ".partial", ".opdownload"}


class FolderWatcher:
    """Processes files that appear in *folder*. Results go to *folder*/'converted' by default, so the
    watcher never reacts to its own output. A file is processed only after its size stopped changing."""

    def __init__(self, folder: Path, steps: list[Step], opts: Optional[Options] = None,
                 on_result: Optional[Callable[[Path, Result], None]] = None, interval: float = 1.0,
                 settle: float = 2.0, out_dir: Optional[Path] = None, process_existing: bool = False):
        self.folder = Path(folder)
        self.steps = steps
        self.out_dir = Path(out_dir) if out_dir else self.folder / "converted"
        self.opts = (opts or Options()).but(out_dir=self.out_dir)
        self.on_result = on_result
        self.interval, self.settle = interval, settle
        self._stop = threading.Event()
        self._thread: Optional[threading.Thread] = None
        self._seen: dict[Path, tuple[int, float]] = {}
        self._done: set[Path] = set()
        if not process_existing:
            self._done = {p for p in self._files()}

    def _files(self):
        try:
            for entry in os.scandir(self.folder):
                p = Path(entry.path)
                if entry.is_file() and not p.name.startswith((".", "~$")) and p.suffix.lower() not in PARTIAL_SUFFIXES:
                    yield p
        except OSError:
            return

    def scan_once(self, now: Optional[float] = None) -> list[Path]:
        """One polling pass; returns the files that were processed. (Public so tests can drive it.)"""
        now = time.monotonic() if now is None else now
        processed = []
        current = set()
        for p in self._files():
            current.add(p)
            if p in self._done:
                continue
            try:
                size = p.stat().st_size
            except OSError:
                continue
            prev = self._seen.get(p)
            if prev is None or prev[0] != size:
                self._seen[p] = (size, now)
                continue
            if now - prev[1] >= self.settle and size > 0 and not self._locked(p):
                self._done.add(p)
                result = run_job([p], self.steps, self.opts, cancel=self._stop)
                processed.append(p)
                if self.on_result:
                    self.on_result(p, result)
        self._done &= current | self._done          # keep memory of finished files
        return processed

    @staticmethod
    def _locked(p: Path) -> bool:
        """True when another program still has the file open for writing (Windows)."""
        try:
            with open(p, "ab"):
                return False
        except OSError:
            return True

    def start(self) -> None:
        if self._thread and self._thread.is_alive():
            return
        self._stop.clear()
        self._thread = threading.Thread(target=self._loop, name="satsuma-watch", daemon=True)
        self._thread.start()

    def _loop(self) -> None:
        while not self._stop.wait(self.interval):
            try:
                self.scan_once()
            except Exception:
                pass

    def stop(self) -> None:
        self._stop.set()
        if self._thread:
            self._thread.join(timeout=5)
