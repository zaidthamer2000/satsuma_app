"""Audio and video through FFmpeg: conversion, size-targeted compression, metadata removal."""
from __future__ import annotations

import json
import re
from functools import lru_cache
from pathlib import Path
from typing import Optional

from .. import engines
from ..formats import AUDIO, VIDEO, Target, canon, kind_of
from ..model import ConversionError, Context, MissingEngine, TargetUnreachable
from ..util import ext_of, human_size, run_cmd

NAME = "ffmpeg"

AUDIO_OUT = {
    "mp3": ["-c:a", "libmp3lame"], "m4a": ["-c:a", "aac"], "aac": ["-c:a", "aac"],
    "ogg": ["-c:a", "libvorbis"], "opus": ["-c:a", "libopus"], "wma": ["-c:a", "wmav2"],
    "wav": ["-c:a", "pcm_s16le"], "flac": ["-c:a", "flac"], "aiff": ["-c:a", "pcm_s16be"],
}
LOSSY_AUDIO = {"mp3", "m4a", "aac", "ogg", "opus", "wma"}
VIDEO_OUT = ("mp4", "mkv", "mov", "webm", "avi", "gif")
SIZE_TARGET_VIDEO = {"mp4", "mkv", "mov", "webm"}


def targets(path: Path) -> list[Target]:
    kind, src = kind_of(path), canon(ext_of(path))
    if kind not in ("audio", "video"):
        return []
    ok = engines.available("ffmpeg")
    miss = "" if ok else "FFmpeg"
    out = [Target(t, NAME, ok, miss) for t in AUDIO_OUT if t != src]
    if kind == "video":
        out = [Target(t, NAME, ok, miss) for t in VIDEO_OUT if t != src] + out
    return out


# ------------------------------------------------------------------------------ probing

def probe(path: Path, ctx: Optional[Context] = None) -> dict:
    exe = engines.find("ffprobe") or engines.require("ffprobe")
    rc, out, err = run_cmd([exe, "-v", "error", "-print_format", "json", "-show_format",
                            "-show_streams", path], ctx, timeout=60)
    if rc != 0:
        raise ConversionError(f"This file could not be read as media: {_tail(err)}")
    data = json.loads(out or "{}")
    streams = data.get("streams", [])
    fmt = data.get("format", {})
    video = next((s for s in streams if s.get("codec_type") == "video"
                  and not s.get("disposition", {}).get("attached_pic")), None)
    audio = next((s for s in streams if s.get("codec_type") == "audio"), None)
    try:
        duration = float(fmt.get("duration") or (video or audio or {}).get("duration") or 0)
    except ValueError:
        duration = 0.0
    return {"duration": duration, "video": video, "audio": audio, "tags": fmt.get("tags", {}) or {},
            "size": int(fmt.get("size") or 0)}


def _tail(text: str, lines: int = 3) -> str:
    parts = [ln.strip() for ln in text.splitlines() if ln.strip()]
    return " | ".join(parts[-lines:]) or "unknown error"


@lru_cache(maxsize=1)
def _encoders() -> frozenset:
    exe = engines.require("ffmpeg")
    rc, out, _ = run_cmd([exe, "-hide_banner", "-encoders"], timeout=30)
    names = set()
    for line in out.splitlines():
        m = re.match(r"^\s[VAS][\w.]{5}\s+(\S+)", line)
        if m:
            names.add(m.group(1))
    return frozenset(names)


def _need(*encoders: str) -> None:
    have = _encoders()
    missing = [e for e in encoders if e not in have]
    if missing:
        raise ConversionError("This FFmpeg build cannot encode " + ", ".join(missing)
                              + ". Install a full FFmpeg build (winget install Gyan.FFmpeg).")


# ---------------------------------------------------------------------------- running

def _run_ffmpeg(args: list, ctx: Context, duration: float, lo: float = 0.0, hi: float = 1.0) -> None:
    exe = engines.require("ffmpeg")
    ctx.used("FFmpeg")

    def on_line(line: str) -> None:
        if duration and (line.startswith("out_time_us=") or line.startswith("out_time_ms=")):
            try:
                seconds = int(line.split("=", 1)[1]) / 1_000_000
            except ValueError:
                return
            ctx.progress(lo + (hi - lo) * min(1.0, seconds / duration), "Encoding")

    rc, _, err = run_cmd([exe, "-hide_banner", "-nostdin", "-y", *args, "-progress", "pipe:1", "-nostats"],
                         ctx, on_line=on_line)
    if rc != 0:
        raise ConversionError(f"FFmpeg could not process this file: {_tail(err)}")


def _meta_args(strip: bool) -> list:
    if strip:
        return ["-map_metadata", "-1", "-map_chapters", "-1", "-fflags", "+bitexact",
                "-flags:v", "+bitexact", "-flags:a", "+bitexact"]
    return ["-map_metadata", "0"]


def _video_filter(opts) -> str:
    if opts.video_height:
        return f"scale=-2:{int(opts.video_height)}:flags=lanczos"
    return "scale=trunc(iw/2)*2:trunc(ih/2)*2"


# ------------------------------------------------------------------------------ audio

MP3_RATES = [8, 16, 24, 32, 40, 48, 56, 64, 80, 96, 112, 128, 160, 192, 224, 256, 320]


def _snap_mp3(kbps: float) -> int:
    return max([r for r in MP3_RATES if r <= kbps] or [MP3_RATES[0]])


def _lower_rate(ext: str, kbps: int) -> int:
    """Next smaller bitrate worth trying (MP3 only accepts a fixed list)."""
    if ext == "mp3":
        return max([r for r in MP3_RATES if r < kbps] or [MP3_RATES[0]])
    return max(6, int(kbps * 0.88))


def _audio_args(ext: str, bitrate_k: Optional[int]) -> list:
    args = list(AUDIO_OUT[ext])
    if ext in LOSSY_AUDIO and bitrate_k:
        if ext == "mp3":
            bitrate_k = _snap_mp3(bitrate_k)
            if bitrate_k <= 64:
                args += ["-ar", "22050"]          # MPEG-2 layer III: valid at very low bitrates
        args += ["-b:a", f"{int(bitrate_k)}k"]
        if bitrate_k <= 32:
            args += ["-ac", "1"]
    return args


def _convert_audio(src: Path, ext: str, ctx: Context, info: dict) -> list[Path]:
    if not info["audio"]:
        raise ConversionError("This file has no audio track")
    out = ctx.path(f"result.{ext}")
    enc = AUDIO_OUT[ext][1]
    _need(enc)
    bitrate = ctx.opts.audio_bitrate_k
    if ctx.opts.target_size:
        if ext not in LOSSY_AUDIO:
            raise ConversionError(f"A size limit needs a lossy format (MP3, M4A, OGG, OPUS) - not {ext.upper()}")
        if not info["duration"]:
            raise ConversionError("The duration of this file is unknown, so a size limit cannot be applied")
        bitrate = int(ctx.opts.target_size * 8 / info["duration"] * 0.96 / 1000)
        floor = {"mp3": 16, "opus": 6, "m4a": 16, "aac": 16, "ogg": 24, "wma": 32}[ext]
        if bitrate < floor:
            raise TargetUnreachable(f"{human_size(ctx.opts.target_size)} is too small for "
                                    f"{info['duration']:.0f} seconds of audio")
        bitrate = min(bitrate, 320)
    cover = [] if ext in ("wav", "flac", "aiff", "ogg", "opus", "wma") else ["-map", "0:v:0?", "-c:v", "copy",
                                                                           "-disposition:v:0", "attached_pic"]
    args = ["-i", src, "-map", "0:a:0", *(cover if (kind_of(src) == "audio" and ext in ("mp3", "m4a")) else []),
            *_audio_args(ext, bitrate), *_meta_args(ctx.opts.strip_metadata), out]
    _run_ffmpeg(args, ctx, info["duration"])
    if ext == "mp3" and ctx.opts.target_size:
        bitrate = _snap_mp3(bitrate)
    for _ in range(6):                                      # verify the size limit, retry a bit lower
        if not ctx.opts.target_size or out.stat().st_size <= ctx.opts.target_size:
            break
        lowered = _lower_rate(ext, int(bitrate))
        if lowered >= bitrate:
            break
        bitrate = lowered
        _run_ffmpeg(["-i", src, "-map", "0:a:0", *_audio_args(ext, bitrate),
                     *_meta_args(ctx.opts.strip_metadata), out], ctx, info["duration"])
    if ctx.opts.target_size and out.stat().st_size > ctx.opts.target_size:
        raise TargetUnreachable("Could not reach the requested size")
    return [out]


# ------------------------------------------------------------------------------ video

def _video_codec_args(ext: str, opts) -> list:
    if ext in ("mp4", "mkv", "mov"):
        _need("libx264", "aac")
        return ["-c:v", "libx264", "-preset", "medium", "-crf", str(opts.video_crf), "-pix_fmt", "yuv420p",
                "-c:a", "aac", "-b:a", f"{min(opts.audio_bitrate_k, 192)}k"]
    if ext == "webm":
        _need("libvpx-vp9", "libopus")
        return ["-c:v", "libvpx-vp9", "-crf", str(min(63, opts.video_crf + 8)), "-b:v", "0", "-row-mt", "1",
                "-cpu-used", "4", "-pix_fmt", "yuv420p", "-c:a", "libopus", "-b:a", "128k"]
    if ext == "avi":
        _need("mpeg4", "libmp3lame")
        return ["-c:v", "mpeg4", "-q:v", "3", "-pix_fmt", "yuv420p", "-c:a", "libmp3lame", "-b:a", "192k"]
    raise ConversionError(f"Unsupported video format: {ext}")


def _convert_gif(src: Path, ctx: Context, info: dict) -> list[Path]:
    if not info["video"]:
        raise ConversionError("This file has no video track")
    if info["duration"] > 30:
        ctx.warn("Long clips make very large GIFs - consider cutting the clip or using WebM/MP4")
    out = ctx.path("result.gif")
    fps, width = int(ctx.opts.gif_fps), int(ctx.opts.gif_width)
    graph = (f"fps={fps},scale='min({width},iw)':-2:flags=lanczos,split[a][b];"
             f"[a]palettegen=stats_mode=diff[p];[b][p]paletteuse=dither=bayer:bayer_scale=5")
    _run_ffmpeg(["-i", src, "-an", "-vf", graph, "-loop", "0", out], ctx, info["duration"])
    return [out]


def _convert_video(src: Path, ext: str, ctx: Context, info: dict) -> list[Path]:
    if not info["video"]:
        raise ConversionError("This file has no video track")
    if ext == "gif":
        return _convert_gif(src, ctx, info)
    out = ctx.path(f"result.{ext}")
    opts = ctx.opts
    common = ["-i", src, "-map", "0:v:0", "-map", "0:a?", "-vf", _video_filter(opts)]
    tail = _meta_args(opts.strip_metadata)
    if ext in ("mp4", "mov"):
        tail = ["-movflags", "+faststart", *tail]
    if not opts.target_size:
        _run_ffmpeg([*common, *_video_codec_args(ext, opts), *tail, out], ctx, info["duration"])
        return [out]
    # --- size-targeted: two-pass at a computed bitrate, verify, retry lower if needed
    if ext not in SIZE_TARGET_VIDEO:
        raise ConversionError(f"A size limit is supported for MP4, MKV, MOV and WebM - not {ext.upper()}")
    if not info["duration"]:
        raise ConversionError("The duration of this file is unknown, so a size limit cannot be applied")
    total_bps = opts.target_size * 8 / info["duration"] * 0.93
    audio_bps = 0 if not info["audio"] else min(128_000, max(24_000, total_bps * 0.15))
    video_bps = total_bps - audio_bps
    if video_bps < 15_000:
        raise TargetUnreachable(f"{human_size(opts.target_size)} is too small for "
                                f"{info['duration']:.0f} seconds of video")
    codec = "libvpx-vp9" if ext == "webm" else "libx264"
    acodec = "libopus" if ext == "webm" else "aac"
    _need(codec, acodec)
    log = str(ctx.path("pass"))
    vs = info["video"]
    width, height = int(vs.get("width") or 0), int(vs.get("height") or 0)
    fps = _fps(vs)
    for attempt in range(3):
        ctx.check()
        h = _pick_height(video_bps, width, height, fps, opts.video_height)
        if h and h != height:
            ctx.warn(f"Resolution reduced to {h}p to fit the size limit")
        vf = f"scale=-2:{h}:flags=lanczos" if h else _video_filter(opts)
        args_in = ["-i", src, "-map", "0:v:0", "-map", "0:a?", "-vf", vf]
        base = [*args_in, "-c:v", codec, "-b:v", str(int(video_bps)), "-pix_fmt", "yuv420p"]
        base += ["-preset", "medium"] if codec == "libx264" else ["-row-mt", "1", "-cpu-used", "4"]
        base += ["-passlogfile", log]
        lo = attempt / 3
        _run_ffmpeg([*base, "-pass", "1", "-an", "-f", "null", "-"], ctx, info["duration"], lo, lo + 0.15)
        audio = ["-an"]
        if info["audio"]:
            audio = ["-c:a", acodec, "-b:a", str(int(audio_bps))] + (["-ac", "1"] if audio_bps < 48_000 else [])
        _run_ffmpeg([*base, "-pass", "2", *audio, *tail, out], ctx, info["duration"], lo + 0.15, lo + 0.33)
        if out.stat().st_size <= opts.target_size:
            return [out]
        video_bps *= (opts.target_size / out.stat().st_size) * 0.92
        if video_bps < 15_000:
            break
    raise TargetUnreachable("Could not reach the requested size without destroying the video")


def _fps(stream: dict) -> float:
    try:
        num, den = str(stream.get("avg_frame_rate") or stream.get("r_frame_rate") or "25/1").split("/")
        value = float(num) / float(den)
        return value if 1 <= value <= 120 else 25.0
    except (ValueError, ZeroDivisionError):
        return 25.0


def _pick_height(video_bps: float, width: int, height: int, fps: float, user_height: Optional[int]) -> int:
    """Largest standard height that still gets >= ~0.04 bits per pixel; 0 = keep the original."""
    if not width or not height:
        return user_height or 0
    ceiling = min(height, user_height) if user_height else height
    for h in sorted({ceiling, 1080, 720, 540, 480, 360, 288, 240, 180, 144}, reverse=True):
        if h > ceiling:
            continue
        w = width * h / height
        if video_bps / (w * h * fps) >= 0.04 or h == 144:
            return h if h != height else 0
    return 0


def convert(src: Path, ext: str, ctx: Context) -> list[Path]:
    ext = canon(ext)
    info = probe(src, ctx)
    ctx.progress(0.02, "Analysing")
    if ext in AUDIO_OUT:
        return _convert_audio(src, ext, ctx, info)
    if ext in VIDEO_OUT:
        return _convert_video(src, ext, ctx, info)
    raise ConversionError(f"Unsupported format: {ext}")


def compress(src: Path, ctx: Context) -> list[Path]:
    kind, ext = kind_of(src), canon(ext_of(src))
    if kind == "video":
        target_ext = ext if ext in SIZE_TARGET_VIDEO else "mp4"
        opts = ctx.opts if ctx.opts.target_size else ctx.opts.but(video_crf=max(ctx.opts.video_crf, 28))
    else:
        target_ext = ext if ext in LOSSY_AUDIO else "mp3"
        opts = ctx.opts.but(audio_bitrate_k=min(ctx.opts.audio_bitrate_k, 128))
    ctx.opts = opts
    return convert(src, target_ext, ctx)


def strip_metadata(src: Path, ctx: Context) -> list[Path]:
    info = probe(src, ctx)
    ext = canon(ext_of(src))
    for key in info["tags"]:
        ctx.note("metadata_removed", f"tag:{key}")
    out = ctx.path(f"result.{ext}")
    _run_ffmpeg(["-i", src, "-map", "0", "-c", "copy", *_meta_args(True), out], ctx, info["duration"])
    return [out]
