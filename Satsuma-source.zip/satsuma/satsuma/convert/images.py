"""Images (Pillow): conversion, resizing, size-targeted compression, background tools."""
from __future__ import annotations

import io
import math
from pathlib import Path
from typing import Optional

from PIL import Image, ImageOps, ImageSequence, features

from .. import engines
from ..formats import IMAGE, Target, canon
from ..model import ConversionError, Context, MissingEngine, TargetUnreachable
from ..util import ext_of, human_size

NAME = "images"

try:  # optional: HEIC / HEIF (and AVIF fallback)
    import pillow_heif  # type: ignore
    pillow_heif.register_heif_opener()
    HEIF = True
except Exception:  # pragma: no cover - depends on environment
    HEIF = False

RAW_EXTS = {"cr2", "cr3", "nef", "arw", "dng", "orf", "rw2", "raf", "pef", "srw"}
PIL_FORMAT = {"jpg": "JPEG", "png": "PNG", "webp": "WEBP", "avif": "AVIF", "tiff": "TIFF",
              "bmp": "BMP", "gif": "GIF", "ico": "ICO", "pdf": "PDF", "heic": "HEIF"}
LOSSY = {"jpg", "webp", "avif", "heic"}


def _has_avif() -> bool:
    try:
        return bool(features.check("avif"))
    except ValueError:                      # very old Pillow does not know the feature name
        return False


def _can_read(ext: str) -> bool:
    ext = canon(ext)
    if ext in RAW_EXTS:
        return engines.have_module("rawpy")
    if ext == "heic":
        return HEIF
    if ext == "avif":
        return _has_avif() or HEIF
    return ext in {canon(e) for e in IMAGE}


def output_formats() -> list[str]:
    out = ["jpg", "png", "webp", "tiff", "bmp", "gif", "ico", "pdf"]
    if _has_avif() or HEIF:
        out.append("avif")
    if HEIF:
        out.append("heic")
    return out


def targets(path: Path) -> list[Target]:
    src = canon(ext_of(path))
    if not _can_read(src):
        if src in RAW_EXTS:
            return [Target(t, NAME, False, "rawpy") for t in ("jpg", "png", "tiff")]
        if src == "heic":
            return [Target(t, NAME, False, "pillow-heif") for t in ("jpg", "png", "webp")]
        return []
    return [Target(t, NAME) for t in output_formats() if t != src]


# ----------------------------------------------------------------------------- reading

def open_image(path: Path) -> Image.Image:
    ext = canon(ext_of(path))
    if ext in RAW_EXTS:
        if not engines.have_module("rawpy"):
            raise MissingEngine("rawpy", "pip install rawpy")
        import rawpy  # type: ignore
        import numpy  # noqa: F401
        with rawpy.imread(str(path)) as raw:
            rgb = raw.postprocess(use_camera_wb=True, no_auto_bright=False)
        return Image.fromarray(rgb)
    try:
        # Read the file fully first: no file handle stays open (matters on Windows, where an open
        # handle blocks deleting or moving the file, e.g. for animated GIF/WebP).
        with open(path, "rb") as fh:
            data = fh.read()
        img = Image.open(io.BytesIO(data))
        img.load()
    except MissingEngine:
        raise
    except Exception as exc:
        raise ConversionError(f"Cannot read this image ({path.name}): {exc}") from exc
    return img


def _frames(img: Image.Image) -> int:
    return getattr(img, "n_frames", 1) or 1


def _has_alpha(img: Image.Image) -> bool:
    return img.mode in ("RGBA", "LA", "PA") or (img.mode == "P" and "transparency" in img.info)


def _flatten(img: Image.Image) -> Image.Image:
    rgba = img.convert("RGBA")
    bg = Image.new("RGB", rgba.size, (255, 255, 255))
    bg.paste(rgba, mask=rgba.getchannel("A"))
    return bg


def _prepare(img: Image.Image, fmt: str) -> Image.Image:
    """Put the pixels into a mode the target encoder accepts."""
    alpha = _has_alpha(img)
    if fmt in ("jpg", "bmp", "pdf"):
        if alpha:
            return _flatten(img)
        return img if img.mode == "RGB" else img.convert("RGB")
    if fmt == "gif":
        return img
    if img.mode in ("I;16", "I;16B", "I;16L", "I") and fmt in ("png", "tiff"):
        return img
    if img.mode in ("I;16", "I;16B", "I;16L", "I", "F"):
        img = img.point(lambda v: v / 256).convert("L") if img.mode.startswith("I") else img.convert("L")
    if img.mode in ("P", "PA"):
        return img.convert("RGBA" if alpha else "RGB")
    if img.mode in ("CMYK", "YCbCr", "LAB", "HSV"):
        return img.convert("RGB")
    if img.mode == "1":
        return img.convert("L")
    return img


def _fit(img: Image.Image, max_side: Optional[int]) -> Image.Image:
    if max_side and max(img.size) > max_side:
        return ImageOps.contain(img, (max_side, max_side), Image.LANCZOS)
    return img


def _scaled(img: Image.Image, factor: float) -> Image.Image:
    w, h = img.size
    return img.resize((max(1, int(w * factor)), max(1, int(h * factor))), Image.LANCZOS)


# ----------------------------------------------------------------------------- encoding

def _meta_kwargs(img: Image.Image, fmt: str, strip: bool) -> dict:
    if strip:
        return {}
    kw: dict = {}
    icc = img.info.get("icc_profile")
    exif = img.info.get("exif")
    if icc and fmt in ("jpg", "png", "webp", "tiff", "avif"):
        kw["icc_profile"] = icc
    if exif and fmt in ("jpg", "webp", "png", "avif"):
        kw["exif"] = exif
    return kw


def _ico_sizes(img: Image.Image) -> list[tuple[int, int]]:
    side = min(256, max(img.size))
    return [(s, s) for s in (16, 24, 32, 48, 64, 128, 256) if s <= side] or [(16, 16)]


def encode(img: Image.Image, fmt: str, quality: int = 85, strip: bool = False,
           dpi: Optional[int] = None) -> bytes:
    """Encode one (already prepared) image to bytes in the given format."""
    buf = io.BytesIO()
    kw = _meta_kwargs(img, fmt, strip)
    if fmt == "jpg":
        kw.update(quality=int(quality), optimize=True, progressive=True)
    elif fmt == "webp":
        kw.update(quality=int(quality), method=4)
    elif fmt == "avif":
        kw.update(quality=int(quality), speed=6)
    elif fmt == "heic":
        kw.update(quality=int(quality))
    elif fmt == "png":
        kw.update(optimize=True, compress_level=9)
    elif fmt == "tiff":
        kw.update(compression="tiff_adobe_deflate")
    elif fmt == "ico":
        if img.width != img.height:                      # pad to a square canvas
            side = max(img.size)
            canvas = Image.new("RGBA", (side, side), (0, 0, 0, 0))
            canvas.paste(img.convert("RGBA"), ((side - img.width) // 2, (side - img.height) // 2))
            img = canvas
        kw = {"sizes": _ico_sizes(img)}
    elif fmt == "pdf":
        kw = {"resolution": float(dpi or 150), "quality": int(quality)}
    elif fmt == "gif":
        img = img.convert("RGBA") if _has_alpha(img) else img.convert("RGB")
        img = img.quantize(256, method=Image.Quantize.FASTOCTREE) if img.mode != "P" else img
    try:
        img.save(buf, PIL_FORMAT[fmt], **kw)
    except OSError as exc:
        raise ConversionError(f"Could not encode {fmt.upper()}: {exc}") from exc
    return buf.getvalue()


def _encode_animated(src: Image.Image, fmt: str, quality: int, max_side: Optional[int]) -> bytes:
    frames, durations = [], []
    for frame in ImageSequence.Iterator(src):
        durations.append(frame.info.get("duration", 100))
        f = _fit(frame.convert("RGBA"), max_side)
        frames.append(f)
    buf = io.BytesIO()
    kw = {"save_all": True, "append_images": frames[1:], "duration": durations,
          "loop": src.info.get("loop", 0)}
    if fmt == "webp":
        kw["quality"] = int(quality)
    frames[0].save(buf, PIL_FORMAT[fmt], **kw)
    return buf.getvalue()


def encode_to_target(img: Image.Image, fmt: str, target: int, opts, ctx: Optional[Context] = None
                     ) -> tuple[bytes, dict]:
    """Smallest-loss encoding that is at most *target* bytes (quality search, then downscale)."""
    strip = opts.strip_metadata
    info = {"scaled": 1.0, "quality": None}
    if fmt not in LOSSY | {"png", "pdf"}:
        raise ConversionError(f"A size limit is not supported for {fmt.upper()} - use JPG, WebP, AVIF, PNG or PDF")
    min_side = 48
    factor = 1.0
    work = img
    for _ in range(14):
        if ctx:
            ctx.check()
        prepared = _prepare(work, fmt)
        if fmt in LOSSY or fmt == "pdf":
            top = min(95, max(1, int(opts.quality)))
            data = encode(prepared, fmt, top, strip)
            if len(data) <= target:
                info.update(quality=top, scaled=factor)
                return data, info
            lo, hi, best = 5, top - 1, None
            while lo <= hi:
                if ctx:
                    ctx.check()
                mid = (lo + hi) // 2
                data = encode(prepared, fmt, mid, strip)
                if len(data) <= target:
                    best, lo = (data, mid), mid + 1
                else:
                    hi = mid - 1
            if best:
                info.update(quality=best[1], scaled=factor)
                return best[0], info
            smallest = len(encode(prepared, fmt, 5, strip))
        else:                                              # PNG: palette reduction, then scale
            data = encode(prepared, "png", 100, strip)
            if len(data) <= target:
                info["scaled"] = factor
                return data, info
            smallest = len(data)
            rgba = prepared.convert("RGBA") if _has_alpha(prepared) else prepared.convert("RGB")
            for colors in (256, 128, 64, 32):
                q = rgba.quantize(colors, method=Image.Quantize.FASTOCTREE)
                data = encode(q, "png", 100, strip)
                smallest = min(smallest, len(data))
                if len(data) <= target:
                    info.update(scaled=factor, colors=colors)
                    return data, info
        # still too big: shrink pixels in proportion to what is missing
        ratio = math.sqrt(target / max(smallest, 1)) * 0.95
        step = min(0.9, max(0.3, ratio))
        factor *= step
        if min(img.size) * factor < min_side:
            break
        work = _scaled(img, factor)
    raise TargetUnreachable(f"Cannot get this image under {human_size(target)} without making it unreadable")


def render(src: Path, fmt: str, opts, ctx: Optional[Context] = None) -> tuple[bytes, dict]:
    """Convert one image file to *fmt* entirely in memory. Used by convert() and by previews."""
    fmt = canon(fmt)
    img = open_image(src)
    info: dict = {"size": img.size}
    if _frames(img) > 1 and fmt in ("gif", "webp"):
        return _encode_animated(img, fmt, opts.quality, opts.max_side), info
    if _frames(img) <= 1:
        img = ImageOps.exif_transpose(img)
    img = _fit(img, opts.max_side)
    if opts.target_size:
        data, more = encode_to_target(img, fmt, opts.target_size, opts, ctx)
        info.update(more)
        return data, info
    return encode(_prepare(img, fmt), fmt, opts.quality, opts.strip_metadata), info


def estimate_size(src: Path, fmt: str, opts) -> int:
    """Exact size of the converted result (images are cheap to encode) for the preview."""
    return len(render(src, fmt, opts)[0])


def convert(src: Path, ext: str, ctx: Context) -> list[Path]:
    ext = canon(ext)
    if ext not in PIL_FORMAT:
        raise ConversionError(f"Unsupported image format: {ext}")
    ctx.used("Pillow")
    ctx.progress(0.1, "Reading image")
    data, info = render(src, ext, ctx.opts, ctx)
    if ctx.opts.target_size and info.get("scaled", 1.0) < 1.0:
        ctx.warn(f"The image was scaled down to {int(info['scaled'] * 100)}% to reach the size limit")
    out = ctx.path(f"result.{ext}")
    out.write_bytes(data)
    ctx.progress(1.0, "Done")
    return [out]


def compress(src: Path, ctx: Context) -> list[Path]:
    ext = canon(ext_of(src))
    img_ext = ext if ext in ("jpg", "png", "webp", "avif") else None
    if img_ext is None:
        probe = open_image(src)
        img_ext = "webp" if _has_alpha(probe) else "jpg"
    return convert(src, img_ext, ctx)


# ----------------------------------------------------------------------- background / upscale

def remove_background(src: Path, ctx: Context) -> list[Path]:
    img = open_image(src)
    img = ImageOps.exif_transpose(img) if _frames(img) <= 1 else img
    out = ctx.path("result.png")
    if engines.have_module("rembg"):
        ctx.used("rembg")
        from rembg import remove  # type: ignore
        ctx.progress(0.2, "Removing background (first run downloads the AI model)")
        result = remove(img.convert("RGBA"))
        result.save(out, "PNG")
        return [out]
    if engines.have_module("cv2"):
        ctx.used("OpenCV GrabCut")
        ctx.warn("Basic mode (OpenCV). Install 'rembg' for much better cut-outs.")
        _grabcut(img.convert("RGB"), out)
        return [out]
    raise MissingEngine("rembg", "pip install rembg  (or  pip install opencv-python-headless  for basic mode)")


def _grabcut(img: Image.Image, out: Path) -> None:
    import cv2  # type: ignore
    import numpy as np
    arr = np.array(img)[:, :, ::-1].copy()
    h, w = arr.shape[:2]
    scale = min(1.0, 1000 / max(h, w))
    small = cv2.resize(arr, (int(w * scale), int(h * scale))) if scale < 1 else arr
    mask = np.zeros(small.shape[:2], np.uint8)
    mx, my = max(2, small.shape[1] // 20), max(2, small.shape[0] // 20)
    rect = (mx, my, small.shape[1] - 2 * mx, small.shape[0] - 2 * my)
    bgd, fgd = np.zeros((1, 65), np.float64), np.zeros((1, 65), np.float64)
    cv2.grabCut(small, mask, rect, bgd, fgd, 5, cv2.GC_INIT_WITH_RECT)
    fg = np.where((mask == cv2.GC_FGD) | (mask == cv2.GC_PR_FGD), 255, 0).astype(np.uint8)
    fg = cv2.morphologyEx(fg, cv2.MORPH_OPEN, np.ones((3, 3), np.uint8))
    fg = cv2.GaussianBlur(fg, (5, 5), 0)
    if scale < 1:
        fg = cv2.resize(fg, (w, h), interpolation=cv2.INTER_LINEAR)
    rgba = img.convert("RGBA")
    rgba.putalpha(Image.fromarray(fg))
    rgba.save(out, "PNG")


def upscale(src: Path, ctx: Context) -> list[Path]:
    scale = max(2, min(4, int(ctx.opts.scale)))
    out = ctx.path("result.png")
    exe = engines.find("realesrgan")
    if exe:
        ctx.used("Real-ESRGAN")
        from ..util import run_cmd
        tmp_in = ctx.path("in.png")
        open_image(src).convert("RGBA").save(tmp_in)
        rc, _, err = run_cmd([exe, "-i", tmp_in, "-o", out, "-s", str(scale), "-n",
                              "realesrgan-x4plus" if scale == 4 else "realesrgan-x4plus"], ctx, timeout=1800)
        if rc == 0 and out.exists():
            if scale != 4:
                im = Image.open(out)
                im = im.resize((im.width * scale // 4, im.height * scale // 4), Image.LANCZOS)
                im.save(out)
            return [out]
        ctx.warn("Real-ESRGAN failed - used the standard resize instead")
    ctx.used("Pillow")
    img = ImageOps.exif_transpose(open_image(src))
    if max(img.size) * scale > 20000:
        raise ConversionError("The result would be too large for this image")
    big = img.convert("RGBA" if _has_alpha(img) else "RGB").resize(
        (img.width * scale, img.height * scale), Image.LANCZOS)
    from PIL import ImageFilter
    big = big.filter(ImageFilter.UnsharpMask(radius=1.6, percent=80, threshold=2))
    big.save(out, "PNG", optimize=True)
    if not exe:
        ctx.warn("Standard (non-AI) resize. Put realesrgan-ncnn-vulkan in the tools folder for AI upscaling.")
    return [out]
