"""Text recognition with Tesseract (Arabic, English and ~100 more languages)."""
from __future__ import annotations

import os
import re
import shutil
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Optional

from PIL import Image, ImageOps

from .. import engines, net
from ..formats import Target, kind_of
from ..model import ConversionError, Context, MissingLanguage
from ..util import IS_WINDOWS, data_dir, is_ascii, run_cmd, workdir
from . import images as img_backend

NAME = "ocr"
OUT_FORMATS = ("txt", "docx", "pdf")
_ENV_URL = os.environ.get("SATSUMA_TESSDATA_URL")
TESSDATA_URLS = [_ENV_URL] if _ENV_URL else [
    "https://github.com/tesseract-ocr/tessdata_{quality}/raw/main/{lang}.traineddata",
    "https://github.com/tesseract-ocr/tessdata_{quality}/raw/master/{lang}.traineddata",
]

LANGUAGES = {
    "ara": "Arabic", "eng": "English", "fas": "Persian", "urd": "Urdu", "heb": "Hebrew", "tur": "Turkish",
    "fra": "French", "deu": "German", "spa": "Spanish", "ita": "Italian", "por": "Portuguese",
    "rus": "Russian", "ukr": "Ukrainian", "hin": "Hindi", "ben": "Bengali", "chi_sim": "Chinese (Simplified)",
    "chi_tra": "Chinese (Traditional)", "jpn": "Japanese", "kor": "Korean", "kur": "Kurdish (Kurmanji)",
    "ckb": "Kurdish (Sorani)", "syr": "Syriac", "ell": "Greek", "nld": "Dutch", "pol": "Polish",
}


def targets(path: Path) -> list[Target]:
    if kind_of(path) not in ("image", "pdf"):
        return []
    ok = engines.available("tesseract")
    return [Target(t, NAME, ok, "" if ok else "Tesseract OCR") for t in OUT_FORMATS]


# --------------------------------------------------------------------------- language data

def tessdata_dir() -> Path:
    base = data_dir() / "tessdata"
    if IS_WINDOWS and not is_ascii(base):          # Tesseract cannot read non-ASCII folders reliably
        alt = Path(os.environ.get("ProgramData", "C:\\ProgramData")) / "Satsuma" / "tessdata"
        try:
            alt.mkdir(parents=True, exist_ok=True)
            return alt
        except OSError:
            pass
    base.mkdir(parents=True, exist_ok=True)
    return base


def system_tessdata() -> Optional[Path]:
    exe = engines.find("tesseract")
    if not exe:
        return None
    try:
        rc, out, err = run_cmd([exe, "--list-langs"], timeout=30)
    except Exception:
        return None
    m = re.search(r'"([^"]+)"', (out or "") + "\n" + (err or ""))
    if m:
        p = Path(m.group(1))
        if p.is_dir():
            return p
    return None


def installed_languages() -> set[str]:
    langs = {f.stem for f in tessdata_dir().glob("*.traineddata")}
    sysdir = system_tessdata()
    if sysdir:
        langs |= {f.stem for f in sysdir.glob("*.traineddata")}
    return langs - {"osd", "equ"}


def download_language(lang: str, quality: str = "best", progress=None, cancel=None) -> Path:
    if not re.fullmatch(r"[A-Za-z_]{2,16}", lang):
        raise ConversionError(f"Invalid language code: {lang}")
    quality = quality if quality in ("best", "fast") else "best"
    last: Exception = ConversionError("No download address configured")
    for template in TESSDATA_URLS:
        try:
            return net.download(template.format(quality=quality, lang=lang),
                                tessdata_dir() / f"{lang}.traineddata", progress, cancel)
        except ConversionError as exc:                    # try the next address (e.g. other branch name)
            last = exc
    raise last


def ensure_languages(langs: str, allow_download: bool = False, quality: str = "best",
                     progress=None, cancel=None) -> Path:
    """Make sure every language is present in ONE folder Tesseract can read; return it."""
    wanted = [l for l in re.split(r"[+,\s]+", langs) if l]
    if not wanted:
        raise ConversionError("No OCR language selected")
    user, sysdir = tessdata_dir(), system_tessdata()
    missing = []
    for lang in wanted:
        target = user / f"{lang}.traineddata"
        if target.exists():
            continue
        if sysdir and (sysdir / f"{lang}.traineddata").exists():
            shutil.copy2(sysdir / f"{lang}.traineddata", target)
        else:
            missing.append(lang)
    if missing:
        if not allow_download:
            raise MissingLanguage(missing)
        for lang in missing:
            download_language(lang, quality, progress, cancel)
    return user


# ---------------------------------------------------------------------------------- engine

def _prepare_pages(src: Path, ctx: Context, as_jpeg: bool) -> list[Path]:
    """ASCII-named, grayscale page images in the work folder."""
    opts = ctx.opts
    outdir = ctx.work / "ocr_pages"
    outdir.mkdir(exist_ok=True)
    dpi = max(150, min(600, opts.ocr_dpi))
    ext = "jpg" if as_jpeg else "png"
    pages: list[Path] = []
    if kind_of(src) == "pdf":
        from . import pdfs
        pdf = pdfs._pdfium(src, opts.password)
        try:
            idx = pdfs.parse_pages(opts.page_spec, len(pdf))
            for n, i in enumerate(idx):
                ctx.check()
                ctx.progress(0.25 * n / len(idx), f"Preparing page {i + 1}")
                pil = pdf[i].render(scale=dpi / 72, grayscale=True).to_pil()
                pages.append(_save_page(pil, outdir / f"p{n:05d}.{ext}", dpi, as_jpeg))
        finally:
            pdf.close()
    else:
        img = ImageOps.exif_transpose(img_backend.open_image(src))
        if max(img.size) < 1600:
            f = 2 if max(img.size) >= 800 else 3
            img = img.resize((img.width * f, img.height * f), Image.LANCZOS)
        pages.append(_save_page(img, outdir / f"p00000.{ext}", dpi, as_jpeg))
    return pages


def _save_page(pil: Image.Image, dest: Path, dpi: int, as_jpeg: bool) -> Path:
    if pil.mode in ("RGBA", "LA", "P"):
        pil = img_backend._flatten(pil)
    gray = ImageOps.autocontrast(pil.convert("L"), cutoff=1)
    if as_jpeg:
        gray.save(dest, "JPEG", quality=85, dpi=(dpi, dpi))
    else:
        gray.save(dest, "PNG", dpi=(dpi, dpi))
    return dest


def _run_tesseract(page: Path, out_base: Path, langs: str, tessdata: Path, mode: str, ctx: Context) -> None:
    exe = engines.require("tesseract")
    env = dict(os.environ, OMP_THREAD_LIMIT="1")
    args = [exe, page, out_base, "-l", langs, "--tessdata-dir", tessdata, "--psm", "3", "--oem", "1"]
    if mode == "pdf":                       # '-c' works even when the folder has no 'configs' directory
        args += ["-c", "tessedit_create_pdf=1"]
    rc, _, err = run_cmd(args, ctx, timeout=900, env=env)
    expected = out_base.with_suffix(".pdf" if mode == "pdf" else ".txt")
    if rc != 0 or not expected.exists():
        tail = " | ".join([ln for ln in err.splitlines() if ln.strip()][-2:])
        raise ConversionError(f"Text recognition failed: {tail or 'unknown error'}")


def recognise(src: Path, ext: str, ctx: Context) -> tuple[list[Path], list[str]]:
    """Core routine: returns (page_pdfs_or_empty, page_texts)."""
    opts = ctx.opts
    engines.require("tesseract")
    tessdata = ensure_languages(opts.ocr_langs, opts.allow_download, opts.ocr_quality, cancel=ctx.cancel)
    ctx.used("Tesseract OCR")
    pages = _prepare_pages(src, ctx, as_jpeg=(ext == "pdf"))
    mode = "pdf" if ext == "pdf" else "txt"
    results: dict[int, Path] = {}
    workers = max(1, min(4, (os.cpu_count() or 2) // 2 or 1, len(pages)))
    done = 0
    with ThreadPoolExecutor(max_workers=workers) as pool:
        futures = {pool.submit(_run_tesseract, p, p.with_suffix(""), opts.ocr_langs, tessdata, mode, ctx): n
                   for n, p in enumerate(pages)}
        try:
            for fut in as_completed(futures):
                fut.result()
                done += 1
                ctx.progress(0.25 + 0.7 * done / len(pages), f"Recognised {done} of {len(pages)} pages")
        except BaseException:
            for f in futures:
                f.cancel()
            raise
    if mode == "pdf":
        return [p.with_suffix(".pdf") for p in pages], []
    texts = [p.with_suffix(".txt").read_text(encoding="utf-8", errors="replace") for p in pages]
    return [], texts


def _paragraphs(page_text: str) -> list[str]:
    paras = []
    for block in re.split(r"\n\s*\n", page_text.replace("\r\n", "\n")):
        lines = [ln.strip() for ln in block.split("\n") if ln.strip()]
        if lines:
            paras.append(" ".join(lines))
    return paras


def texts_to_docx(texts: list[str], dest: Path) -> None:
    from docx import Document
    from .pdfs import add_text_paragraph
    doc = Document()
    for i, page in enumerate(texts):
        for para in _paragraphs(page):
            add_text_paragraph(doc, para)
        if i < len(texts) - 1:
            doc.add_page_break()
    doc.save(str(dest))


def convert(src: Path, ext: str, ctx: Context) -> list[Path]:
    if ext not in OUT_FORMATS:
        raise ConversionError(f"Unsupported OCR output: {ext}")
    return _ocr(src, ext, ctx)


def convert_pdf(src: Path, ext: str, ctx: Context) -> list[Path]:
    return _ocr(src, ext, ctx)


def _ocr(src: Path, ext: str, ctx: Context) -> list[Path]:
    page_files, texts = recognise(src, ext, ctx)
    out = ctx.path(f"result.{ext}")
    if ext == "pdf":
        import pikepdf
        merged = pikepdf.new()
        opened = [pikepdf.open(p) for p in page_files]
        try:
            for o in opened:
                merged.pages.extend(o.pages)
            merged.save(out)
        finally:
            for o in opened:
                o.close()
        return [out]
    if not "".join(texts).strip():
        ctx.warn("No text was recognised - check the language setting and the image quality")
    if ext == "txt":
        out.write_text("\n\n".join(t.strip() for t in texts), encoding="utf-8-sig")
    else:
        texts_to_docx(texts, out)
    return [out]
