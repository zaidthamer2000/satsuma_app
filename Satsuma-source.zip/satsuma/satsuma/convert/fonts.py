"""Fonts (fontTools): TTF/OTF <-> WOFF/WOFF2."""
from __future__ import annotations

from pathlib import Path

from .. import engines
from ..formats import Target, canon
from ..model import ConversionError, Context, MissingEngine
from ..util import ext_of

NAME = "fonts"


def _flavour(path: Path) -> str:
    """'ttf' for TrueType outlines, 'otf' for CFF outlines."""
    try:
        from fontTools.ttLib import TTFont
        with TTFont(str(path), lazy=True) as f:
            return "otf" if "CFF " in f or "CFF2" in f else "ttf"
    except Exception:
        return "ttf"


def targets(path: Path) -> list[Target]:
    src = canon(ext_of(path))
    woff2_ok = engines.have_module("brotli")
    out = []
    if src in ("ttf", "otf"):
        out.append(Target("woff", NAME))
        out.append(Target("woff2", NAME, woff2_ok, "" if woff2_ok else "brotli"))
    elif src in ("woff", "woff2"):
        out.append(Target(_flavour(path), NAME))
        if src == "woff":
            out.append(Target("woff2", NAME, woff2_ok, "" if woff2_ok else "brotli"))
        else:
            out.append(Target("woff", NAME))
    return out


def convert(src: Path, ext: str, ctx: Context) -> list[Path]:
    from fontTools.ttLib import TTFont, TTLibError
    ext = canon(ext)
    if ext == "woff2" and not engines.have_module("brotli"):
        raise MissingEngine("brotli", "pip install brotli")
    ctx.used("fontTools")
    try:
        font = TTFont(str(src))
    except (TTLibError, OSError) as exc:
        raise ConversionError(f"This font could not be read: {exc}") from exc
    font.flavor = {"woff": "woff", "woff2": "woff2"}.get(ext)
    out = ctx.path(f"result.{ext}")
    font.save(str(out))
    font.close()
    return [out]
