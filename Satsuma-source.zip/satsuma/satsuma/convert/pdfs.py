"""PDF tools: render, text, merge / split / extract / rotate / unlock, size-targeted compression."""
from __future__ import annotations

import io
import re
import unicodedata
from pathlib import Path
from typing import Optional

from .. import engines
from ..formats import Target, kind_of
from ..model import ConversionError, Context, MissingEngine, TargetUnreachable
from ..util import human_size
from . import images as img_backend

NAME = "pdf"
IMAGE_TARGETS = ("png", "jpg", "webp", "tiff")


def targets(path: Path) -> list[Target]:
    if kind_of(path) != "pdf":
        return []
    out = [Target(t, NAME) for t in IMAGE_TARGETS]
    out.append(Target("txt", NAME))
    out.append(Target("docx", NAME))
    return out


# ------------------------------------------------------------------------------ helpers

def _pdfium(path: Path, password: Optional[str] = None):
    import pypdfium2 as pdfium
    try:
        return pdfium.PdfDocument(str(path), password=password)
    except pdfium.PdfiumError as exc:
        if "password" in str(exc).lower():
            raise ConversionError("This PDF is password-protected. Enter the password and try again.") from exc
        raise ConversionError(f"This PDF could not be opened: {exc}") from exc


def _pikepdf_open(path: Path, password: Optional[str] = None):
    import pikepdf
    try:
        return pikepdf.open(path, password=password or "")
    except pikepdf.PasswordError as exc:
        raise ConversionError("This PDF is password-protected. Enter the correct password.") from exc
    except pikepdf.PdfError as exc:
        raise ConversionError(f"This PDF could not be opened: {exc}") from exc


def parse_pages(spec: str, total: int) -> list[int]:
    """'1-3,5,8-' -> zero-based indices. Order and repeats are kept (so 3,1,2 reorders)."""
    spec = (spec or "").strip()
    if not spec:
        return list(range(total))
    result: list[int] = []
    for part in re.split(r"[,\s;]+", spec):
        if not part:
            continue
        m = re.fullmatch(r"(\d*)(-?)(\d*)", part)
        if not m or not (m.group(1) or m.group(3)):
            raise ConversionError(f"Cannot understand the page list: '{part}'")
        a, dash, b = m.groups()
        start = int(a) if a else 1
        end = int(b) if b else (total if dash else start)
        if not dash:
            end = start
        if start < 1 or end < 1 or start > total or end > total:
            raise ConversionError(f"Page {max(start, end)} does not exist - this PDF has {total} pages")
        step = 1 if end >= start else -1
        result.extend(range(start - 1, end - 1 + (1 if step > 0 else -1), step))
    if not result:
        raise ConversionError("No pages selected")
    return result


def page_count(path: Path, password: Optional[str] = None) -> int:
    with _pikepdf_open(path, password) as pdf:
        return len(pdf.pages)


def extract_text(path: Path, password: Optional[str] = None, pages: Optional[list[int]] = None,
                 ctx: Optional[Context] = None) -> list[str]:
    pdf = _pdfium(path, password)
    try:
        idx = pages if pages is not None else range(len(pdf))
        texts = []
        for n, i in enumerate(idx):
            if ctx:
                ctx.check()
                ctx.progress(n / max(1, len(idx)), "Reading text")
            tp = pdf[i].get_textpage()
            texts.append(tp.get_text_range() or "")
            tp.close()
        return texts
    finally:
        pdf.close()


def has_text_layer(path: Path, password: Optional[str] = None, sample: int = 5) -> bool:
    pdf = _pdfium(path, password)
    try:
        n = min(sample, len(pdf))
        chars = 0
        for i in range(n):
            tp = pdf[i].get_textpage()
            chars += len((tp.get_text_range() or "").strip())
            tp.close()
        return chars >= 20
    finally:
        pdf.close()


_RTL = re.compile(r"[\u0590-\u08FF\uFB1D-\uFDFF\uFE70-\uFEFF]")


def rtl_ratio(text: str) -> float:
    letters = [c for c in text if c.isalpha()]
    if not letters:
        return 0.0
    return sum(1 for c in letters if _RTL.match(c)) / len(letters)


# ------------------------------------------------------------------------------ convert

def convert(src: Path, ext: str, ctx: Context) -> list[Path]:
    opts = ctx.opts
    if ext in IMAGE_TARGETS:
        return pdf_to_images(src, ext, ctx)
    if ext == "txt":
        pages = parse_pages(opts.page_spec, page_count(src, opts.password))
        texts = extract_text(src, opts.password, pages, ctx)
        if not "".join(texts).strip():
            from . import ocr
            ctx.warn("This PDF has no text layer (it is a scan) - text was recognised with OCR")
            return ocr.convert_pdf(src, "txt", ctx)
        out = ctx.path("result.txt")
        out.write_text("\n\n".join(t.replace("\r\n", "\n").strip() for t in texts), encoding="utf-8-sig")
        ctx.used("PDFium")
        return [out]
    if ext == "docx":
        return pdf_to_docx(src, ctx)
    raise ConversionError(f"Unsupported PDF target: {ext}")


def pdf_to_images(src: Path, ext: str, ctx: Context) -> list[Path]:
    opts = ctx.opts
    ctx.used("PDFium")
    pdf = _pdfium(src, opts.password)
    try:
        pages = parse_pages(opts.page_spec, len(pdf))
        outs = []
        digits = max(3, len(str(len(pdf))))
        for n, i in enumerate(pages):
            ctx.check()
            ctx.progress(n / len(pages), f"Page {i + 1}")
            bitmap = pdf[i].render(scale=max(36, opts.render_dpi) / 72)
            pil = bitmap.to_pil()
            data = img_backend.encode(img_backend._prepare(pil, ext), ext, opts.quality, opts.strip_metadata,
                                      dpi=opts.render_dpi)
            out = ctx.path(f"page_{i + 1:0{digits}d}.{ext}")
            out.write_bytes(data)
            outs.append(out)
        return outs
    finally:
        pdf.close()


# ---------------------------------------------------------------------------- PDF -> Word

def pdf_to_docx(src: Path, ctx: Context) -> list[Path]:
    opts = ctx.opts
    out = ctx.path("result.docx")
    mode = opts.pdf_word_mode
    scanned = not has_text_layer(src, opts.password)
    sample = "" if scanned else "".join(extract_text(src, opts.password, [0, *([1] if page_count(src, opts.password) > 1 else [])]))
    arabic = rtl_ratio(sample) > 0.2
    from . import ocr
    ocr_ready = engines.available("tesseract")

    if mode == "auto":
        if scanned:
            mode = "ocr"
        elif arabic and ocr_ready:
            mode = "ocr"
            ctx.warn("Arabic/Hebrew text in PDFs is often stored in visual order, so the pages were "
                     "re-read with OCR to get correct, editable text. Check the result.")
        else:
            mode = "editable"
    if mode == "ocr":
        return ocr.convert_pdf(src, "docx", ctx)
    if mode == "layout":
        from . import documents
        return documents.pdf_layout_to_docx(src, ctx)
    # editable
    if engines.have_module("pdf2docx"):
        try:
            from pdf2docx import Converter  # type: ignore
            ctx.used("pdf2docx")
            cv = Converter(str(src), password=opts.password or None)
            try:
                cv.convert(str(out))
            finally:
                cv.close()
            if out.exists():
                return [out]
        except Exception as exc:  # fall through to the built-in converter
            ctx.warn(f"pdf2docx could not convert this file ({exc}); the built-in converter was used")
    if arabic:
        ctx.warn("Arabic text may appear in the wrong order in this PDF. Install Tesseract with Arabic data "
                 "for a more reliable result.")
    _builtin_flow_docx(src, out, ctx)
    return [out]


def _set_rtl(paragraph) -> None:
    from docx.oxml import OxmlElement
    pPr = paragraph._p.get_or_add_pPr()
    bidi = OxmlElement("w:bidi")
    pPr.insert_element_before(bidi, "w:adjustRightInd", "w:snapToGrid", "w:spacing", "w:ind",
                              "w:contextualSpacing", "w:mirrorIndents", "w:suppressOverlap", "w:jc",
                              "w:textDirection", "w:textAlignment", "w:textboxTightWrap", "w:outlineLvl",
                              "w:divId", "w:cnfStyle", "w:rPr", "w:sectPr", "w:pPrChange")
    for run in paragraph.runs:
        rPr = run._r.get_or_add_rPr()
        rtl = OxmlElement("w:rtl")
        rPr.insert_element_before(rtl, "w:cs", "w:em", "w:lang", "w:eastAsianLayout", "w:specVanish", "w:oMath")


def add_text_paragraph(doc, text: str, style: Optional[str] = None, bold: bool = False, size: Optional[float] = None):
    """Append a paragraph, switching it to right-to-left when the text is mostly Arabic/Hebrew."""
    from docx.shared import Pt
    p = doc.add_paragraph(style=style) if style else doc.add_paragraph()
    run = p.add_run(text)
    run.bold = bold or None
    if size:
        run.font.size = Pt(size)
    if rtl_ratio(text) >= 0.5:
        _set_rtl(p)
    return p


_BULLET = re.compile(r"^\s*([\u2022\u25CF\u25AA\u25E6\u2023\u2043\-\u2013\*]|\(cid:\d+\))\s*(.*)$")
_CID = re.compile(r"\(cid:\d+\)")


def _builtin_flow_docx(src: Path, dst: Path, ctx: Context) -> None:
    """Text, headings, bullets, tables and pictures as flowing, editable Word content."""
    import statistics
    import pdfplumber
    from docx import Document
    from docx.shared import Emu, Pt

    ctx.used("pdfplumber + python-docx")
    doc = Document()
    sec = doc.sections[0]
    with pdfplumber.open(str(src), password=ctx.opts.password or None) as pdf:
        total = len(pdf.pages)
        first = pdf.pages[0]
        sec.page_width, sec.page_height = Pt(first.width), Pt(first.height)
        margin = Pt(min(54, first.width * 0.08))
        sec.left_margin = sec.right_margin = sec.top_margin = sec.bottom_margin = margin
        content_w = sec.page_width - 2 * margin
        sizes = [c["size"] for pg in pdf.pages[:6] for c in pg.chars[:4000] if c.get("size")]
        body = statistics.median(sizes) if sizes else 11.0
        doc.styles["Normal"].font.size = Pt(round(body * 2) / 2 if 6 <= body <= 16 else 11)

        for idx, page in enumerate(pdf.pages):
            ctx.check()
            ctx.progress(idx / total, f"Page {idx + 1} of {total}")
            blocks: list[tuple[float, str, object]] = []
            tables = []
            try:
                tables = page.find_tables()
            except Exception:
                tables = []
            boxes = [t.bbox for t in tables]
            for t in tables:
                rows = t.extract()
                if rows:
                    blocks.append((t.bbox[1], "table", rows))

            def in_table(w):
                cx, cy = (w["x0"] + w["x1"]) / 2, (w["top"] + w["bottom"]) / 2
                return any(b[0] <= cx <= b[2] and b[1] <= cy <= b[3] for b in boxes)

            words = [w for w in page.extract_words(extra_attrs=["size", "fontname"], keep_blank_chars=False)
                     if not in_table(w)]
            words.sort(key=lambda w: (round(w["top"]), w["x0"]))
            lines: list[list[dict]] = []
            for w in words:
                if lines and abs(lines[-1][0]["top"] - w["top"]) <= max(2.0, 0.5 * w["size"]):
                    lines[-1].append(w)
                else:
                    lines.append([w])
            paras: list[dict] = []
            for ln in lines:
                ln.sort(key=lambda w: w["x0"])
                raw_text = " ".join(w["text"] for w in ln)
                text = unicodedata.normalize("NFKC", raw_text if _BULLET.match(raw_text) else _CID.sub("", raw_text))
                size = statistics.median(w["size"] for w in ln)
                bold = all("bold" in w["fontname"].lower() for w in ln)
                top, bottom = min(w["top"] for w in ln), max(w["bottom"] for w in ln)
                prev = paras[-1] if paras else None
                if (prev and abs(prev["size"] - size) < 0.15 * size and top - prev["bottom"] < 0.55 * size
                        and not _BULLET.match(text)):
                    prev["text"] += " " + text
                    prev["bottom"] = bottom
                else:
                    paras.append({"top": top, "bottom": bottom, "text": text, "size": size, "bold": bold,
                                  "kind": "text", "bullet": None})
            for p in paras:
                m = _BULLET.match(p["text"])
                if m and len(m.group(2)) > 1:
                    p["bullet"], p["text"] = True, m.group(2)
                else:
                    p["bullet"] = False
                blocks.append((p["top"], "para", p))
            for im in page.images:
                try:
                    w, h = im["x1"] - im["x0"], im["bottom"] - im["top"]
                    if w < 24 or h < 24:
                        continue
                    box = (max(0, im["x0"]), max(0, im["top"]), min(page.width, im["x1"]), min(page.height, im["bottom"]))
                    pil = page.crop(box).to_image(resolution=150).original.convert("RGB")
                    blocks.append((im["top"], "image", (pil, w)))
                except Exception:
                    continue
            blocks.sort(key=lambda b: b[0])
            for _, kind, payload in blocks:
                if kind == "table":
                    ncols = max(len(r) for r in payload)
                    table = doc.add_table(rows=0, cols=ncols)
                    table.style = "Table Grid"
                    for r in payload:
                        cells = table.add_row().cells
                        for c, value in enumerate(r):
                            cells[c].text = unicodedata.normalize("NFKC", (value or "").strip())
                            if rtl_ratio(cells[c].text) >= 0.5:
                                _set_rtl(cells[c].paragraphs[0])
                    doc.add_paragraph()
                elif kind == "image":
                    pil, wpt = payload
                    buf = io.BytesIO()
                    pil.save(buf, "PNG")
                    buf.seek(0)
                    doc.add_picture(buf, width=min(Pt(wpt), content_w))
                else:
                    p = payload
                    ratio = p["size"] / body if body else 1
                    if ratio >= 1.25 and len(p["text"]) < 140:
                        level = 1 if ratio >= 1.6 else 2 if ratio >= 1.4 else 3
                        doc.add_heading(p["text"], level=level)
                        if rtl_ratio(p["text"]) >= 0.5:
                            _set_rtl(doc.paragraphs[-1])
                    elif p["bullet"]:
                        add_text_paragraph(doc, p["text"], style="List Bullet")
                    else:
                        add_text_paragraph(doc, p["text"], bold=p["bold"])
            if idx < total - 1:
                doc.add_page_break()
    doc.save(str(dst))


# -------------------------------------------------------------------- merge / split / ...

def merge(sources: list[Path], ctx: Context) -> list[Path]:
    import contextlib
    import pikepdf
    if len(sources) < 2:
        raise ConversionError("Choose at least two PDF files to merge")
    ctx.used("pikepdf")
    out = ctx.path("result.pdf")
    dst = pikepdf.new()
    with contextlib.ExitStack() as stack:
        for n, s in enumerate(sources):
            ctx.check()
            ctx.progress(n / len(sources), s.name)
            pdf = stack.enter_context(_pikepdf_open(s, ctx.opts.password))
            dst.pages.extend(pdf.pages)
        dst.save(out)
    return [out]


def extract_pages(src: Path, ctx: Context) -> list[Path]:
    import pikepdf
    ctx.used("pikepdf")
    with _pikepdf_open(src, ctx.opts.password) as pdf:
        idx = parse_pages(ctx.opts.page_spec, len(pdf.pages))
        dst = pikepdf.new()
        for i in idx:
            dst.pages.append(pdf.pages[i])
        out = ctx.path("result.pdf")
        dst.save(out)
    return [out]


def split(src: Path, ctx: Context) -> list[Path]:
    import pikepdf
    ctx.used("pikepdf")
    outs = []
    with _pikepdf_open(src, ctx.opts.password) as pdf:
        total = len(pdf.pages)
        if total > 3000:
            raise ConversionError("This PDF has too many pages to split into single files")
        digits = max(3, len(str(total)))
        for i in range(total):
            ctx.check()
            ctx.progress(i / total, f"Page {i + 1}")
            dst = pikepdf.new()
            dst.pages.append(pdf.pages[i])
            out = ctx.path(f"page_{i + 1:0{digits}d}.pdf")
            dst.save(out)
            outs.append(out)
    return outs


def rotate(src: Path, ctx: Context) -> list[Path]:
    ctx.used("pikepdf")
    angle = ctx.opts.angle % 360
    if angle not in (90, 180, 270):
        raise ConversionError("Rotation must be 90, 180 or 270 degrees")
    with _pikepdf_open(src, ctx.opts.password) as pdf:
        for i in parse_pages(ctx.opts.page_spec, len(pdf.pages)):
            pdf.pages[i].rotate(angle, relative=True)
        out = ctx.path("result.pdf")
        pdf.save(out)
    return [out]


def unlock(src: Path, ctx: Context) -> list[Path]:
    ctx.used("pikepdf")
    with _pikepdf_open(src, ctx.opts.password) as pdf:
        if not pdf.is_encrypted:
            ctx.warn("This PDF was not protected - a plain copy was made")
        out = ctx.path("result.pdf")
        pdf.save(out, encryption=False)
    return [out]


def images_to_pdf(sources: list[Path], ctx: Context) -> list[Path]:
    """One page per image, page size = image size. Several images -> one PDF."""
    import contextlib
    import pikepdf
    from PIL import ImageOps
    ctx.used("Pillow + pikepdf")
    dst = pikepdf.new()
    keep = []
    with contextlib.ExitStack() as stack:
        for n, s in enumerate(sources):
            ctx.check()
            ctx.progress(n / len(sources), s.name)
            img = img_backend.open_image(s)
            if getattr(img, "n_frames", 1) <= 1:
                img = ImageOps.exif_transpose(img)
            img = img_backend._fit(img, ctx.opts.max_side)
            dpi = 150
            data = img_backend.encode(img_backend._prepare(img, "pdf"), "pdf", ctx.opts.quality, True, dpi)
            one = pikepdf.open(io.BytesIO(data))
            stack.callback(one.close)
            dst.pages.extend(one.pages)
            keep.append(one)
        out = ctx.path("result.pdf")
        dst.save(out)
    return [out]


# ---------------------------------------------------------------------------- compress

IMAGE_STAGES = [(80, 220), (70, 170), (58, 130), (45, 100), (35, 75)]     # (jpeg quality, max dpi)
RASTER_STAGES = [(150, 60), (120, 50), (96, 42), (72, 36)]                 # (dpi, jpeg quality)


def _save_lossless(src: Path, dst: Path, password, strip: bool) -> int:
    import pikepdf
    with _pikepdf_open(src, password) as pdf:
        pdf.remove_unreferenced_resources()
        if strip:
            _strip_pdf(pdf)
        pdf.save(dst, compress_streams=True, recompress_flate=True,
                 object_stream_mode=pikepdf.ObjectStreamMode.generate)
    return dst.stat().st_size


def _recompress_images(src: Path, dst: Path, password, quality: int, max_dpi: int, strip: bool, ctx: Context) -> int:
    import pikepdf
    from pikepdf import Name, PdfImage
    from PIL import Image
    done: set = set()
    with _pikepdf_open(src, password) as pdf:
        pdf.remove_unreferenced_resources()
        for page in pdf.pages:
            ctx.check()
            try:
                w_in = float(page.mediabox[2] - page.mediabox[0]) / 72
                h_in = float(page.mediabox[3] - page.mediabox[1]) / 72
                imgs = list(page.images.items())
            except Exception:
                continue
            for _, raw in imgs:
                key = raw.objgen
                if key in done:
                    continue
                done.add(key)
                try:
                    if raw.get("/ImageMask") or raw.get("/BitsPerComponent") not in (8, None):
                        continue
                    filt = str(raw.get("/Filter", ""))
                    if any(f in filt for f in ("JBIG2", "CCITT", "JPX")):
                        continue
                    cs = str(raw.get("/ColorSpace", ""))
                    if "CMYK" in cs or "Separation" in cs or "DeviceN" in cs or "Lab" in cs:
                        continue
                    pim = PdfImage(raw)
                    pil = pim.as_pil_image()
                    if pil.mode not in ("RGB", "L"):
                        if pil.mode in ("P", "1"):
                            continue
                        pil = pil.convert("RGB")
                    dpi_est = max(pil.width / w_in, pil.height / h_in) if w_in and h_in else max_dpi
                    if dpi_est > max_dpi:
                        f = max_dpi / dpi_est
                        pil = pil.resize((max(1, int(pil.width * f)), max(1, int(pil.height * f))), Image.LANCZOS)
                    buf = io.BytesIO()
                    pil.save(buf, "JPEG", quality=quality, optimize=True)
                    data = buf.getvalue()
                    if len(data) >= len(raw.read_raw_bytes()) * 0.92:
                        continue
                    raw.write(data, filter=Name.DCTDecode)
                    raw.Width, raw.Height = pil.width, pil.height
                    raw.ColorSpace = Name.DeviceRGB if pil.mode == "RGB" else Name.DeviceGray
                    raw.BitsPerComponent = 8
                    for k in ("/DecodeParms", "/Decode"):
                        if k in raw:
                            del raw[k]
                except Exception:
                    continue
        if strip:
            _strip_pdf(pdf)
        pdf.save(dst, compress_streams=True, recompress_flate=True,
                 object_stream_mode=pikepdf.ObjectStreamMode.generate)
    return dst.stat().st_size


def _rasterize(src: Path, dst: Path, dpi: int, quality: int, password, ctx: Context) -> int:
    import pikepdf
    pdf = _pdfium(src, password)
    parts = []
    try:
        for i in range(len(pdf)):
            ctx.check()
            pil = pdf[i].render(scale=dpi / 72).to_pil().convert("RGB")
            part = dst.parent / f"_r{i:05d}.pdf"
            pil.save(part, "PDF", resolution=float(dpi), quality=quality)
            parts.append(part)
    finally:
        pdf.close()
    out = pikepdf.new()
    opened = [pikepdf.open(p) for p in parts]
    try:
        for o in opened:
            out.pages.extend(o.pages)
        out.save(dst, compress_streams=True)
    finally:
        for o in opened:
            o.close()
        for p in parts:
            p.unlink(missing_ok=True)
    return dst.stat().st_size


def compress(src: Path, ctx: Context) -> list[Path]:
    opts = ctx.opts
    target = opts.target_size
    ctx.used("pikepdf")
    best_path, best_size = None, None
    original = src.stat().st_size
    work = ctx.work

    def consider(path: Path, size: int) -> bool:
        nonlocal best_path, best_size
        if best_size is None or size < best_size:
            best_path, best_size = path, size
        return bool(target and size <= target)

    p0 = work / "c0.pdf"
    if consider(p0, _save_lossless(src, p0, opts.password, opts.strip_metadata)) and target:
        return [_finish(p0, work)]
    stages = IMAGE_STAGES if target else IMAGE_STAGES[:2]
    for n, (q, dpi) in enumerate(stages, 1):
        ctx.progress(n / (len(stages) + 3), f"Compressing images ({q}%)")
        p = work / f"c{n}.pdf"
        if consider(p, _recompress_images(src, p, opts.password, q, dpi, opts.strip_metadata, ctx)):
            return [_finish(p, work)]
        if not target and n == 2:
            break
    if not target:
        if best_size is not None and best_size >= original * 0.98:
            ctx.warn("This PDF is already well compressed - little could be saved")
        return [_finish(best_path, work)]
    for n, (dpi, q) in enumerate(RASTER_STAGES, 1):
        ctx.progress(0.6 + n * 0.1, f"Last resort: pages as images ({dpi} dpi)")
        p = work / f"r{n}.pdf"
        if consider(p, _rasterize(src, p, dpi, q, opts.password, ctx)):
            ctx.warn("To reach this size the pages were converted to images - text can no longer be selected")
            return [_finish(p, work)]
    raise TargetUnreachable(f"This PDF cannot be made smaller than {human_size(best_size or original)}")


def _finish(path: Path, work: Path) -> Path:
    out = work / "result.pdf"
    if path != out:
        path.replace(out)
    return out


def _strip_pdf(pdf) -> list[str]:
    removed = []
    for key in list(pdf.docinfo.keys()):
        removed.append(f"info:{str(key).lstrip('/')}")
        del pdf.docinfo[key]
    if "/Metadata" in pdf.Root:
        del pdf.Root["/Metadata"]
        removed.append("xmp")
    return removed
