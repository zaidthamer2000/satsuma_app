"""Archives: safe extraction (zip, tar, 7z, rar) and creation (zip, tar.gz, 7z)."""
from __future__ import annotations

import os
import shutil
import tarfile
import zipfile
from pathlib import Path
from typing import Optional

from .. import engines
from ..formats import Target, full_ext, kind_of
from ..model import ConversionError, Context, MissingEngine
from ..util import run_cmd

NAME = "archives"
MAX_TOTAL = 40 * 1024 ** 3
MAX_FILES = 300_000
PACK_FORMATS = ("zip", "tar.gz")


def pack_formats() -> list[str]:
    return list(PACK_FORMATS) + (["7z"] if engines.have_module("py7zr") else [])


def targets(path: Path) -> list[Target]:
    if kind_of(path) != "archive":
        return []
    src = full_ext(path)
    return [Target(t, NAME) for t in PACK_FORMATS if t != src]


def _inside(base: Path, name: str) -> Path:
    base = base.resolve()
    target = (base / name).resolve()
    if target != base and base not in target.parents:
        raise ConversionError(f"The archive contains an unsafe path and was not extracted: {name}")
    return target


def extract(src: Path, ctx: Context) -> list[Path]:
    """Extract into a new folder; returns [folder]."""
    dest = ctx.work / "extracted"
    dest.mkdir()
    ext = full_ext(src)
    ctx.used("Python archive support")
    pwd = ctx.opts.password.encode() if ctx.opts.password else None
    if ext == "zip":
        _extract_zip(src, dest, pwd, ctx)
    elif ext in ("tar", "tar.gz", "tgz", "tar.bz2", "tar.xz", "gz", "bz2", "xz"):
        _extract_tar_like(src, dest, ext, ctx)
    elif ext in ("7z", "rar"):
        _extract_with_7z(src, dest, ext, ctx)
    else:
        raise ConversionError(f"Cannot open .{ext} archives")
    if not any(dest.rglob("*")):
        raise ConversionError("The archive is empty")
    return [dest]


def _extract_zip(src: Path, dest: Path, pwd: Optional[bytes], ctx: Context) -> None:
    try:
        zf = zipfile.ZipFile(src)
    except zipfile.BadZipFile as exc:
        raise ConversionError("This is not a valid ZIP file (it may be damaged)") from exc
    with zf:
        infos = zf.infolist()
        if len(infos) > MAX_FILES or sum(i.file_size for i in infos) > MAX_TOTAL:
            raise ConversionError("This archive is unreasonably large and was not extracted")
        for n, info in enumerate(infos):
            ctx.check()
            ctx.progress(n / max(1, len(infos)), info.filename)
            target = _inside(dest, info.filename)
            if (info.external_attr >> 16) & 0o170000 == 0o120000:          # symlink entry: skip
                ctx.warn("Symbolic links inside the archive were skipped")
                continue
            if info.is_dir():
                target.mkdir(parents=True, exist_ok=True)
                continue
            target.parent.mkdir(parents=True, exist_ok=True)
            try:
                with zf.open(info, pwd=pwd) as s, open(target, "wb") as d:
                    shutil.copyfileobj(s, d, 1 << 20)
            except RuntimeError as exc:
                raise ConversionError("This ZIP is password-protected - enter the password") from exc
            except NotImplementedError as exc:
                raise ConversionError("This ZIP uses a compression method that is not supported here; "
                                      "install 7-Zip and try again") from exc


def _extract_tar_like(src: Path, dest: Path, ext: str, ctx: Context) -> None:
    if ext in ("gz", "bz2", "xz"):                                   # single compressed file
        import bz2, gzip, lzma
        opener = {"gz": gzip.open, "bz2": bz2.open, "xz": lzma.open}[ext]
        with opener(src, "rb") as s, open(dest / src.stem, "wb") as d:
            shutil.copyfileobj(s, d, 1 << 20)
        return
    try:
        tf = tarfile.open(src)
    except tarfile.TarError as exc:
        raise ConversionError("This is not a valid TAR archive") from exc
    with tf:
        members = tf.getmembers()
        if len(members) > MAX_FILES or sum(max(0, m.size) for m in members) > MAX_TOTAL:
            raise ConversionError("This archive is unreasonably large and was not extracted")
        for m in members:
            _inside(dest, m.name)
            if m.issym() or m.islnk() or m.isdev():
                ctx.warn("Links and special files inside the archive were skipped")
        safe = [m for m in members if m.isfile() or m.isdir()]
        for n, m in enumerate(safe):
            ctx.check()
            ctx.progress(n / max(1, len(safe)), m.name)
            tf.extract(m, dest, **({"filter": "data"} if hasattr(tarfile, "data_filter") else {}))


def _extract_with_7z(src: Path, dest: Path, ext: str, ctx: Context) -> None:
    if ext == "7z" and engines.have_module("py7zr"):
        import py7zr
        try:
            with py7zr.SevenZipFile(src, password=ctx.opts.password or None) as z:
                for name in z.getnames():
                    _inside(dest, name)
                z.extractall(dest)
            return
        except py7zr.exceptions.PasswordRequired as exc:
            raise ConversionError("This archive is password-protected - enter the password") from exc
    exe = engines.find("7z")
    if not exe:
        raise MissingEngine("7-Zip", "install it with: winget install 7zip.7zip" if os.name == "nt" else "install 7-Zip")
    ctx.used("7-Zip")
    pw = f"-p{ctx.opts.password}" if ctx.opts.password else "-p-"
    rc, out, err = run_cmd([exe, "x", "-y", "-aoa", f"-o{dest}", pw, src], ctx, timeout=3600)
    if rc != 0:
        raise ConversionError("Could not extract the archive: " + (err.strip().splitlines() or out.strip().splitlines() or ["unknown error"])[-1])


# ----------------------------------------------------------------------------- create

def pack(sources: list[Path], fmt: str, ctx: Context) -> list[Path]:
    if fmt not in pack_formats():
        raise ConversionError(f"Cannot create .{fmt} archives here")
    ctx.used("Python archive support")
    out = ctx.path(f"result.{fmt}")
    entries: list[tuple[Path, str]] = []
    for s in sources:
        if s.is_dir():
            for f in sorted(s.rglob("*")):
                if f.is_file():
                    entries.append((f, str(Path(s.name) / f.relative_to(s))))
        else:
            entries.append((s, s.name))
    if not entries:
        raise ConversionError("There is nothing to archive")
    if fmt == "zip":
        with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED, compresslevel=6, allowZip64=True) as z:
            for n, (f, arc) in enumerate(entries):
                ctx.check()
                ctx.progress(n / len(entries), arc)
                z.write(f, arc.replace("\\", "/"))
    elif fmt == "tar.gz":
        with tarfile.open(out, "w:gz", compresslevel=6) as t:
            for n, (f, arc) in enumerate(entries):
                ctx.check()
                ctx.progress(n / len(entries), arc)
                t.add(f, arcname=arc.replace("\\", "/"), recursive=False)
    else:
        import py7zr
        with py7zr.SevenZipFile(out, "w") as z:
            for f, arc in entries:
                ctx.check()
                z.write(f, arc.replace("\\", "/"))
    return [out]


def convert(src: Path, ext: str, ctx: Context) -> list[Path]:
    """Archive -> archive: extract to a scratch folder and pack again."""
    folder = extract(src, ctx)[0]
    children = sorted(folder.iterdir())
    return pack(children, ext, ctx)
