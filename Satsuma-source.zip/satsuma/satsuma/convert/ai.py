"""Speech to text with faster-whisper (offline after the one-time model download)."""
from __future__ import annotations

from pathlib import Path
from typing import Iterable

from .. import engines
from ..formats import Target, kind_of
from ..model import ConversionError, Context, MissingEngine
from ..util import data_dir, run_cmd

NAME = "ai"
OUT_FORMATS = ("txt", "srt", "vtt")
MODELS = ("tiny", "base", "small", "medium", "large-v3")


def targets(path: Path) -> list[Target]:
    if kind_of(path) not in ("audio", "video"):
        return []
    ok = engines.have_module("faster_whisper") and engines.available("ffmpeg")
    miss = "" if ok else ("faster-whisper" if not engines.have_module("faster_whisper") else "FFmpeg")
    return [Target(t, NAME, ok, miss) for t in OUT_FORMATS]


def _clock(seconds: float, sep: str) -> str:
    ms = int(round(seconds * 1000))
    h, ms = divmod(ms, 3_600_000)
    m, ms = divmod(ms, 60_000)
    s, ms = divmod(ms, 1000)
    return f"{h:02d}:{m:02d}:{s:02d}{sep}{ms:03d}"


def format_segments(segments: Iterable[tuple[float, float, str]], fmt: str) -> str:
    segs = [(a, b, t.strip()) for a, b, t in segments if t.strip()]
    if fmt == "txt":
        return "\n".join(t for _, _, t in segs) + "\n"
    if fmt == "srt":
        return "\n".join(f"{i}\n{_clock(a, ',')} --> {_clock(b, ',')}\n{t}\n" for i, (a, b, t) in enumerate(segs, 1))
    if fmt == "vtt":
        body = "\n".join(f"{_clock(a, '.')} --> {_clock(b, '.')}\n{t}\n" for a, b, t in segs)
        return "WEBVTT\n\n" + body
    raise ConversionError(f"Unsupported transcript format: {fmt}")


def transcribe(src: Path, ext: str, ctx: Context) -> list[Path]:
    if not engines.have_module("faster_whisper"):
        raise MissingEngine("faster-whisper", "pip install faster-whisper")
    ffmpeg = engines.require("ffmpeg")
    opts = ctx.opts
    wav = ctx.path("speech.wav")
    ctx.progress(0.02, "Preparing audio")
    rc, _, err = run_cmd([ffmpeg, "-hide_banner", "-nostdin", "-y", "-i", src, "-vn", "-ac", "1", "-ar", "16000",
                          "-c:a", "pcm_s16le", wav], ctx, timeout=7200)
    if rc != 0 or not wav.exists():
        raise ConversionError("This file has no audio that can be read")
    from faster_whisper import WhisperModel  # type: ignore
    ctx.used("faster-whisper")
    model_dir = data_dir() / "models" / "whisper"
    model_dir.mkdir(parents=True, exist_ok=True)
    ctx.progress(0.05, "Loading the speech model (first use downloads it once)")
    try:
        model = WhisperModel(opts.whisper_model, device="auto", compute_type="int8", download_root=str(model_dir))
        segments, info = model.transcribe(str(wav), language=opts.language or None, vad_filter=True, beam_size=5)
    except Exception as exc:
        raise ConversionError(f"The speech model could not be loaded: {exc}") from exc
    collected = []
    total = float(getattr(info, "duration", 0) or 0)
    for seg in segments:
        ctx.check()
        collected.append((seg.start, seg.end, seg.text))
        if total:
            ctx.progress(0.1 + 0.88 * min(1.0, seg.end / total), "Transcribing")
    if not collected:
        ctx.warn("No speech was detected")
    out = ctx.path(f"result.{ext}")
    out.write_text(format_segments(collected, ext), encoding="utf-8-sig" if ext == "txt" else "utf-8")
    return [out]
