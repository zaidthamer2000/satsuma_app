"""Office documents, e-books and markup: LibreOffice, Pandoc and Calibre (whichever are installed)."""
from __future__ import annotations

import shutil
import threading
from pathlib import Path
from typing import Optional

from .. import engines
from ..formats import Target, canon
from ..model import ConversionError, Context, MissingEngine
from ..util import data_dir, is_ascii, run_cmd, tmp_base, ext_of, IS_WINDOWS

NAME = "documents"
_LO_LOCK = threading.Lock()          # one LibreOffice at a time (it shares a profile)

LO_TEXT_SRC = {"doc", "docx", "odt", "rtf", "txt", "html"}
LO_SHEET_SRC = {"xls", "xlsx", "ods", "csv"}
LO_SLIDE_SRC = {"ppt", "pptx", "odp"}
LO_DRAW_SRC = {"svg"}
LO_OUT = {"text": ["pdf", "docx", "odt", "rtf", "txt", "html"],
          "sheet": ["pdf", "xlsx", "ods", "csv", "html"],
          "slide": ["pdf", "pptx", "odp"],
          "draw": ["png", "pdf"]}
LO_FILTER = {"pdf": "pdf", "docx": "docx:MS Word 2007 XML", "odt": "odt", "rtf": "rtf",
             "txt": "txt:Text (encoded):UTF8", "html": "html", "xlsx": "xlsx:Calc MS Excel 2007 XML",
             "ods": "ods", "csv": "csv:Text - txt - csv (StarCalc):44,34,76,1",
             "pptx": "pptx:Impress MS PowerPoint 2007 XML", "odp": "odp", "png": "png"}

PANDOC_SRC = {"md": "markdown", "html": "html", "docx": "docx", "odt": "odt", "epub": "epub",
              "rst": "rst", "tex": "latex"}
PANDOC_OUT = {"docx": ["docx"], "html": ["html5", "-s"], "md": ["markdown"], "epub": ["epub3"],
              "odt": ["odt"], "txt": ["plain"], "rst": ["rst"]}
CALIBRE_SRC = {"epub", "mobi", "azw", "azw3", "fb2"}
CALIBRE_OUT = ["epub", "mobi", "azw3", "pdf", "docx", "txt", "fb2"]
PANDOC_FIRST = {"html", "txt", "md", "epub", "rst"}


def _lo_kind(ext: str) -> Optional[str]:
    for kind, group in (("text", LO_TEXT_SRC), ("sheet", LO_SHEET_SRC), ("slide", LO_SLIDE_SRC),
                        ("draw", LO_DRAW_SRC)):
        if ext in group:
            return kind
    return None


def _candidates(src: str, tgt: str) -> list[str]:
    """Engines that could do src -> tgt, best first."""
    options: list[str] = []
    kind = _lo_kind(src)
    if kind and tgt in LO_OUT[kind]:
        options.append("soffice")
    if src in PANDOC_SRC and tgt in PANDOC_OUT:
        options.append("pandoc")
    if src in CALIBRE_SRC and tgt in CALIBRE_OUT:
        options.append("ebook-convert")
    if tgt in PANDOC_FIRST and "pandoc" in options:
        options.remove("pandoc")
        options.insert(0, "pandoc")
    return options


def _all_targets(src: str) -> list[str]:
    result: list[str] = []
    kind = _lo_kind(src)
    if kind:
        result += LO_OUT[kind]
    if src in PANDOC_SRC:
        result += list(PANDOC_OUT)
        if "pdf" not in result:
            result.append("pdf")                       # via DOCX
    if src in CALIBRE_SRC:
        result += CALIBRE_OUT
    seen, ordered = set(), []
    for t in result:
        if t != src and t not in seen:
            seen.add(t)
            ordered.append(t)
    return ordered


def _route(src: str, tgt: str) -> list[tuple[str, str]]:
    """Steps [(engine, target_ext)] using only installed engines; [] when impossible."""
    for eng in _candidates(src, tgt):
        if engines.available(eng):
            return [(eng, tgt)]
    if src in PANDOC_SRC and tgt in LO_OUT["text"] and engines.available("pandoc") and engines.available("soffice"):
        return [("pandoc", "docx"), ("soffice", tgt)]      # e.g. Markdown -> DOCX -> PDF
    return []


def targets(path: Path) -> list[Target]:
    src = canon(ext_of(path))
    out = []
    for tgt in _all_targets(src):
        if _route(src, tgt):
            out.append(Target(tgt, NAME))
        else:
            need = _candidates(src, tgt)
            names = {"soffice": "LibreOffice", "pandoc": "Pandoc", "ebook-convert": "Calibre"}
            if not need and src in PANDOC_SRC:
                need = ["pandoc", "soffice"]
            out.append(Target(tgt, NAME, False, " / ".join(names[n] for n in need[:2]) or "LibreOffice"))
    return out


# ------------------------------------------------------------------------------ engines

def _profile_dir() -> Path:
    base = data_dir() / "lo-profile"
    if IS_WINDOWS and not is_ascii(base):
        base = Path(tmp_base(True) or base) / "lo-profile"
    base.parent.mkdir(parents=True, exist_ok=True)
    return base


def _soffice(src: Path, tgt: str, ctx: Context, infilter: Optional[str] = None, src_ext: Optional[str] = None) -> Path:
    exe = engines.require("soffice")
    ctx.used("LibreOffice")
    ext = src_ext or ext_of(src)
    indir, outdir = ctx.work / "lo_in", ctx.work / "lo_out"
    indir.mkdir(exist_ok=True)
    outdir.mkdir(exist_ok=True)
    tmp_in = indir / f"src.{ext}"
    shutil.copy2(src, tmp_in)
    profile = _profile_dir()
    args = [exe, f"-env:UserInstallation={profile.as_uri()}", "--headless", "--norestore", "--nolockcheck",
            "--nodefault", "--nofirststartwizard"]
    if infilter:
        args.append(f"--infilter={infilter}")
    args += ["--convert-to", LO_FILTER[tgt], "--outdir", outdir, tmp_in]
    ctx.progress(0.1, "LibreOffice is working (the first run is slower)")
    ok = False
    try:
        with _LO_LOCK:
            rc, out, err = run_cmd(args, ctx, timeout=900)
        result = outdir / f"src.{tgt}"
        if not result.exists():
            detail = " | ".join(x for x in (err.strip().splitlines()[-1:] + out.strip().splitlines()[-1:]) if x)
            raise ConversionError(f"LibreOffice could not convert this file{': ' + detail if detail else ''}")
        ok = True
        final = ctx.work / f"lo_result.{tgt}"
        result.replace(final)
        return final
    finally:
        if not ok:                                   # a killed run can leave a broken profile behind
            shutil.rmtree(profile, ignore_errors=True)


def _pandoc(src: Path, src_ext: str, tgt: str, ctx: Context) -> Path:
    exe = engines.require("pandoc")
    ctx.used("Pandoc")
    out = ctx.work / f"pandoc_result.{tgt}"
    cmd = [exe, "-f", PANDOC_SRC[src_ext], "-t", PANDOC_OUT[tgt][0], *PANDOC_OUT[tgt][1:],
           "-o", out, "--wrap=none", src]
    if tgt == "html":
        cmd += ["--metadata", f"title={src.stem}"]
    rc, _, err = run_cmd(cmd, ctx, timeout=600, cwd=src.parent)
    if rc != 0 or not out.exists():
        raise ConversionError(f"Pandoc could not convert this file: {err.strip().splitlines()[-1:] or ''}")
    return out


def _calibre(src: Path, tgt: str, ctx: Context) -> Path:
    exe = engines.require("ebook-convert")
    ctx.used("Calibre")
    out = ctx.work / f"calibre_result.{tgt}"
    rc, _, err = run_cmd([exe, src, out], ctx, timeout=1800)
    if rc != 0 or not out.exists():
        raise ConversionError(f"Calibre could not convert this file: {err.strip().splitlines()[-1:] or ''}")
    return out


def convert(src: Path, ext: str, ctx: Context) -> list[Path]:
    s, t = canon(ext_of(src)), canon(ext)
    steps = _route(s, t)
    if not steps:
        cand = _candidates(s, t) or ["soffice"]
        raise MissingEngine({"soffice": "LibreOffice", "pandoc": "Pandoc", "ebook-convert": "Calibre"}[cand[0]],
                            "install it (winget) or put it in the tools folder")
    current, current_ext = src, s
    for n, (eng, tgt) in enumerate(steps):
        ctx.check()
        if eng == "soffice":
            current = _soffice(current, tgt, ctx, src_ext=current_ext)
        elif eng == "pandoc":
            current = _pandoc(current, current_ext, tgt, ctx)
        else:
            current = _calibre(current, tgt, ctx)
        current_ext = tgt
    if t == "csv" and s in ("xls", "xlsx", "ods"):
        ctx.warn("Only the first sheet is exported to CSV")
    if t == "html" and s in LO_TEXT_SRC | LO_SHEET_SRC:
        ctx.warn("Images and styles may be stored in separate files by LibreOffice's HTML export")
    return [current]


def pdf_layout_to_docx(src: Path, ctx: Context) -> list[Path]:
    """Faithful layout (text boxes) through LibreOffice - looks identical, edits less nicely."""
    if not engines.available("soffice"):
        raise MissingEngine("LibreOffice", "needed for the 'layout' mode")
    ctx.warn("Layout mode keeps the look of the PDF but pieces of text may be in text boxes")
    return [_soffice(src, "docx", ctx, infilter="writer_pdf_import", src_ext="pdf")]
