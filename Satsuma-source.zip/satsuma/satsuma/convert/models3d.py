"""3D models through trimesh (experimental): STL, OBJ, PLY, GLB, OFF."""
from __future__ import annotations

from pathlib import Path

from .. import engines
from ..formats import MODEL3D, Target, canon
from ..model import ConversionError, Context, MissingEngine
from ..util import ext_of

NAME = "3d"
OUT = ["stl", "obj", "ply", "glb", "off"]


def targets(path: Path) -> list[Target]:
    src = canon(ext_of(path))
    if src not in MODEL3D:
        return []
    ok = engines.have_module("trimesh")
    return [Target(t, NAME, ok, "" if ok else "trimesh") for t in OUT if t != src]


def convert(src: Path, ext: str, ctx: Context) -> list[Path]:
    if not engines.have_module("trimesh"):
        raise MissingEngine("trimesh", "pip install trimesh")
    import trimesh
    ctx.used("trimesh")
    ctx.warn("3D conversion is experimental - check the result in a 3D viewer")
    try:
        scene = trimesh.load(str(src))
        out = ctx.path(f"result.{ext}")
        scene.export(str(out))
    except Exception as exc:
        raise ConversionError(f"This 3D model could not be converted: {exc}") from exc
    return [out]
