"""Remove hidden metadata (EXIF/GPS, PDF info, Office authors, media tags) and report what was found."""
from __future__ import annotations

import io
import zipfile
from pathlib import Path

from PIL import Image

from ..formats import Target, canon, kind_of
from ..model import ConversionError, Context
from ..util import ext_of
from . import av, images, pdfs

NAME = "metadata"
OOXML = {"docx", "xlsx", "pptx"}
ODF = {"odt", "ods", "odp"}
EXIF_NAMES = {271: "camera make", 272: "camera model", 305: "software", 306: "date taken/modified",
              315: "author", 33432: "copyright", 270: "description", 37510: "user comment",
              42036: "lens", 42033: "camera serial number"}


def supported(path: Path) -> bool:
    ext = canon(ext_of(path))
    kind = kind_of(path)
    return kind in ("image", "pdf", "audio", "video") or ext in OOXML | ODF


def inspect_image(img: Image.Image) -> list[str]:
    found = []
    try:
        exif = img.getexif()
    except Exception:
        exif = {}
    if exif:
        if 0x8825 in exif and exif.get_ifd(0x8825):
            found.append("GPS location")
        for tag, name in EXIF_NAMES.items():
            if tag in exif:
                found.append(name)
    info_keys = {str(k).lower() for k in img.info}
    if any(k.startswith("xml:com.adobe.xmp") or k == "xmp" for k in info_keys):
        found.append("XMP data")
    if "icc_profile" in info_keys:
        found.append("colour profile (kept unless you strip everything)")
    text = getattr(img, "text", None) or {}
    for k in text:
        found.append(f"text chunk: {k}")
    return found


def strip(src: Path, ctx: Context) -> list[Path]:
    kind, ext = kind_of(src), canon(ext_of(src))
    ctx.progress(0.1, "Looking for hidden data")
    if kind == "image":
        return _strip_image(src, ext, ctx)
    if kind == "pdf":
        return _strip_pdf(src, ctx)
    if kind in ("audio", "video"):
        return av.strip_metadata(src, ctx)
    if ext in OOXML:
        return _strip_ooxml(src, ext, ctx)
    if ext in ODF:
        return _strip_odf(src, ext, ctx)
    raise ConversionError("Metadata removal is supported for images, PDFs, Office/OpenDocument files, audio and video")


def _strip_image(src: Path, ext: str, ctx: Context) -> list[Path]:
    img = images.open_image(src)
    for item in inspect_image(img):
        ctx.note("metadata_removed", item)
    out_ext = ext if ext in images.PIL_FORMAT and ext not in ("heic", "ico", "pdf") else "png"
    ctx.opts = ctx.opts.but(strip_metadata=True)
    if out_ext == "jpg" and img.format == "JPEG" and getattr(img, "n_frames", 1) == 1:
        # Re-save with the original quantisation tables: no visible quality loss
        from PIL import ImageOps
        buf = io.BytesIO()
        clean = ImageOps.exif_transpose(img)
        try:
            clean.save(buf, "JPEG", quality="keep", subsampling="keep", optimize=True)
        except (ValueError, OSError):
            clean.save(buf, "JPEG", quality=95, optimize=True)
        out = ctx.path("result.jpg")
        out.write_bytes(buf.getvalue())
        ctx.used("Pillow")
        return [out]
    return images.convert(src, out_ext, ctx)


def _strip_pdf(src: Path, ctx: Context) -> list[Path]:
    import pikepdf
    ctx.used("pikepdf")
    with pdfs._pikepdf_open(src, ctx.opts.password) as pdf:
        for item in pdfs._strip_pdf(pdf):
            ctx.note("metadata_removed", item)
        out = ctx.path("result.pdf")
        pdf.save(out, compress_streams=True, object_stream_mode=pikepdf.ObjectStreamMode.generate)
    return [out]


_OOXML_BLANK = {"creator", "lastModifiedBy", "title", "subject", "description", "keywords", "category",
                "Company", "Manager", "contentStatus", "identifier", "language", "revision", "Template"}
_ODF_BLANK = {"creator", "initial-creator", "title", "subject", "description", "keyword", "generator",
              "creation-date", "date", "editing-duration", "user-defined", "print-date", "printed-by"}


def _rewrite_zip(src: Path, dst: Path, targets: dict, blank: set, ctx: Context) -> None:
    from lxml import etree
    with zipfile.ZipFile(src) as zin, zipfile.ZipFile(dst, "w") as zout:
        for item in zin.infolist():
            data = zin.read(item.filename)
            if item.filename in targets:
                try:
                    root = etree.fromstring(data)
                    for el in root.iter():
                        name = etree.QName(el).localname if isinstance(el.tag, str) else ""
                        if name in blank and (el.text or "").strip():
                            ctx.note("metadata_removed", f"{name}: {el.text.strip()[:40]}")
                            el.text = ""
                    data = etree.tostring(root, xml_declaration=True, encoding="UTF-8", standalone=True)
                except etree.XMLSyntaxError:
                    pass
            zout.writestr(item, data, compress_type=item.compress_type)


def _strip_ooxml(src: Path, ext: str, ctx: Context) -> list[Path]:
    out = ctx.path(f"result.{ext}")
    _rewrite_zip(src, out, {"docProps/core.xml", "docProps/app.xml"}, _OOXML_BLANK, ctx)
    ctx.used("zip + XML")
    ctx.warn("Comment and tracked-change author names inside the document body are not changed")
    return [out]


def _strip_odf(src: Path, ext: str, ctx: Context) -> list[Path]:
    out = ctx.path(f"result.{ext}")
    _rewrite_zip(src, out, {"meta.xml"}, _ODF_BLANK, ctx)
    ctx.used("zip + XML")
    return [out]
