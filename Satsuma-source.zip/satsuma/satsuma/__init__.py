"""Satsuma - an offline, open-source file converter and toolbox."""
__version__ = "1.0.0"
APP_NAME = "Satsuma"
