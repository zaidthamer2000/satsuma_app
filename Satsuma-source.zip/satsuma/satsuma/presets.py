"""Built-in and user presets: one click = a chain of steps plus option overrides."""
from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path

from .core import Step
from .formats import kind_of
from .model import Options
from .util import data_dir

MB, KB = 1024 ** 2, 1024


@dataclass
class Preset:
    id: str
    name: str
    name_ar: str
    steps: list[Step]
    options: dict = field(default_factory=dict)
    kinds: tuple = ()                    # empty = any
    builtin: bool = True

    def applies_to(self, paths) -> bool:
        return not self.kinds or all(kind_of(p) in self.kinds for p in paths)

    def apply(self, base: Options) -> Options:
        return base.but(**self.options)

    def to_dict(self) -> dict:
        return {"id": self.id, "name": self.name, "name_ar": self.name_ar, "options": self.options,
                "kinds": list(self.kinds), "steps": [s.to_dict() for s in self.steps]}

    @classmethod
    def from_dict(cls, d: dict) -> "Preset":
        return cls(d["id"], d["name"], d.get("name_ar") or d["name"], [Step.from_dict(s) for s in d["steps"]],
                   d.get("options", {}), tuple(d.get("kinds", ())), builtin=False)


def _p(id, name, name_ar, steps, options=None, kinds=()):
    return Preset(id, name, name_ar, steps, options or {}, tuple(kinds))


BUILTIN = [
    _p("whatsapp_photo", "Photo for WhatsApp / chat", "صورة للواتساب",
       [Step("convert", "jpg")], {"max_side": 1600, "quality": 80, "strip_metadata": True}, ["image"]),
    _p("instagram_post", "Instagram post (1080 px)", "منشور إنستغرام",
       [Step("convert", "jpg")], {"max_side": 1080, "quality": 90, "strip_metadata": True}, ["image"]),
    _p("web_image", "Web image (WebP)", "صورة للويب (WebP)",
       [Step("convert", "webp")], {"max_side": 2000, "quality": 82, "strip_metadata": True}, ["image"]),
    _p("upload_500kb", "Upload form: at most 500 KB", "نموذج تقديم: حتى 500 كيلوبايت",
       [Step("compress")], {"target_size": 500 * KB}, ["image", "pdf"]),
    _p("upload_1mb", "Upload form: at most 1 MB", "نموذج تقديم: حتى 1 ميغابايت",
       [Step("compress")], {"target_size": 1 * MB}, ["image", "pdf"]),
    _p("upload_2mb", "Upload form: at most 2 MB", "نموذج تقديم: حتى 2 ميغابايت",
       [Step("compress")], {"target_size": 2 * MB}, ["image", "pdf"]),
    _p("email_5mb", "Email attachment: at most 5 MB", "مرفق بريد: حتى 5 ميغابايت",
       [Step("compress")], {"target_size": 5 * MB}, ["image", "pdf", "video", "audio"]),
    _p("video_whatsapp", "Video for WhatsApp (about 15 MB)", "فيديو للواتساب (حوالي 15 ميغابايت)",
       [Step("compress")], {"target_size": 15 * MB, "video_height": 720}, ["video"]),
    _p("privacy_clean", "Remove hidden data (privacy)", "إزالة البيانات الخفية (الخصوصية)",
       [Step("strip_metadata")], {}, ["image", "pdf", "video", "audio", "office"]),
    _p("scan_searchable", "Scan to searchable PDF (OCR)", "مسح ضوئي إلى PDF قابل للبحث",
       [Step("ocr", "pdf")], {"ocr_langs": "ara+eng"}, ["image", "pdf"]),
    _p("pdf_to_word", "PDF to Word", "PDF إلى Word", [Step("convert", "docx")], {}, ["pdf"]),
    _p("to_mp3", "Audio to MP3", "صوت إلى MP3", [Step("convert", "mp3")], {"audio_bitrate_k": 192},
       ["audio", "video"]),
    _p("transcribe_text", "Speech to text", "تفريغ الصوت إلى نص", [Step("transcribe", "txt")], {},
       ["audio", "video"]),
]


def user_file() -> Path:
    return data_dir() / "presets.json"


def load_user() -> list[Preset]:
    try:
        raw = json.loads(user_file().read_text(encoding="utf-8"))
        return [Preset.from_dict(d) for d in raw]
    except (OSError, ValueError, KeyError):
        return []


def save_user(presets: list[Preset]) -> None:
    tmp = user_file().with_suffix(".tmp")
    tmp.write_text(json.dumps([p.to_dict() for p in presets], ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(user_file())


def all_presets() -> list[Preset]:
    return BUILTIN + load_user()


def find(preset_id: str) -> Preset:
    for p in all_presets():
        if p.id == preset_id:
            return p
    raise KeyError(preset_id)


def for_paths(paths) -> list[Preset]:
    return [p for p in all_presets() if p.applies_to(paths)]
