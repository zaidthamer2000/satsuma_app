"""Command line: everything the app can do, scriptable (PowerShell, batch files, Task Scheduler)."""
from __future__ import annotations

import argparse
import json
import signal
import sys
import threading
import time
from pathlib import Path

from . import __version__, core, engines, history, presets
from .core import Step
from .model import Options
from .util import human_size, parse_size

EXIT_OK, EXIT_FAIL, EXIT_CANCEL = 0, 1, 130


def _utf8_console() -> None:
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")      # Arabic names on cp1252 consoles
        except (AttributeError, ValueError):
            pass


def _size(value: str) -> int:
    try:
        return parse_size(value)
    except ValueError as exc:
        raise argparse.ArgumentTypeError(str(exc))


def _common(p: argparse.ArgumentParser) -> None:
    p.add_argument("files", nargs="+", type=Path, help="input files")
    p.add_argument("--out", type=Path, help="output folder (default: next to each original)")
    p.add_argument("--suffix", help="text added to the output file name")
    p.add_argument("--size", type=_size, metavar="2MB", help="make the result at most this big")
    p.add_argument("--quality", type=int, metavar="1-100", help="quality for JPG/WebP/AVIF")
    p.add_argument("--max-side", type=int, metavar="PX", help="longest image side in pixels")
    p.add_argument("--strip", action="store_true", help="remove hidden data (EXIF/GPS, author ...)")
    p.add_argument("--password", help="password of the input file")
    p.add_argument("--pages", help="page list such as 1-3,5,8-")
    p.add_argument("--lang", help="OCR languages, e.g. ara+eng")
    p.add_argument("--download-langs", action="store_true", help="allow downloading missing OCR language data")
    p.add_argument("--json", action="store_true", help="machine-readable output")
    p.add_argument("--quiet", action="store_true", help="print nothing but errors")
    p.add_argument("--notify", action="store_true", help="show failures in a message box (Windows)")


def _options(a) -> Options:
    o = Options()
    ch = {}
    if getattr(a, "out", None):
        ch["out_dir"] = a.out
    if getattr(a, "suffix", None) is not None:
        ch["suffix"] = a.suffix
    if getattr(a, "size", None):
        ch["target_size"] = a.size
    if getattr(a, "quality", None):
        ch["quality"] = max(1, min(100, a.quality))
    if getattr(a, "max_side", None):
        ch["max_side"] = a.max_side
    if getattr(a, "strip", False):
        ch["strip_metadata"] = True
    if getattr(a, "password", None):
        ch["password"] = a.password
    if getattr(a, "pages", None):
        ch["page_spec"] = a.pages
    if getattr(a, "lang", None):
        ch["ocr_langs"] = a.lang
    if getattr(a, "download_langs", False):
        ch["allow_download"] = True
    for name, key in (("angle", "angle"), ("scale", "scale"), ("model", "whisper_model"),
                      ("language", "language"), ("dpi", "render_dpi"), ("word_mode", "pdf_word_mode"),
                      ("crf", "video_crf"), ("height", "video_height")):
        if getattr(a, name, None) is not None:
            ch[key] = getattr(a, name)
    return o.but(**ch)


def _run(a, steps: list[Step], opts: Options = None) -> int:
    opts = opts or _options(a)
    files = list(a.files)
    cancel = threading.Event()
    signal.signal(signal.SIGINT, lambda *_: cancel.set())
    tty = bool(sys.stdout) and sys.stdout.isatty() and not a.quiet and not a.json

    def progress(i, n, frac, msg):
        if tty:
            sys.stdout.write(f"\r[{i + 1}/{n}] {int(frac * 100):3d}%  {msg[:50]:50}")
            sys.stdout.flush()

    results = core.run_batch(files, steps, opts, cancel=cancel, progress=progress)
    if tty:
        sys.stdout.write("\r" + " " * 72 + "\r")
    code = EXIT_OK
    if a.json:
        print(json.dumps([{"ok": r.ok, "sources": [str(s) for s in r.sources], "outputs": [str(o) for o in r.outputs],
                           "error": r.error, "warnings": r.warnings, "seconds": round(r.seconds, 2),
                           "job_id": r.job_id} for r in results], ensure_ascii=False, indent=2))
    for r in results:
        if r.cancelled:
            code = EXIT_CANCEL
        elif not r.ok:
            code = EXIT_FAIL if code != EXIT_CANCEL else code
        if a.json:
            continue
        names = ", ".join(s.name for s in r.sources)
        if r.ok:
            if not a.quiet:
                before = sum(s.stat().st_size for s in r.sources if s.is_file())
                for o in r.outputs:
                    after = o.stat().st_size if o.is_file() else sum(f.stat().st_size for f in o.rglob("*") if f.is_file())
                    print(f"OK    {names}  ->  {o}   ({human_size(before)} -> {human_size(after)}, {r.seconds:.1f}s)")
                for w in r.warnings:
                    print(f"      note: {w}")
        else:
            print(f"FAIL  {names}: {r.error}", file=sys.stderr)
            miss = r.report.get("missing_languages")
            if miss:
                print("      add --download-langs to fetch the language data once", file=sys.stderr)
    failed = [r for r in results if not r.ok and not r.cancelled]
    if failed and getattr(a, "notify", False):
        _message_box("Satsuma", "\n".join(f"{', '.join(x.name for x in r.sources)}: {r.error}" for r in failed))
    if len(results) < len(files) and not any(r.cancelled for r in results) and steps and not core.ACTIONS[steps[0].action].multi:
        code = EXIT_CANCEL
    return code


def _message_box(title: str, text: str) -> None:
    if sys.platform != "win32":
        return
    try:
        import ctypes
        ctypes.windll.user32.MessageBoxW(0, text[:1500], title, 0x10)      # MB_ICONERROR
    except Exception:
        pass


def build_parser() -> argparse.ArgumentParser:
    ap = argparse.ArgumentParser(prog="satsuma", description="Satsuma - offline file converter and toolbox")
    ap.add_argument("--version", action="version", version=f"Satsuma {__version__}")
    sub = ap.add_subparsers(dest="cmd")

    p = sub.add_parser("convert", help="convert files to another format"); _common(p)
    p.add_argument("--to", required=True, help="target format, e.g. pdf, jpg, mp3, docx")
    p.add_argument("--word-mode", choices=["auto", "editable", "layout", "ocr"], help="PDF to Word method")
    p.add_argument("--dpi", type=int, help="render resolution for PDF to image")
    p.add_argument("--crf", type=int, help="video quality (lower = better, default 23)")
    p.add_argument("--height", type=int, help="video height in pixels")

    p = sub.add_parser("compress", help="make files smaller (optionally up to a maximum size)"); _common(p)
    p = sub.add_parser("clean", help="remove hidden data (EXIF/GPS, authors, tags)"); _common(p)
    p = sub.add_parser("ocr", help="recognise text in images and scanned PDFs"); _common(p)
    p.add_argument("--to", default="txt", choices=["txt", "docx", "pdf"])
    p.add_argument("--dpi", type=int)
    p = sub.add_parser("transcribe", help="speech to text (needs faster-whisper)"); _common(p)
    p.add_argument("--to", default="txt", choices=["txt", "srt", "vtt"])
    p.add_argument("--model", choices=["tiny", "base", "small", "medium", "large-v3"])
    p.add_argument("--language", help="spoken language code such as ar, en (default: auto-detect)")
    p = sub.add_parser("bg", help="remove the background of images"); _common(p)
    p = sub.add_parser("upscale", help="enlarge images"); _common(p)
    p.add_argument("--scale", type=int, choices=[2, 3, 4])
    p = sub.add_parser("pdf", help="PDF tools: merge, split, extract, rotate, unlock")
    p.add_argument("op", choices=["merge", "split", "extract", "rotate", "unlock"]); _common(p)
    p.add_argument("--angle", type=int, choices=[90, 180, 270])
    p = sub.add_parser("images2pdf", help="put images into one PDF"); _common(p)
    p = sub.add_parser("archive", help="create a zip / tar.gz / 7z"); _common(p)
    p.add_argument("--to", default="zip", choices=["zip", "tar.gz", "7z"])
    p = sub.add_parser("extract", help="extract zip / tar / 7z / rar"); _common(p)
    p = sub.add_parser("preset", help="run a preset")
    p.add_argument("preset_id"); _common(p)

    sub.add_parser("presets", help="list presets")
    p = sub.add_parser("formats", help="show what can be done with a file"); p.add_argument("files", nargs="+", type=Path)
    p = sub.add_parser("doctor", help="check installed components"); p.add_argument("--json", action="store_true")
    p = sub.add_parser("history", help="recent jobs"); p.add_argument("-n", type=int, default=20)
    p = sub.add_parser("report", help="privacy report of a job"); p.add_argument("job_id", type=int)
    p = sub.add_parser("undo", help="remove the files a job created"); p.add_argument("job_id", type=int)
    p = sub.add_parser("ocr-lang", help="download OCR language data (one time, needs internet)")
    p.add_argument("codes", nargs="+"); p.add_argument("--quality", choices=["best", "fast"], default="best")
    p = sub.add_parser("watch", help="run a preset on every new file in a folder")
    p.add_argument("folder", type=Path); p.add_argument("--preset", required=True); p.add_argument("--out", type=Path)
    p = sub.add_parser("shell", help="add/remove Explorer right-click entries (Windows)")
    p.add_argument("op", choices=["register", "unregister"])
    p = sub.add_parser("gui", help="open the window"); p.add_argument("files", nargs="*", type=Path)
    return ap


def main(argv=None) -> int:
    try:
        return _main(argv)
    except BrokenPipeError:
        return EXIT_OK


def _main(argv=None) -> int:
    _utf8_console()
    argv = list(sys.argv[1:] if argv is None else argv)
    if argv and argv[0] == "--gui":
        return _gui([Path(x) for x in argv[1:]])
    if not argv:
        if getattr(sys, "frozen", False):
            return _gui([])
        build_parser().print_help()
        return EXIT_OK
    a = build_parser().parse_args(argv)
    cmd = a.cmd

    if cmd == "convert":
        return _run(a, [Step("convert", a.to.lower().lstrip("."))])
    if cmd == "compress":
        return _run(a, [Step("compress")])
    if cmd == "clean":
        return _run(a, [Step("strip_metadata")])
    if cmd == "ocr":
        return _run(a, [Step("ocr", a.to)])
    if cmd == "transcribe":
        return _run(a, [Step("transcribe", a.to)])
    if cmd == "bg":
        return _run(a, [Step("remove_bg")])
    if cmd == "upscale":
        return _run(a, [Step("upscale")])
    if cmd == "pdf":
        action = {"merge": "pdf_merge", "split": "pdf_split", "extract": "pdf_extract",
                  "rotate": "pdf_rotate", "unlock": "pdf_unlock"}[a.op]
        return _run(a, [Step(action)])
    if cmd == "images2pdf":
        return _run(a, [Step("images_to_pdf")])
    if cmd == "archive":
        return _run(a, [Step("archive", a.to)])
    if cmd == "extract":
        return _run(a, [Step("extract")])
    if cmd == "preset":
        try:
            pr = presets.find(a.preset_id)
        except KeyError:
            print(f"Unknown preset '{a.preset_id}'. Run: satsuma presets", file=sys.stderr)
            return EXIT_FAIL
        a_opts = _options(a)
        merged = pr.apply(a_opts)
        # explicit command-line options win over the preset
        for field_name, given in (("target_size", a.size), ("quality", a.quality), ("max_side", a.max_side),
                                  ("ocr_langs", a.lang)):
            if given:
                merged = merged.but(**{field_name: given if field_name != "quality" else max(1, min(100, given))})
        return _run(a, pr.steps, merged)
    if cmd == "presets":
        for p in presets.all_presets():
            tag = "" if p.builtin else "  (yours)"
            print(f"{p.id:18} {p.name}{tag}")
        return EXIT_OK
    if cmd == "formats":
        for f in a.files:
            print(f"{f.name}")
            for o in core.offers([f]):
                mark = "  " if o.available else "! "
                miss = f"   (needs {o.missing})" if not o.available else ""
                print(f"  {mark}{o.action}" + (f" -> {o.target}" if o.target else "") + miss)
        return EXIT_OK
    if cmd == "doctor":
        rows = engines.status()
        if a.json:
            print(json.dumps(rows, indent=2))
            return EXIT_OK
        for r in rows:
            mark = "OK " if r["ok"] else "-- "
            line = f"{mark} {r['title']:24} {r['purpose']}"
            if r["ok"] and r["version"]:
                line += f"   [{r['version']}]"
            elif not r["ok"] and r["install"]:
                line += f"   -> {r['install']}"
            print(line)
        from .convert import ocr
        print("\nOCR languages ready:", ", ".join(sorted(ocr.installed_languages())) or "none")
        return EXIT_OK
    if cmd == "history":
        for j in history.recent(a.n):
            when = time.strftime("%Y-%m-%d %H:%M", time.localtime(j["ts"]))
            state = "undone" if j["undone"] else ("ok" if j["ok"] else "failed")
            print(f"#{j['id']:<5} {when}  {state:7} {j['label']}  ({', '.join(Path(s).name for s in j['sources'])[:50]})")
        return EXIT_OK
    if cmd == "report":
        j = history.get(a.job_id)
        if not j:
            print("Unknown job", file=sys.stderr)
            return EXIT_FAIL
        print(history.format_report(j["report"]))
        return EXIT_OK
    if cmd == "undo":
        res = history.undo(a.job_id)
        if res["error"]:
            print(res["error"], file=sys.stderr)
            return EXIT_FAIL
        for path, where in res["removed"]:
            print(f"removed  {path}   (-> {where})")
        for path, why in res["skipped"]:
            print(f"skipped  {path}   ({why})")
        return EXIT_OK
    if cmd == "ocr-lang":
        from .convert import ocr
        for code in a.codes:
            print(f"downloading {code} ...")
            try:
                ocr.download_language(code, a.quality)
            except Exception as exc:
                print(f"FAIL  {code}: {exc}", file=sys.stderr)
                return EXIT_FAIL
        print("done")
        return EXIT_OK
    if cmd == "watch":
        return _watch(a)
    if cmd == "shell":
        from . import shell_integration as si
        try:
            keys = si.register() if a.op == "register" else si.unregister()
        except OSError as exc:
            print(str(exc), file=sys.stderr)
            return EXIT_FAIL
        print("\n".join(keys) or "nothing to do")
        return EXIT_OK
    if cmd == "gui":
        return _gui(a.files)
    build_parser().print_help()
    return EXIT_OK


def _watch(a) -> int:
    from .watcher import FolderWatcher
    try:
        pr = presets.find(a.preset)
    except KeyError:
        print(f"Unknown preset '{a.preset}'", file=sys.stderr)
        return EXIT_FAIL
    if not a.folder.is_dir():
        print("Folder not found", file=sys.stderr)
        return EXIT_FAIL

    def show(path, r):
        print(("OK    " if r.ok else "FAIL  ") + path.name + ("" if r.ok else f": {r.error}"), flush=True)

    w = FolderWatcher(a.folder, pr.steps, pr.apply(Options()), on_result=show, out_dir=a.out)
    print(f"Watching {a.folder}  ->  {w.out_dir}   (Ctrl+C to stop)")
    w.start()
    try:
        while True:
            time.sleep(0.5)
    except KeyboardInterrupt:
        w.stop()
    return EXIT_OK


def _gui(files) -> int:
    try:
        from .gui.app import main as gui_main
    except ImportError as exc:
        print("The window needs PySide6:  pip install PySide6\n(" + str(exc) + ")", file=sys.stderr)
        return EXIT_FAIL
    return gui_main([str(f) for f in files])


if __name__ == "__main__":
    sys.exit(main())
