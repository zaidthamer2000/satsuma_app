"""Small, dependency-free helpers: paths, safe names, subprocesses, sizes."""
from __future__ import annotations

import collections
import contextlib
import hashlib
import os
import queue
import re
import shutil
import subprocess
import sys
import tempfile
import threading
import time
from pathlib import Path
from typing import Callable, Iterator, Optional

from .model import Cancelled, ConversionError, MissingEngine

IS_WINDOWS = sys.platform == "win32"

# ----------------------------------------------------------------------------- dirs


def data_dir() -> Path:
    """Per-user writable folder (history, presets, downloaded language data)."""
    env = os.environ.get("SATSUMA_HOME")
    if env:
        p = Path(env)
    elif IS_WINDOWS:
        p = Path(os.environ.get("APPDATA") or Path.home() / "AppData" / "Roaming") / "Satsuma"
    elif sys.platform == "darwin":
        p = Path.home() / "Library" / "Application Support" / "Satsuma"
    else:
        p = Path(os.environ.get("XDG_DATA_HOME") or Path.home() / ".local" / "share") / "satsuma"
    p.mkdir(parents=True, exist_ok=True)
    return p


def app_dir() -> Path:
    """Folder that contains the program (works for source checkouts and PyInstaller)."""
    if getattr(sys, "frozen", False):
        return Path(getattr(sys, "_MEIPASS", Path(sys.executable).parent))
    return Path(__file__).resolve().parent.parent


def fallback_output_dir() -> Path:
    docs = Path.home() / "Documents"
    base = docs if docs.is_dir() else Path.home()
    p = base / "Satsuma Output"
    p.mkdir(parents=True, exist_ok=True)
    return p


def is_ascii(p) -> bool:
    try:
        str(p).encode("ascii")
        return True
    except UnicodeEncodeError:
        return False


def tmp_base(prefer_ascii: bool = False) -> Optional[str]:
    """Directory to create work folders in.

    Some native tools on Windows (notably Tesseract) fail on non-ASCII paths, which
    matters for users whose profile folder is not Latin. When asked, we move the work
    folder to an ASCII location.
    """
    base = tempfile.gettempdir()
    if not prefer_ascii or is_ascii(base):
        return base
    candidates = []
    if IS_WINDOWS:
        drive = os.environ.get("SystemDrive", "C:")
        candidates += [Path(os.environ.get("ProgramData", drive + "\\ProgramData")) / "Satsuma" / "tmp",
                       Path(drive + "\\") / "Satsuma-tmp"]
    for c in candidates:
        try:
            c.mkdir(parents=True, exist_ok=True)
            if is_ascii(c):
                return str(c)
        except OSError:
            continue
    return base


@contextlib.contextmanager
def workdir(prefix: str = "satsuma-", ascii_only: bool = False) -> Iterator[Path]:
    path = Path(tempfile.mkdtemp(prefix=prefix, dir=tmp_base(ascii_only)))
    try:
        yield path
    finally:
        shutil.rmtree(path, ignore_errors=True)


# ------------------------------------------------------------------------ file names

_INVALID = re.compile(r'[<>:"/\\|?*\x00-\x1f]')
_RESERVED = {"CON", "PRN", "AUX", "NUL", *(f"COM{i}" for i in range(1, 10)),
             *(f"LPT{i}" for i in range(1, 10))}


def safe_stem(name: str, fallback: str = "file", limit: int = 120) -> str:
    """Make a file *stem* valid on Windows, macOS and Linux."""
    name = _INVALID.sub("_", name).strip().rstrip(". ")
    if not name:
        return fallback
    if name.split(".")[0].upper() in _RESERVED:
        name = "_" + name
    return name[:limit].rstrip(". ") or fallback


def ext_of(path) -> str:
    """Lower-case extension without the dot ('' if none)."""
    return Path(path).suffix.lower().lstrip(".")


def claim_path(directory: Path, stem: str, ext: str = "") -> Path:
    """Reserve a file name that does not exist yet (creates an empty placeholder).

    Uses O_EXCL so two parallel jobs can never pick the same name, and never
    overwrites anything that already exists: 'a.png', 'a (1).png', 'a (2).png', ...
    """
    directory.mkdir(parents=True, exist_ok=True)
    if ext and not ext.startswith("."):
        ext = "." + ext
    n = 0
    while True:
        name = f"{stem}{ext}" if n == 0 else f"{stem} ({n}){ext}"
        candidate = directory / name
        try:
            fd = os.open(candidate, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
        except FileExistsError:
            n += 1
            continue
        os.close(fd)
        return candidate


def claim_dir(parent: Path, name: str) -> Path:
    parent.mkdir(parents=True, exist_ok=True)
    n = 0
    while True:
        candidate = parent / (name if n == 0 else f"{name} ({n})")
        try:
            candidate.mkdir()
            return candidate
        except FileExistsError:
            n += 1


def move_into_place(src: Path, dst: Path) -> None:
    """Atomically replace *dst* (our own placeholder) with *src*; works across drives."""
    try:
        os.replace(src, dst)
    except OSError:
        shutil.copy2(src, dst)
        with contextlib.suppress(OSError):
            os.remove(src)


# ------------------------------------------------------------------------- numbers

_SIZE_RE = re.compile(r"^\s*([0-9]*\.?[0-9]+)\s*([kmgt]?i?b?)?\s*$", re.I)


def human_size(n: float) -> str:
    n = float(n)
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if abs(n) < 1024 or unit == "TB":
            return f"{n:.0f} {unit}" if unit == "B" else f"{n:.1f} {unit}"
        n /= 1024
    return f"{n:.1f} TB"


def parse_size(text: str) -> int:
    """'2MB' -> 2097152, '500 kb' -> 512000, '1.5m' -> 1572864, '300' -> 300."""
    m = _SIZE_RE.match(str(text))
    if not m:
        raise ValueError(f"Cannot understand size: {text!r}")
    value = float(m.group(1))
    unit = (m.group(2) or "b").lower().rstrip("b").rstrip("i")
    power = {"": 0, "k": 1, "m": 2, "g": 3, "t": 4}[unit]
    return int(value * 1024 ** power)


def sha256_file(path: Path, chunk: int = 1 << 20) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for block in iter(lambda: f.read(chunk), b""):
            h.update(block)
    return h.hexdigest()


def dir_size(path: Path) -> int:
    return sum(p.stat().st_size for p in Path(path).rglob("*") if p.is_file())


def size_of(path: Path) -> int:
    path = Path(path)
    return dir_size(path) if path.is_dir() else path.stat().st_size


# ---------------------------------------------------------------------- subprocesses


def _kill_tree(proc: subprocess.Popen) -> None:
    try:
        if IS_WINDOWS:
            subprocess.run(["taskkill", "/PID", str(proc.pid), "/T", "/F"],
                           capture_output=True, creationflags=subprocess.CREATE_NO_WINDOW)
        else:
            proc.terminate()
            try:
                proc.wait(3)
            except subprocess.TimeoutExpired:
                proc.kill()
    except Exception:
        with contextlib.suppress(Exception):
            proc.kill()


def run_cmd(args, ctx=None, *, on_line: Optional[Callable[[str], None]] = None,
            timeout: Optional[float] = None, cwd=None, env=None) -> tuple[int, str, str]:
    """Run a program without a console window; honours cancellation and timeouts.

    Returns (returncode, stdout, stderr_tail). If *on_line* is given, stdout lines are
    streamed to it instead of being collected.
    """
    argv = [str(a) for a in args]
    flags = subprocess.CREATE_NO_WINDOW if IS_WINDOWS else 0
    try:
        proc = subprocess.Popen(argv, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                                stderr=subprocess.PIPE, text=True, encoding="utf-8",
                                errors="replace", cwd=cwd, env=env, creationflags=flags)
    except FileNotFoundError as exc:
        raise MissingEngine(Path(argv[0]).name) from exc
    except OSError as exc:
        raise ConversionError(f"Could not start {Path(argv[0]).name}: {exc}") from exc

    q: "queue.Queue[tuple[str, Optional[str]]]" = queue.Queue()

    def pump(stream, tag):
        try:
            for line in iter(stream.readline, ""):
                q.put((tag, line))
        except (ValueError, OSError):        # stream closed after a cancel/timeout
            pass
        finally:
            q.put((tag, None))

    for stream, tag in ((proc.stdout, "o"), (proc.stderr, "e")):
        threading.Thread(target=pump, args=(stream, tag), daemon=True).start()

    out_buf: list[str] = []
    err_tail: collections.deque = collections.deque(maxlen=200)
    finished = 0
    started = time.monotonic()
    try:
        while finished < 2:
            try:
                tag, line = q.get(timeout=0.1)
            except queue.Empty:
                tag, line = "", ""
            if line is None:
                finished += 1
            elif tag == "o":
                if on_line:
                    on_line(line.rstrip("\r\n"))
                else:
                    out_buf.append(line)
            elif tag == "e":
                err_tail.append(line.rstrip("\r\n"))
            if ctx is not None and ctx.cancelled():
                _kill_tree(proc)
                raise Cancelled()
            if timeout and time.monotonic() - started > timeout:
                _kill_tree(proc)
                raise ConversionError(f"{Path(argv[0]).name} took too long and was stopped")
        rc = proc.wait()
    except BaseException:
        if proc.poll() is None:
            _kill_tree(proc)
        raise
    finally:
        for stream in (proc.stdout, proc.stderr):       # release the pipe handles (important on Windows)
            with contextlib.suppress(Exception):
                stream.close()
    return rc, "".join(out_buf), "\n".join(err_tail)
