"""Locate the external programs and optional Python packages Satsuma can use."""
from __future__ import annotations

import glob
import importlib.util
import os
import shutil
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

from .model import MissingEngine
from .util import IS_WINDOWS, app_dir, data_dir, run_cmd


@dataclass(frozen=True)
class Engine:
    id: str
    title: str
    exes: tuple
    win_paths: tuple = ()
    winget: Optional[str] = None
    purpose: str = ""
    version_args: tuple = ("--version",)


ENGINES = {e.id: e for e in (
    Engine("ffmpeg", "FFmpeg", ("ffmpeg",),
           (r"%LOCALAPPDATA%\Microsoft\WinGet\Links\ffmpeg.exe", r"%ProgramFiles%\ffmpeg\bin\ffmpeg.exe",
            r"C:\ffmpeg\bin\ffmpeg.exe", r"%ProgramData%\chocolatey\bin\ffmpeg.exe",
            r"%LOCALAPPDATA%\Microsoft\WinGet\Packages\Gyan.FFmpeg*\ffmpeg-*\bin\ffmpeg.exe"),
           "Gyan.FFmpeg", "Audio and video conversion, compression", ("-version",)),
    Engine("ffprobe", "FFprobe", ("ffprobe",),
           (r"%LOCALAPPDATA%\Microsoft\WinGet\Links\ffprobe.exe", r"%ProgramFiles%\ffmpeg\bin\ffprobe.exe",
            r"C:\ffmpeg\bin\ffprobe.exe",
            r"%LOCALAPPDATA%\Microsoft\WinGet\Packages\Gyan.FFmpeg*\ffmpeg-*\bin\ffprobe.exe"),
           "Gyan.FFmpeg", "Reads media duration and streams", ("-version",)),
    Engine("tesseract", "Tesseract OCR", ("tesseract",),
           (r"%ProgramFiles%\Tesseract-OCR\tesseract.exe", r"%ProgramFiles(x86)%\Tesseract-OCR\tesseract.exe",
            r"%LOCALAPPDATA%\Programs\Tesseract-OCR\tesseract.exe"),
           "UB-Mannheim.TesseractOCR", "Text recognition (Arabic, English, ...)", ("--version",)),
    Engine("soffice", "LibreOffice", ("soffice", "libreoffice"),
           (r"%ProgramFiles%\LibreOffice*\program\soffice.exe",
            r"%ProgramFiles(x86)%\LibreOffice*\program\soffice.exe"),
           "TheDocumentFoundation.LibreOffice", "Word / Excel / PowerPoint / SVG conversion", ("--version",)),
    Engine("pandoc", "Pandoc", ("pandoc",),
           (r"%ProgramFiles%\Pandoc\pandoc.exe", r"%LOCALAPPDATA%\Pandoc\pandoc.exe"),
           "JohnMacFarlane.Pandoc", "Markdown / EPUB / HTML / DOCX conversion", ("--version",)),
    Engine("7z", "7-Zip", ("7z", "7zz", "7za"),
           (r"%ProgramFiles%\7-Zip\7z.exe", r"%ProgramFiles(x86)%\7-Zip\7z.exe"),
           "7zip.7zip", "Opening RAR and other archive formats", ("i",)),
    Engine("ebook-convert", "Calibre", ("ebook-convert",),
           (r"%ProgramFiles%\Calibre2\ebook-convert.exe", r"%ProgramFiles(x86)%\Calibre2\ebook-convert.exe"),
           "calibre.calibre", "MOBI / AZW3 / EPUB / FB2 e-book conversion", ("--version",)),
    Engine("realesrgan", "Real-ESRGAN (ncnn)", ("realesrgan-ncnn-vulkan",),
           (), None, "AI image upscaling (optional; drop the program into the tools folder)", ("-h",)),
)}

OPTIONAL_MODULES = {
    "pillow_heif": "HEIC / HEIF images",
    "rawpy": "Camera RAW photos (CR2, NEF, ARW, DNG ...)",
    "pdf2docx": "Best-quality PDF to Word conversion",
    "rembg": "AI background removal",
    "faster_whisper": "Speech to text (offline)",
    "brotli": "WOFF2 fonts",
    "py7zr": "Creating and opening .7z archives",
    "trimesh": "3D models (STL, OBJ, PLY, GLB)",
    "cv2": "Fallback background removal",
}

_cache: dict = {}


def tools_dirs() -> list[Path]:
    dirs = [app_dir() / "tools", data_dir() / "tools"]
    if getattr(__import__("sys"), "frozen", False):
        dirs.append(Path(__import__("sys").executable).parent / "tools")
    return [d for d in dirs if d.is_dir()]


def _search(engine: Engine) -> Optional[Path]:
    names = []
    for exe in engine.exes:
        names.append(exe + ".exe" if IS_WINDOWS else exe)
    for d in tools_dirs():                      # 1) tools folder shipped with / next to the app
        for name in names:
            for hit in [d / name, *d.glob(f"**/{name}")]:
                if hit.is_file():
                    return hit
    for name in names:                          # 2) PATH
        found = shutil.which(name)
        if found:
            return Path(found)
    if IS_WINDOWS:                              # 3) usual install locations
        for pattern in engine.win_paths:
            for hit in sorted(glob.glob(os.path.expandvars(pattern)), reverse=True):
                if Path(hit).is_file():
                    return Path(hit)
    return None


def find(engine_id: str) -> Optional[Path]:
    if engine_id not in _cache or (_cache[engine_id] and not _cache[engine_id].exists()):
        _cache[engine_id] = _search(ENGINES[engine_id])
    return _cache[engine_id]


def forget() -> None:
    """Forget cached lookups (e.g. after the user installed a component)."""
    _cache.clear()


def available(engine_id: str) -> bool:
    return find(engine_id) is not None


def require(engine_id: str) -> Path:
    path = find(engine_id)
    if path is None:
        eng = ENGINES[engine_id]
        hint = f"install it with:  winget install {eng.winget}" if (IS_WINDOWS and eng.winget) else \
            "install it or put it in the 'tools' folder"
        raise MissingEngine(eng.title, hint)
    return path


def have_module(name: str) -> bool:
    try:
        return importlib.util.find_spec(name) is not None
    except (ImportError, ValueError):
        return False


def status(with_versions: bool = True) -> list[dict]:
    rows = []
    for eng in ENGINES.values():
        path = find(eng.id)
        version = ""
        if path and with_versions:
            try:
                rc, out, err = run_cmd([path, *eng.version_args], timeout=15)
                version = ((out or err).strip().splitlines() or [""])[0][:90]
            except Exception:
                version = "?"
        rows.append({"kind": "program", "id": eng.id, "title": eng.title, "ok": path is not None,
                     "path": str(path) if path else "", "version": version, "purpose": eng.purpose,
                     "install": (f"winget install {eng.winget}" if eng.winget else "")})
    for mod, purpose in OPTIONAL_MODULES.items():
        rows.append({"kind": "python", "id": mod, "title": mod, "ok": have_module(mod), "path": "",
                     "version": "", "purpose": purpose, "install": f"pip install {mod.replace('_', '-')}"})
    return rows
