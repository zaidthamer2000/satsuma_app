"""The ONLY module allowed to touch the network (see tests/test_privacy.py).

It is used for exactly one thing: downloading optional OCR language data when the
user explicitly asks for a language that is not installed yet.
"""
from __future__ import annotations

import os
import urllib.request
from pathlib import Path
from typing import Callable, Optional

from .model import Cancelled, ConversionError

USER_AGENT = "Satsuma/1.0 (+https://github.com/)"


def download(url: str, dest: Path, progress: Optional[Callable[[float], None]] = None,
             cancel=None, timeout: int = 30) -> Path:
    dest = Path(dest)
    dest.parent.mkdir(parents=True, exist_ok=True)
    part = dest.with_suffix(dest.suffix + ".part")
    req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp, open(part, "wb") as out:
            total = int(resp.headers.get("Content-Length") or 0)
            done = 0
            while True:
                if cancel is not None and cancel.is_set():
                    raise Cancelled()
                block = resp.read(1 << 16)
                if not block:
                    break
                out.write(block)
                done += len(block)
                if progress and total:
                    progress(done / total)
        if total and done != total:
            raise ConversionError("The download was interrupted - please try again")
        os.replace(part, dest)
    except (OSError, ValueError) as exc:
        raise ConversionError(f"Download failed: {exc}") from exc
    finally:
        if part.exists():
            try:
                part.unlink()
            except OSError:
                pass
    return dest
