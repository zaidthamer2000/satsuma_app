"""Shared data types: options, results, the per-job context and exceptions."""
from __future__ import annotations

import dataclasses
import threading
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, Optional


class ConversionError(Exception):
    """A failure whose message is safe to show to the user."""


class Cancelled(Exception):
    """Raised when the user cancels a running job."""


class MissingEngine(ConversionError):
    def __init__(self, engine: str, hint: str = ""):
        msg = f"Required component not found: {engine}"
        if hint:
            msg += f" - {hint}"
        super().__init__(msg)
        self.engine = engine
        self.hint = hint


class MissingLanguage(ConversionError):
    """OCR language data is not installed (and downloading was not allowed)."""

    def __init__(self, languages):
        self.languages = list(languages)
        super().__init__("OCR language data not installed: " + ", ".join(self.languages)
                         + ". Download it from Settings > OCR languages (or run: satsuma ocr-lang "
                         + " ".join(self.languages) + ").")


class TargetUnreachable(ConversionError):
    """The requested target size cannot be reached without destroying the file."""


@dataclass
class Options:
    # images / general
    quality: int = 85                      # 1-100 for lossy image encoders
    target_size: Optional[int] = None      # bytes; "make it at most this big"
    strip_metadata: bool = False
    max_side: Optional[int] = None         # longest image side in pixels
    # output
    out_dir: Optional[Path] = None         # None -> next to the source file
    suffix: Optional[str] = None           # None -> action default
    # OCR
    ocr_langs: str = "ara+eng"
    ocr_dpi: int = 300
    allow_download: bool = False           # may fetch missing OCR language data (explicit opt-in)
    ocr_quality: str = "best"              # tessdata flavour to download: best | fast
    # PDF
    render_dpi: int = 200
    page_spec: str = ""                    # "1-3,5,8-" (1-based)
    angle: int = 90
    password: Optional[str] = None
    pdf_word_mode: str = "auto"            # auto | editable | layout | ocr
    # AI helpers
    scale: int = 2
    whisper_model: str = "small"
    language: Optional[str] = None
    # audio / video
    video_crf: int = 23
    video_height: Optional[int] = None
    audio_bitrate_k: int = 192
    gif_fps: int = 12
    gif_width: int = 480

    def but(self, **changes) -> "Options":
        return dataclasses.replace(self, **changes)

    def to_dict(self) -> dict:
        d = dataclasses.asdict(self)
        d["out_dir"] = str(self.out_dir) if self.out_dir else None
        return d

    @classmethod
    def from_dict(cls, data: dict) -> "Options":
        names = {f.name for f in dataclasses.fields(cls)}
        clean = {k: v for k, v in (data or {}).items() if k in names}
        if clean.get("out_dir"):
            clean["out_dir"] = Path(clean["out_dir"])
        return cls(**clean)


ProgressFn = Callable[[float, str], None]


class Context:
    """Everything a backend needs while it runs one step."""

    def __init__(self, opts: Options, work: Path, cancel: Optional[threading.Event] = None,
                 progress: Optional[ProgressFn] = None):
        self.opts = opts
        self.work = Path(work)
        self.cancel = cancel or threading.Event()
        self._progress = progress
        self.warnings: list[str] = []
        self.engines: list[str] = []
        self.report: dict = {}

    def cancelled(self) -> bool:
        return self.cancel.is_set()

    def check(self) -> None:
        if self.cancel.is_set():
            raise Cancelled()

    def progress(self, fraction: float, message: str = "") -> None:
        if self._progress:
            self._progress(max(0.0, min(1.0, fraction)), message)

    def warn(self, message: str) -> None:
        if message not in self.warnings:
            self.warnings.append(message)

    def used(self, engine: str) -> None:
        if engine not in self.engines:
            self.engines.append(engine)

    def note(self, key: str, value) -> None:
        self.report.setdefault(key, []).append(value)

    def path(self, name: str) -> Path:
        return self.work / name


@dataclass
class Result:
    ok: bool
    sources: list[Path] = field(default_factory=list)
    outputs: list[Path] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    error: Optional[str] = None
    cancelled: bool = False
    engines: list[str] = field(default_factory=list)
    report: dict = field(default_factory=dict)
    seconds: float = 0.0
    job_id: Optional[int] = None
