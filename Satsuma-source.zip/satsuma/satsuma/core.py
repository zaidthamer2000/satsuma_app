"""The engine: what can be done to a file, and running chains of steps safely.

Safety rules enforced here for every action:
  * the original file is never modified, moved or deleted;
  * outputs are written to a temporary folder first and only moved into place when the
    whole chain succeeded (a cancelled or failed job leaves nothing behind);
  * an existing file is never overwritten ("a.png", "a (1).png", ...).
"""
from __future__ import annotations

import os
import shutil
import tempfile
import threading
import time
import traceback
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, Optional, Sequence

from . import engines, history
from .convert import ai, archives, av, documents, fonts, images, metadata, models3d, ocr, pdfs
from .formats import Target, canon, full_ext, kind_of
from .model import (Cancelled, ConversionError, Context, MissingEngine, MissingLanguage, Options, Result)
from .util import (IS_WINDOWS, claim_dir, claim_path, data_dir, fallback_output_dir, move_into_place, safe_stem,
                   ext_of, size_of, workdir)

ProgressCb = Callable[[float, str], None]


@dataclass
class Step:
    action: str
    target: Optional[str] = None
    params: dict = field(default_factory=dict)

    def to_dict(self) -> dict:
        return {"action": self.action, "target": self.target, "params": self.params}

    @classmethod
    def from_dict(cls, d: dict) -> "Step":
        return cls(d["action"], d.get("target"), dict(d.get("params") or {}))

    def label(self) -> str:
        return f"{self.action}" + (f" -> {self.target}" if self.target else "")


@dataclass(frozen=True)
class Action:
    id: str
    label: str
    group: str
    multi: bool = False
    needs_target: bool = False
    suffix: str = ""


ACTIONS: dict[str, Action] = {a.id: a for a in (
    Action("convert", "Convert", "convert", needs_target=True),
    Action("compress", "Compress / reduce size", "optimize", suffix="_compressed"),
    Action("strip_metadata", "Remove hidden data", "privacy", suffix="_clean"),
    Action("ocr", "Recognise text (OCR)", "text", needs_target=True, suffix="_ocr"),
    Action("transcribe", "Speech to text", "text", needs_target=True),
    Action("remove_bg", "Remove background", "image", suffix="_nobg"),
    Action("upscale", "Enlarge image", "image", suffix="_x{scale}"),
    Action("extract", "Extract archive", "archive"),
    Action("archive", "Create archive", "archive", multi=True, needs_target=True),
    Action("pdf_merge", "Merge PDFs", "pdf", multi=True, suffix="_merged"),
    Action("images_to_pdf", "Images to one PDF", "pdf", multi=True),
    Action("pdf_split", "Split into pages", "pdf", suffix=" pages"),
    Action("pdf_extract", "Extract / reorder pages", "pdf", suffix="_pages"),
    Action("pdf_rotate", "Rotate pages", "pdf", suffix="_rotated"),
    Action("pdf_unlock", "Remove PDF password", "pdf", suffix="_unlocked"),
)}

BACKENDS = (images, av, pdfs, documents, archives, fonts, models3d)


# ------------------------------------------------------------------------------ offers

@dataclass(frozen=True)
class Offer:
    action: str
    target: Optional[str]
    available: bool = True
    missing: str = ""

    @property
    def key(self) -> tuple:
        return (self.action, self.target)


def _single_offers(path: Path) -> list[Offer]:
    kind = kind_of(path)
    out: list[Offer] = []
    seen: set = set()
    for backend in BACKENDS:
        for t in backend.targets(path):
            if t.ext not in seen:
                seen.add(t.ext)
                out.append(Offer("convert", t.ext, t.available, t.missing))
    if kind in ("image", "pdf", "video", "audio"):
        ok = kind != "video" and kind != "audio" or engines.available("ffmpeg")
        out.append(Offer("compress", None, ok, "" if ok else "FFmpeg"))
    if metadata.supported(path):
        ffm = kind in ("audio", "video") and not engines.available("ffmpeg")
        out.append(Offer("strip_metadata", None, not ffm, "FFmpeg" if ffm else ""))
    for t in ocr.targets(path):
        out.append(Offer("ocr", t.ext, t.available, t.missing))
    for t in ai.targets(path):
        out.append(Offer("transcribe", t.ext, t.available, t.missing))
    if kind == "image":
        bg = engines.have_module("rembg") or engines.have_module("cv2")
        out.append(Offer("remove_bg", None, bg, "" if bg else "rembg"))
        out.append(Offer("upscale", None))
    if kind == "archive":
        out.append(Offer("extract", None))
    if kind == "pdf":
        out += [Offer("pdf_split", None), Offer("pdf_extract", None), Offer("pdf_rotate", None),
                Offer("pdf_unlock", None)]
    return out


def offers(paths: Sequence[Path]) -> list[Offer]:
    """Everything that can be done to ALL of the given files."""
    paths = [Path(p) for p in paths]
    if not paths:
        return []
    common: Optional[dict] = None
    per_ext: dict = {}
    for p in paths:
        key = full_ext(p)
        if key not in per_ext:
            per_ext[key] = {o.key: o for o in _single_offers(p) if not ACTIONS[o.action].multi}
        current = per_ext[key]
        common = current if common is None else {k: v for k, v in common.items() if k in current}
    result = list(common.values()) if common else []
    kinds = {kind_of(p) for p in paths}
    if kinds == {"pdf"} and len(paths) >= 2:
        result.append(Offer("pdf_merge", None))
    if kinds == {"image"}:
        result.append(Offer("images_to_pdf", None))
    for fmt in archives.pack_formats():
        result.append(Offer("archive", fmt))
    return result


# ----------------------------------------------------------------------------- dispatch

def _pick_backend(src: Path, target: str):
    target = canon(target)
    for backend in BACKENDS:
        for t in backend.targets(src):
            if t.ext == target:
                if not t.available:
                    raise MissingEngine(t.missing or backend.NAME)
                return backend
    raise ConversionError(f"Cannot convert .{ext_of(src)} files to {target.upper()}")


def _run_single(action: str, src: Path, target: Optional[str], ctx: Context) -> list[Path]:
    kind = kind_of(src)
    if action == "convert":
        if not target:
            raise ConversionError("Choose a target format")
        if canon(target) == canon(ext_of(src)):
            raise ConversionError("The file is already in this format - use 'compress' to make it smaller")
        return _pick_backend(src, target).convert(src, canon(target), ctx)
    if action == "compress":
        if kind == "image":
            return images.compress(src, ctx)
        if kind == "pdf":
            return pdfs.compress(src, ctx)
        if kind in ("audio", "video"):
            return av.compress(src, ctx)
        raise ConversionError("Compression is available for images, PDFs, audio and video")
    if action == "strip_metadata":
        return metadata.strip(src, ctx)
    if action == "ocr":
        return ocr.convert(src, target or "txt", ctx)
    if action == "transcribe":
        return ai.transcribe(src, target or "txt", ctx)
    if action == "remove_bg":
        return images.remove_background(src, ctx)
    if action == "upscale":
        return images.upscale(src, ctx)
    if action == "extract":
        return archives.extract(src, ctx)
    if action == "pdf_split":
        return pdfs.split(src, ctx)
    if action == "pdf_extract":
        return pdfs.extract_pages(src, ctx)
    if action == "pdf_rotate":
        return pdfs.rotate(src, ctx)
    if action == "pdf_unlock":
        return pdfs.unlock(src, ctx)
    raise ConversionError(f"Unknown action: {action}")


def _run_multi(action: str, srcs: list[Path], target: Optional[str], ctx: Context) -> list[Path]:
    if action == "pdf_merge":
        return pdfs.merge(srcs, ctx)
    if action == "images_to_pdf":
        return pdfs.images_to_pdf(srcs, ctx)
    if action == "archive":
        return archives.pack(srcs, canon(target or "zip"), ctx)
    raise ConversionError(f"Unknown action: {action}")


# ----------------------------------------------------------------------------- running

@dataclass
class _Item:
    path: Path
    origin: Path          # the user's file this came from (for naming)


def _output_dir(origin: Path, opts: Options, ctx_warn: Callable[[str], None]) -> Path:
    want = Path(opts.out_dir) if opts.out_dir else origin.parent
    if _writable(want):
        return want
    fb = fallback_output_dir()
    ctx_warn(f"The folder '{want}' is not writable - results were saved to {fb}")
    return fb


def _writable(folder: Path) -> bool:
    """Really try to create a file (os.access is unreliable for Windows folders and network shares)."""
    try:
        folder.mkdir(parents=True, exist_ok=True)
        fd, name = tempfile.mkstemp(dir=folder, prefix=".satsuma-w")
        os.close(fd)
        os.unlink(name)
        return True
    except OSError:
        return False


def _suffix_for(step: Step, opts: Options, same_ext: bool) -> str:
    if opts.suffix is not None:
        return opts.suffix
    base = ACTIONS[step.action].suffix.replace("{scale}", str(opts.scale))
    if not base and same_ext and step.action in ("convert", "ocr"):
        return "_converted"
    return base


def _needs_ascii(steps: Sequence[Step]) -> bool:
    return IS_WINDOWS and any(s.action in ("ocr",) or s.action == "convert" and s.target in ("docx",)
                              for s in steps)


def run_job(sources: Sequence[Path], steps: Sequence[Step], opts: Optional[Options] = None, *,
            cancel: Optional[threading.Event] = None, progress: Optional[ProgressCb] = None,
            log: bool = True) -> Result:
    """Run a chain of steps over *sources* as one job; returns a Result (never raises)."""
    opts = opts or Options()
    cancel = cancel or threading.Event()
    srcs = [Path(s) for s in sources]
    started = time.monotonic()
    result = Result(ok=False, sources=srcs)
    created: list[Path] = []
    label = " + ".join(s.label() for s in steps) or "job"
    try:
        if not srcs or not steps:
            raise ConversionError("Nothing to do")
        for s in srcs:
            if not s.exists():
                raise ConversionError(f"File not found: {s}")
        with workdir(ascii_only=_needs_ascii(steps)) as work:
            items = [_Item(s, s) for s in srcs]
            n_steps = len(steps)
            first_ctx_warnings: list[str] = []
            last_step = steps[-1]
            for si, step in enumerate(steps):
                if step.action not in ACTIONS:
                    raise ConversionError(f"Unknown action: {step.action}")
                step_opts = opts.but(**step.params) if step.params else opts
                produced: list[_Item] = []
                units = [items] if ACTIONS[step.action].multi else [[it] for it in items]
                for ui, unit in enumerate(units):
                    if cancel.is_set():
                        raise Cancelled()
                    stage = work / f"s{si}_{ui}"
                    stage.mkdir(parents=True)
                    lo = (si + ui / len(units)) / n_steps
                    span = 1 / (n_steps * len(units))

                    def prog(frac, msg="", lo=lo, span=span):
                        if progress:
                            progress(lo + frac * span, msg)

                    ctx = Context(step_opts, stage, cancel, prog)
                    if ACTIONS[step.action].multi:
                        outs = _run_multi(step.action, [u.path for u in unit], step.target, ctx)
                        origin = unit[0].origin
                    else:
                        outs = _run_single(step.action, unit[0].path, step.target, ctx)
                        origin = unit[0].origin
                    for w in ctx.warnings:
                        if w not in result.warnings:
                            result.warnings.append(w)
                    for e in ctx.engines:
                        if e not in result.engines:
                            result.engines.append(e)
                    for k, v in ctx.report.items():
                        result.report.setdefault(k, []).extend(v)
                    for o in outs:
                        if not o.exists() or (o.is_file() and o.stat().st_size == 0):
                            raise ConversionError("The conversion produced an empty file")
                        produced.append(_Item(o, origin))
                items = produced
            if progress:
                progress(0.98, "Saving")
            created = _finalize(items, steps, last_step, opts, result)
        result.outputs = created
        result.ok = True
    except Cancelled:
        result.cancelled = True
        result.error = "Cancelled"
        _cleanup(created)
    except MissingLanguage as exc:
        result.error = str(exc)
        result.report["missing_languages"] = exc.languages
    except ConversionError as exc:
        result.error = str(exc)
        _cleanup(created)
    except MemoryError:
        result.error = "Not enough memory to process this file"
        _cleanup(created)
    except OSError as exc:
        result.error = f"A file could not be read or saved: {exc.strerror or exc}"
        _cleanup(created)
    except Exception as exc:                      # a bug: log the details, show a short message
        _log_crash(exc)
        result.error = f"Unexpected error ({type(exc).__name__}: {exc}). Details were saved to the error log."
        _cleanup(created)
    result.seconds = time.monotonic() - started
    if log and not result.cancelled:
        try:
            result.job_id = history.record(result, label)
        except Exception:
            pass
    return result


def _finalize(items: list[_Item], steps: Sequence[Step], last: Step, opts: Options, result: Result) -> list[Path]:
    """Move temporary outputs next to the originals under collision-free names."""
    by_origin: dict[Path, list[_Item]] = {}
    for it in items:
        by_origin.setdefault(it.origin, []).append(it)
    created: list[Path] = []
    try:
        for origin, group in by_origin.items():
            out_dir = _output_dir(origin, opts, lambda m: m not in result.warnings and result.warnings.append(m))
            stem = safe_stem(origin.stem if origin.is_file() or not origin.suffix else origin.stem)
            same_ext = len(group) == 1 and group[0].path.is_file() and \
                canon(ext_of(group[0].path)) == canon(ext_of(origin))
            suffix = _suffix_for(last, opts, same_ext)
            if len(group) == 1 and group[0].path.is_dir():              # e.g. extracted archive
                dest = claim_dir(out_dir, safe_stem(stem + suffix))
                for child in group[0].path.iterdir():
                    shutil.move(str(child), str(dest / child.name))
                created.append(dest)
            elif len(group) == 1:
                src = group[0].path
                dest = claim_path(out_dir, safe_stem(stem + suffix, limit=150), canon_ext(src))
                created.append(dest)
                move_into_place(src, dest)
            else:                                                       # many pages -> a folder
                default = " pages" if kind_of(origin) == "pdf" else " files"
                folder = claim_dir(out_dir, safe_stem(stem + (suffix or default)))
                created.append(folder)
                for it in group:
                    move_into_place(it.path, folder / it.path.name)
    except BaseException:
        _cleanup(created)
        raise
    return created


def canon_ext(path: Path) -> str:
    return ext_of(path)


def _cleanup(paths: list[Path]) -> None:
    for p in paths:
        try:
            shutil.rmtree(p) if p.is_dir() else p.unlink()
        except OSError:
            pass


def _log_crash(exc: BaseException) -> None:
    try:
        with open(data_dir() / "errors.log", "a", encoding="utf-8") as f:
            f.write(f"\n--- {time.strftime('%Y-%m-%d %H:%M:%S')} ---\n")
            f.write("".join(traceback.format_exception(type(exc), exc, exc.__traceback__)))
    except OSError:
        pass


def run_batch(sources: Sequence[Path], steps: Sequence[Step], opts: Optional[Options] = None, *,
              cancel: Optional[threading.Event] = None,
              progress: Optional[Callable[[int, int, float, str], None]] = None,
              on_result: Optional[Callable[[int, Result], None]] = None, log: bool = True) -> list[Result]:
    """One job per file (or a single job when the first step combines files)."""
    cancel = cancel or threading.Event()
    srcs = [Path(s) for s in sources]
    groups = [srcs] if (steps and ACTIONS.get(steps[0].action, ACTIONS["convert"]).multi) else [[s] for s in srcs]
    results: list[Result] = []
    for i, group in enumerate(groups):
        if cancel.is_set():
            break

        def prog(frac, msg="", i=i):
            if progress:
                progress(i, len(groups), frac, msg)

        r = run_job(group, steps, opts, cancel=cancel, progress=prog, log=log)
        results.append(r)
        if on_result:
            on_result(i, r)
        if r.cancelled:
            break
    return results
