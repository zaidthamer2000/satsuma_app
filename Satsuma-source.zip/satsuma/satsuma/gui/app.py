"""The Satsuma window (PySide6). All real work happens in satsuma.core; this file only shows it."""
from __future__ import annotations

import json
import os
import subprocess
import sys
import threading
import time
from pathlib import Path
from typing import Optional

from PySide6.QtCore import QObject, QRunnable, QSettings, Qt, QThread, QThreadPool, QTimer, QUrl, Signal
from PySide6.QtGui import QDesktopServices
from PySide6.QtNetwork import QLocalServer, QLocalSocket
from PySide6.QtWidgets import (QAbstractItemView, QApplication, QCheckBox, QComboBox, QDoubleSpinBox, QFileDialog,
                               QFormLayout, QGroupBox, QHBoxLayout, QHeaderView, QLabel, QLineEdit, QListWidget,
                               QMainWindow, QMessageBox, QProgressBar, QPushButton, QSlider, QSpinBox,
                               QTableWidget, QTableWidgetItem, QTabWidget, QVBoxLayout, QWidget)

from .. import __version__, core, engines, history, presets
from ..convert import images, ocr
from ..formats import kind_of
from ..i18n import action_label, tr
from ..model import Options
from ..util import IS_WINDOWS, human_size

SERVER_NAME = "SatsumaSingleInstance-v1"
MAX_DROPPED = 5000


def expand_paths(paths) -> list[Path]:
    """Files stay, folders are replaced by the files inside them."""
    out: list[Path] = []
    for raw in paths:
        p = Path(raw)
        if p.is_dir():
            for f in sorted(p.rglob("*")):
                if f.is_file() and not f.name.startswith("."):
                    out.append(f)
                    if len(out) >= MAX_DROPPED:
                        return out
        elif p.exists():
            out.append(p)
    return out


class BatchWorker(QThread):
    progress = Signal(int, int, float, str)
    one_done = Signal(int, object)
    all_done = Signal(object)

    def __init__(self, files, steps, opts, parent=None):
        super().__init__(parent)
        self.files, self.steps, self.opts = list(files), list(steps), opts
        self.cancel = threading.Event()

    def run(self):
        results = []
        try:
            results = core.run_batch(self.files, self.steps, self.opts, cancel=self.cancel,
                                     progress=lambda i, n, f, m: self.progress.emit(i, n, f, m),
                                     on_result=lambda i, r: self.one_done.emit(i, r))
        finally:
            self.all_done.emit(results)


class DownloadWorker(QThread):
    done = Signal(bool, str)

    def __init__(self, codes, quality="best", parent=None):
        super().__init__(parent)
        self.codes, self.quality = list(codes), quality

    def run(self):
        try:
            for code in self.codes:
                ocr.download_language(code, self.quality)
            self.done.emit(True, "")
        except Exception as exc:
            self.done.emit(False, str(exc))


class _EstimateSignals(QObject):
    ready = Signal(int, object)


class _Estimate(QRunnable):
    def __init__(self, token, path, fmt, opts, signals):
        super().__init__()
        self.token, self.path, self.fmt, self.opts, self.signals = token, path, fmt, opts, signals

    def run(self):
        try:
            self.signals.ready.emit(self.token, images.estimate_size(self.path, self.fmt, self.opts))
        except Exception:
            self.signals.ready.emit(self.token, None)


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.settings = QSettings("Satsuma", "Satsuma")
        self.lang = str(self.settings.value("lang", "en"))
        self.files: list[Path] = []
        self.offers: list[core.Offer] = []
        self.out_dir: Optional[Path] = None
        self.worker: Optional[BatchWorker] = None
        self.dl_worker: Optional[DownloadWorker] = None
        self.row_results: dict[int, object] = {}
        self.est_token = 0
        self.est_signals = _EstimateSignals()
        self.est_signals.ready.connect(self._estimate_ready)
        self.est_timer = QTimer(self)
        self.est_timer.setSingleShot(True)
        self.est_timer.timeout.connect(self._run_estimate)
        self.add_timer = QTimer(self)                       # batches paths forwarded by Explorer
        self.add_timer.setSingleShot(True)
        self.add_timer.timeout.connect(self._flush_pending)
        self.pending: list[str] = []
        self.setAcceptDrops(True)
        self.resize(1040, 720)
        self._build()
        self.retranslate()
        self.refresh_offers()

    # ----------------------------------------------------------------------------- layout
    def _build(self):
        self.tabs = QTabWidget()
        self.setCentralWidget(self.tabs)
        self.tabs.addTab(self._build_convert_tab(), "")
        self.tabs.addTab(self._build_history_tab(), "")
        self.tabs.addTab(self._build_components_tab(), "")
        self.tabs.currentChanged.connect(self._tab_changed)

    def _build_convert_tab(self) -> QWidget:
        root = QWidget()
        outer = QVBoxLayout(root)
        top = QHBoxLayout()
        self.note = QLabel()
        self.lang_box = QComboBox()
        self.lang_box.addItem("English", "en")
        self.lang_box.addItem("العربية", "ar")
        self.lang_box.setCurrentIndex(1 if self.lang == "ar" else 0)
        self.lang_box.currentIndexChanged.connect(self._lang_changed)
        top.addWidget(self.note, 1)
        top.addWidget(self.lang_box)
        outer.addLayout(top)

        body = QHBoxLayout()
        left = QVBoxLayout()
        self.drop_label = QLabel()
        self.drop_label.setAlignment(Qt.AlignCenter)
        self.drop_label.setMinimumHeight(70)
        self.drop_label.setStyleSheet("border: 2px dashed #888; border-radius: 10px; padding: 8px;")
        self.list = QListWidget()
        self.list.setSelectionMode(QAbstractItemView.ExtendedSelection)
        row = QHBoxLayout()
        self.btn_add = QPushButton()
        self.btn_add.clicked.connect(self.pick_files)
        self.btn_remove = QPushButton("−")
        self.btn_remove.clicked.connect(self.remove_selected)
        self.btn_clear = QPushButton()
        self.btn_clear.clicked.connect(self.clear_files)
        for b in (self.btn_add, self.btn_remove, self.btn_clear):
            row.addWidget(b)
        self.count_label = QLabel()
        left.addWidget(self.drop_label)
        left.addWidget(self.list, 1)
        left.addLayout(row)
        left.addWidget(self.count_label)
        body.addLayout(left, 4)

        right = QVBoxLayout()
        self.preset_label, self.action_label = QLabel(), QLabel()
        self.preset_box, self.action_box = QComboBox(), QComboBox()
        self.preset_box.currentIndexChanged.connect(self._preset_changed)
        self.action_box.currentIndexChanged.connect(self._action_changed)
        right.addWidget(self.preset_label)
        right.addWidget(self.preset_box)
        right.addWidget(self.action_label)
        right.addWidget(self.action_box)

        self.opt_group = QGroupBox()
        form = QFormLayout(self.opt_group)
        self.quality = QSlider(Qt.Horizontal)
        self.quality.setRange(1, 100)
        self.quality.setValue(85)
        self.quality_val = QLabel("85")
        self.quality.valueChanged.connect(lambda v: (self.quality_val.setText(str(v)), self._schedule_estimate()))
        qrow = QHBoxLayout()
        qrow.addWidget(self.quality, 1)
        qrow.addWidget(self.quality_val)
        self.limit_check = QCheckBox()
        self.limit_value = QDoubleSpinBox()
        self.limit_value.setRange(0.05, 100000)
        self.limit_value.setValue(2.0)
        self.limit_value.setDecimals(2)
        self.limit_unit = QComboBox()
        self.limit_unit.addItems(["KB", "MB"])
        self.limit_unit.setCurrentIndex(1)
        lrow = QHBoxLayout()
        for w in (self.limit_check, self.limit_value, self.limit_unit):
            lrow.addWidget(w)
        self.strip_check = QCheckBox()
        self.max_side = QSpinBox()
        self.max_side.setRange(0, 20000)
        self.max_side.setSpecialValueText("—")
        self.max_side.setSuffix(" px")
        self.pages = QLineEdit()
        self.password = QLineEdit()
        self.password.setEchoMode(QLineEdit.Password)
        self.ocr_langs = QComboBox()
        self.ocr_langs.setEditable(True)
        self.ocr_langs.addItems(["ara+eng", "eng", "ara", "fas+eng", "fra+eng", "deu+eng", "tur+eng"])
        self.angle = QComboBox()
        self.angle.addItems(["90", "180", "270"])
        self.scale = QComboBox()
        self.scale.addItems(["2", "3", "4"])
        self.lbl = {k: QLabel() for k in ("quality", "limit", "max_side", "pages", "password", "ocr", "angle", "scale")}
        form.addRow(self.lbl["quality"], qrow)
        form.addRow(self.lbl["limit"], lrow)
        form.addRow(self.lbl["max_side"], self.max_side)
        form.addRow(self.strip_check)
        form.addRow(self.lbl["pages"], self.pages)
        form.addRow(self.lbl["password"], self.password)
        form.addRow(self.lbl["ocr"], self.ocr_langs)
        form.addRow(self.lbl["angle"], self.angle)
        form.addRow(self.lbl["scale"], self.scale)
        self.estimate_label = QLabel()
        form.addRow(self.estimate_label)
        for w in (self.limit_check,):
            w.toggled.connect(self._schedule_estimate)
        self.limit_value.valueChanged.connect(self._schedule_estimate)
        self.limit_unit.currentIndexChanged.connect(self._schedule_estimate)
        self.max_side.valueChanged.connect(self._schedule_estimate)
        self.strip_check.toggled.connect(self._schedule_estimate)
        right.addWidget(self.opt_group)

        orow = QHBoxLayout()
        self.out_label = QLabel()
        self.out_btn = QPushButton()
        self.out_btn.clicked.connect(self.pick_out_dir)
        self.out_reset = QPushButton("×")
        self.out_reset.setMaximumWidth(32)
        self.out_reset.clicked.connect(self.reset_out_dir)
        orow.addWidget(self.out_label, 1)
        orow.addWidget(self.out_btn)
        orow.addWidget(self.out_reset)
        right.addLayout(orow)

        brow = QHBoxLayout()
        self.btn_start = QPushButton()
        self.btn_start.setDefault(True)
        self.btn_start.clicked.connect(lambda *_: self.start())
        self.btn_cancel = QPushButton()
        self.btn_cancel.setEnabled(False)
        self.btn_cancel.clicked.connect(self.cancel)
        brow.addWidget(self.btn_start, 2)
        brow.addWidget(self.btn_cancel, 1)
        right.addLayout(brow)
        self.progress = QProgressBar()
        self.status = QLabel()
        right.addWidget(self.progress)
        right.addWidget(self.status)
        right.addStretch(1)
        body.addLayout(right, 5)
        outer.addLayout(body, 3)

        self.results = QTableWidget(0, 4)
        self.results.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.results.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.results.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        outer.addWidget(self.results, 2)
        rrow = QHBoxLayout()
        self.btn_show = QPushButton()
        self.btn_show.clicked.connect(lambda: self._show_in_folder(self.results))
        self.btn_undo = QPushButton()
        self.btn_undo.clicked.connect(self._undo_selected_result)
        self.btn_report = QPushButton()
        self.btn_report.clicked.connect(self._report_selected_result)
        for b in (self.btn_show, self.btn_undo, self.btn_report):
            rrow.addWidget(b)
        rrow.addStretch(1)
        outer.addLayout(rrow)
        return root

    def _build_history_tab(self) -> QWidget:
        w = QWidget()
        lay = QVBoxLayout(w)
        self.hist = QTableWidget(0, 5)
        self.hist.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.hist.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.hist.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        lay.addWidget(self.hist)
        row = QHBoxLayout()
        self.h_refresh, self.h_undo, self.h_report = QPushButton("⟳"), QPushButton(), QPushButton()
        self.h_refresh.clicked.connect(self.refresh_history)
        self.h_undo.clicked.connect(self._undo_selected_history)
        self.h_report.clicked.connect(self._report_selected_history)
        for b in (self.h_refresh, self.h_undo, self.h_report):
            row.addWidget(b)
        row.addStretch(1)
        lay.addLayout(row)
        return w

    def _build_components_tab(self) -> QWidget:
        w = QWidget()
        lay = QVBoxLayout(w)
        self.comp = QTableWidget(0, 4)
        self.comp.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.comp.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.comp.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        lay.addWidget(self.comp, 1)
        row = QHBoxLayout()
        self.c_install = QPushButton()
        self.c_install.clicked.connect(self._install_selected)
        self.c_refresh = QPushButton("⟳")
        self.c_refresh.clicked.connect(self.refresh_components)
        row.addWidget(self.c_install)
        row.addWidget(self.c_refresh)
        row.addStretch(1)
        lay.addLayout(row)
        lrow = QHBoxLayout()
        self.dl_label = QLabel()
        self.dl_box = QComboBox()
        for code, name in ocr.LANGUAGES.items():
            self.dl_box.addItem(f"{name} ({code})", code)
        self.dl_btn = QPushButton()
        self.dl_btn.clicked.connect(self._download_language)
        self.dl_status = QLabel()
        for x in (self.dl_label, self.dl_box, self.dl_btn, self.dl_status):
            lrow.addWidget(x)
        lay.addLayout(lrow)
        srow = QHBoxLayout()
        self.shell_on, self.shell_off = QPushButton(), QPushButton()
        self.shell_on.clicked.connect(lambda: self._shell(True))
        self.shell_off.clicked.connect(lambda: self._shell(False))
        self.shell_on.setEnabled(IS_WINDOWS)
        self.shell_off.setEnabled(IS_WINDOWS)
        srow.addWidget(self.shell_on)
        srow.addWidget(self.shell_off)
        srow.addStretch(1)
        lay.addLayout(srow)
        return w

    # ------------------------------------------------------------------------ translations
    def retranslate(self):
        t = lambda k, **kw: tr(self.lang, k, **kw)
        self.setWindowTitle(f"{t('app_title')} {__version__}")
        self.app_direction()
        for i, key in enumerate(("app_title", "history", "components")):
            self.tabs.setTabText(i, {"app_title": "⇄ " + t("app_title"), "history": t("history"),
                                     "components": t("components")}[key])
        self.note.setText(t("offline_note"))
        self.drop_label.setText(t("drop_here"))
        self.btn_add.setText(t("add_files"))
        self.btn_clear.setText(t("clear"))
        self.preset_label.setText(t("presets"))
        self.action_label.setText(t("what_to_do"))
        self.opt_group.setTitle(t("options"))
        self.lbl["quality"].setText(t("quality"))
        self.lbl["limit"].setText(t("target_size"))
        self.lbl["max_side"].setText(t("max_side"))
        self.lbl["pages"].setText(t("pages"))
        self.lbl["password"].setText(t("password"))
        self.lbl["ocr"].setText(t("ocr_langs"))
        self.lbl["angle"].setText(t("angle"))
        self.lbl["scale"].setText("×")
        self.limit_check.setText(t("target_size"))
        self.strip_check.setText(t("strip_meta"))
        self.out_btn.setText(t("choose"))
        self.btn_start.setText(t("start"))
        self.btn_cancel.setText(t("cancel"))
        self.btn_show.setText(t("open_folder"))
        self.btn_undo.setText(t("undo"))
        self.btn_report.setText(t("report"))
        self.h_undo.setText(t("undo"))
        self.h_report.setText(t("report"))
        self.c_install.setText(t("install_hint"))
        self.dl_label.setText(t("ocr_langs"))
        self.dl_btn.setText("⬇")
        self.shell_on.setText(t("register_shell"))
        self.shell_off.setText(t("unregister_shell"))
        self.results.setHorizontalHeaderLabels([t("col_file"), t("col_status"), t("col_result"), t("col_size")])
        self.hist.setHorizontalHeaderLabels(["#", t("col_date"), t("col_job"), t("col_files"), t("col_status")])
        self.comp.setHorizontalHeaderLabels([t("col_component"), t("col_status"), t("col_purpose"), t("col_where")])
        self._update_out_label()
        self._update_count()
        self.fill_presets()
        self.refresh_offers()

    def app_direction(self):
        QApplication.instance().setLayoutDirection(Qt.RightToLeft if self.lang == "ar" else Qt.LeftToRight)

    def _lang_changed(self):
        self.lang = self.lang_box.currentData()
        self.settings.setValue("lang", self.lang)
        self.retranslate()

    # ------------------------------------------------------------------------------- files
    def dragEnterEvent(self, e):
        if e.mimeData().hasUrls():
            e.acceptProposedAction()

    def dropEvent(self, e):
        self.add_paths([u.toLocalFile() for u in e.mimeData().urls() if u.isLocalFile()])

    def pick_files(self):
        names, _ = QFileDialog.getOpenFileNames(self, tr(self.lang, "add_files"))
        if names:
            self.add_paths(names)

    def add_paths(self, paths):
        known = set(self.files)
        for p in expand_paths(paths):
            if p not in known:
                self.files.append(p)
                known.add(p)
                self.list.addItem(str(p))
        self._files_changed()

    def queue_paths(self, paths):
        """Paths forwarded by other Explorer launches: wait a moment so a multi-selection arrives as one batch."""
        self.pending.extend(paths)
        self.add_timer.start(350)

    def _flush_pending(self):
        paths, self.pending = self.pending, []
        self.add_paths(paths)
        self.raise_()
        self.activateWindow()

    def remove_selected(self):
        rows = sorted({self.list.row(i) for i in self.list.selectedItems()}, reverse=True)
        for r in rows:
            self.list.takeItem(r)
            del self.files[r]
        self._files_changed()

    def clear_files(self):
        self.files.clear()
        self.list.clear()
        self._files_changed()

    def _files_changed(self):
        self._update_count()
        self.fill_presets()
        self.refresh_offers()

    def _update_count(self):
        self.count_label.setText(tr(self.lang, "files_selected", n=len(self.files)))

    # ---------------------------------------------------------------------- offers/presets
    def fill_presets(self):
        self.preset_box.blockSignals(True)
        self.preset_box.clear()
        self.preset_box.addItem("—", None)
        if self.files:
            for p in presets.for_paths(self.files):
                self.preset_box.addItem(p.name_ar if self.lang == "ar" else p.name, p.id)
        self.preset_box.blockSignals(False)

    def refresh_offers(self):
        self.offers = core.offers(self.files) if self.files else []
        self.action_box.blockSignals(True)
        self.action_box.clear()
        for o in self.offers:
            name = action_label(self.lang, o.action)
            text = f"{name} → {o.target.upper()}" if o.target else name
            if not o.available:
                text += f"   ({tr(self.lang, 'missing')}: {o.missing})"
            self.action_box.addItem(text, (o.action, o.target))
            if not o.available:
                self.action_box.model().item(self.action_box.count() - 1).setEnabled(False)
        self.action_box.blockSignals(False)
        if not self.offers and self.files:
            self.action_box.addItem(tr(self.lang, "no_actions"))
        self._action_changed()

    def current_step(self) -> Optional[core.Step]:
        pid = self.preset_box.currentData()
        if pid:
            return None
        data = self.action_box.currentData()
        return core.Step(data[0], data[1]) if data else None

    def _preset_changed(self):
        pid = self.preset_box.currentData()
        self.action_box.setEnabled(not pid)
        if pid:
            p = presets.find(pid)
            o = p.options
            if "quality" in o:
                self.quality.setValue(o["quality"])
            self.limit_check.setChecked("target_size" in o)
            if "target_size" in o:
                mb = o["target_size"] / 1024 ** 2
                self.limit_unit.setCurrentIndex(1 if mb >= 1 else 0)
                self.limit_value.setValue(mb if mb >= 1 else o["target_size"] / 1024)
            self.strip_check.setChecked(bool(o.get("strip_metadata", False)))
            self.max_side.setValue(o.get("max_side", 0) or 0)
            if "ocr_langs" in o:
                self.ocr_langs.setCurrentText(o["ocr_langs"])
        self._action_changed()

    def _action_changed(self):
        step = self.current_step()
        action = step.action if step else (None if not self.preset_box.currentData() else "preset")
        target = step.target if step else None
        img_out = action in ("convert", "compress") and (target in (None, "jpg", "webp", "avif", "png", "pdf"))
        self.quality.setEnabled(bool(img_out) or action == "preset")
        self.limit_check.setEnabled(action in ("convert", "compress", "preset"))
        self.max_side.setEnabled(action in ("convert", "compress", "preset"))
        self.strip_check.setEnabled(action in ("convert", "compress", "preset"))
        self.pages.setEnabled(action in ("pdf_extract", "pdf_rotate", "ocr", "convert", "preset"))
        self.password.setEnabled(action in ("pdf_extract", "pdf_rotate", "pdf_unlock", "extract", "pdf_split",
                                            "pdf_merge", "convert", "compress", "ocr", "preset"))
        self.ocr_langs.setEnabled(action in ("ocr", "preset"))
        self.angle.setEnabled(action == "pdf_rotate")
        self.scale.setEnabled(action == "upscale")
        self.btn_start.setEnabled(bool(self.files) and (bool(step) or bool(self.preset_box.currentData())))
        self._schedule_estimate()

    # ------------------------------------------------------------------------ size preview
    def _schedule_estimate(self, *_):
        self.estimate_label.setText("")
        self.est_timer.start(450)

    def _run_estimate(self):
        step = self.current_step()
        if len(self.files) != 1 or not step or kind_of(self.files[0]) != "image":
            return
        if step.action not in ("convert", "compress") or self.limit_check.isChecked():
            return
        fmt = step.target or (self.files[0].suffix.lower().lstrip(".") or "jpg")
        if fmt in ("jpeg",):
            fmt = "jpg"
        if fmt not in images.PIL_FORMAT:
            return
        self.est_token += 1
        QThreadPool.globalInstance().start(_Estimate(self.est_token, self.files[0], fmt, self.collect_options(),
                                                     self.est_signals))

    def _estimate_ready(self, token, size):
        if token == self.est_token and size:
            before = self.files[0].stat().st_size if self.files and self.files[0].exists() else 0
            self.estimate_label.setText(tr(self.lang, "preview_size", s=f"{human_size(size)} (now {human_size(before)})"))

    # ------------------------------------------------------------------------------ run
    def collect_options(self) -> Options:
        o = Options(quality=self.quality.value(), strip_metadata=self.strip_check.isChecked(),
                    max_side=self.max_side.value() or None, page_spec=self.pages.text().strip(),
                    password=self.password.text() or None, ocr_langs=self.ocr_langs.currentText().strip() or "ara+eng",
                    angle=int(self.angle.currentText()), scale=int(self.scale.currentText()), out_dir=self.out_dir)
        if self.limit_check.isChecked():
            mult = 1024 if self.limit_unit.currentText() == "KB" else 1024 ** 2
            o = o.but(target_size=int(self.limit_value.value() * mult))
        return o

    def start(self, allow_download: bool = False):
        if self.worker or not self.files:
            return
        pid = self.preset_box.currentData()
        opts = self.collect_options()
        if allow_download:
            opts = opts.but(allow_download=True)
        if pid:
            steps = presets.find(pid).steps
        else:
            step = self.current_step()
            if not step:
                return
            steps = [step]
        self.results.setRowCount(0)
        self.row_results.clear()
        self.progress.setValue(0)
        self.btn_start.setEnabled(False)
        self.btn_cancel.setEnabled(True)
        self.status.setText(tr(self.lang, "working"))
        self.worker = BatchWorker(self.files, steps, opts, self)
        self.worker.progress.connect(self._on_progress)
        self.worker.one_done.connect(self._on_one_done)
        self.worker.all_done.connect(self._on_all_done)
        self.worker.start()

    def cancel(self):
        if self.worker:
            self.worker.cancel.set()
            self.btn_cancel.setEnabled(False)

    def _on_progress(self, i, n, frac, msg):
        self.progress.setValue(int(((i + frac) / max(1, n)) * 100))
        self.status.setText(f"{i + 1}/{n}  {msg}")

    def _on_one_done(self, i, r):
        row = self.results.rowCount()
        self.results.insertRow(row)
        names = ", ".join(s.name for s in r.sources)
        if r.ok:
            outs = ", ".join(o.name for o in r.outputs)
            before = sum(s.stat().st_size for s in r.sources if s.exists())
            after = sum(o.stat().st_size for o in r.outputs if o.is_file())
            size = tr(self.lang, "size_before_after", a=human_size(before), b=human_size(after)) if after else ""
            status = tr(self.lang, "done") + (" ⚠" if r.warnings else "")
        else:
            outs, size, status = r.error or "", "", tr(self.lang, "failed")
        for c, text in enumerate((names, status, outs, size)):
            item = QTableWidgetItem(text)
            if c == 1 and r.warnings:
                item.setToolTip("\n".join(r.warnings))
            self.results.setItem(row, c, item)
        self.row_results[row] = r

    def _on_all_done(self, results):
        self.worker.wait()
        self.worker = None
        self.btn_cancel.setEnabled(False)
        self.progress.setValue(100 if results else 0)
        self.status.setText("")
        self._action_changed()
        missing = sorted({l for r in results for l in r.report.get("missing_languages", [])})
        if missing:
            answer = QMessageBox.question(self, tr(self.lang, "app_title"),
                                          tr(self.lang, "download_lang") + "\n" + ", ".join(missing))
            if answer == QMessageBox.Yes:
                self.start(allow_download=True)

    # -------------------------------------------------------------------- result actions
    def _selected(self, table) -> Optional[int]:
        rows = table.selectionModel().selectedRows()
        return rows[0].row() if rows else None

    def _show_in_folder(self, table):
        row = self._selected(table)
        r = self.row_results.get(row) if row is not None else None
        if r and r.outputs:
            reveal(r.outputs[0])

    def _undo_selected_result(self):
        row = self._selected(self.results)
        r = self.row_results.get(row) if row is not None else None
        if r and r.job_id:
            self._do_undo(r.job_id)

    def _report_selected_result(self):
        row = self._selected(self.results)
        r = self.row_results.get(row) if row is not None else None
        if r and r.job_id:
            self._show_report(r.job_id)

    def _do_undo(self, job_id: int):
        res = history.undo(job_id)
        lines = [f"✔ {Path(a).name}" for a, _ in res["removed"]] + [f"– {Path(a).name}: {why}" for a, why in res["skipped"]]
        QMessageBox.information(self, tr(self.lang, "undo"), "\n".join(lines) or "—")
        self.refresh_history()

    def _show_report(self, job_id: int):
        job = history.get(job_id)
        if job:
            QMessageBox.information(self, tr(self.lang, "report"), history.format_report(job["report"]))

    # ------------------------------------------------------------------------ out folder
    def pick_out_dir(self):
        d = QFileDialog.getExistingDirectory(self, tr(self.lang, "output_folder"))
        if d:
            self.out_dir = Path(d)
            self._update_out_label()

    def reset_out_dir(self):
        self.out_dir = None
        self._update_out_label()

    def _update_out_label(self):
        self.out_label.setText(f"{tr(self.lang, 'output_folder')}: " +
                               (str(self.out_dir) if self.out_dir else tr(self.lang, "next_to_original")))

    # ----------------------------------------------------------------------------- tabs
    def _tab_changed(self, i):
        if i == 1:
            self.refresh_history()
        elif i == 2:
            self.refresh_components()

    def refresh_history(self):
        rows = history.recent(200)
        self.hist.setRowCount(len(rows))
        self.hist_ids = []
        for r, j in enumerate(rows):
            state = "↩" if j["undone"] else ("✔" if j["ok"] else "✖")
            vals = [str(j["id"]), time.strftime("%Y-%m-%d %H:%M", time.localtime(j["ts"])), j["label"],
                    ", ".join(Path(s).name for s in j["sources"])[:80], state]
            for c, v in enumerate(vals):
                self.hist.setItem(r, c, QTableWidgetItem(v))
            self.hist_ids.append(j["id"])

    def _hist_id(self) -> Optional[int]:
        row = self._selected(self.hist)
        return self.hist_ids[row] if row is not None and row < len(self.hist_ids) else None

    def _undo_selected_history(self):
        jid = self._hist_id()
        if jid:
            self._do_undo(jid)

    def _report_selected_history(self):
        jid = self._hist_id()
        if jid:
            self._show_report(jid)

    def refresh_components(self):
        engines.forget()
        rows = engines.status(with_versions=False)
        self.comp_rows = rows
        self.comp.setRowCount(len(rows))
        for r, row in enumerate(rows):
            vals = [row["title"], tr(self.lang, "ok") if row["ok"] else tr(self.lang, "missing"),
                    row["purpose"], row["install"] if not row["ok"] else row["path"]]
            for c, v in enumerate(vals):
                self.comp.setItem(r, c, QTableWidgetItem(v))

    def _install_selected(self):
        row = self._selected(self.comp)
        if row is None:
            return
        info = self.comp_rows[row]
        if info["ok"] or not info["install"]:
            return
        if IS_WINDOWS and info["kind"] == "program":
            cmd = info["install"].split() + ["-e", "--accept-package-agreements", "--accept-source-agreements"]
            subprocess.Popen(cmd, creationflags=subprocess.CREATE_NEW_CONSOLE)
        else:
            QMessageBox.information(self, info["title"], info["install"])

    def _download_language(self):
        if self.dl_worker:
            return
        code = self.dl_box.currentData()
        self.dl_status.setText("…")
        self.dl_worker = DownloadWorker([code], parent=self)
        self.dl_worker.done.connect(self._download_done)
        self.dl_worker.start()

    def _download_done(self, ok, message):
        self.dl_worker.wait()
        self.dl_worker = None
        self.dl_status.setText("✔" if ok else message[:80])

    def _shell(self, on: bool):
        from .. import shell_integration as si
        try:
            si.register() if on else si.unregister()
            QMessageBox.information(self, tr(self.lang, "app_title"), "OK")
        except OSError as exc:
            QMessageBox.warning(self, tr(self.lang, "app_title"), str(exc))

    def closeEvent(self, e):
        if self.worker:
            self.worker.cancel.set()
            self.worker.wait(5000)
        e.accept()


def reveal(path: Path) -> None:
    path = Path(path)
    if IS_WINDOWS:
        subprocess.Popen(["explorer", "/select,", str(path)])
    else:
        QDesktopServices.openUrl(QUrl.fromLocalFile(str(path if path.is_dir() else path.parent)))


def _forward_to_running_instance(paths: list[str]) -> bool:
    sock = QLocalSocket()
    sock.connectToServer(SERVER_NAME)
    if not sock.waitForConnected(300):
        return False
    sock.write(json.dumps(paths).encode("utf-8"))
    sock.flush()
    sock.waitForBytesWritten(1000)
    sock.disconnectFromServer()
    return True


def main(argv=None) -> int:
    args = list(sys.argv[1:] if argv is None else argv)
    if IS_WINDOWS:
        try:
            import ctypes
            ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID("Satsuma.App")
        except Exception:
            pass
    app = QApplication.instance() or QApplication(["satsuma"])
    paths = [str(Path(a).resolve()) for a in args if not a.startswith("--")]
    if _forward_to_running_instance(paths):
        return 0
    server = QLocalServer()
    QLocalServer.removeServer(SERVER_NAME)
    server.listen(SERVER_NAME)
    win = MainWindow()

    def on_connection():
        conn = server.nextPendingConnection()
        if conn is None:
            return

        def read():
            try:
                win.queue_paths(json.loads(bytes(conn.readAll()).decode("utf-8")))
            except ValueError:
                pass
        conn.readyRead.connect(read)
        conn.waitForReadyRead(200)
        read()

    server.newConnection.connect(on_connection)
    win.show()
    if paths:
        win.add_paths(paths)
    return app.exec()


if __name__ == "__main__":
    sys.exit(main())
