"""Windows Explorer right-click entries (per-user, no administrator rights needed).

Windows 11 shows classic entries under "Show more options" (Shift+F10); Windows 10 shows them directly.
"""
from __future__ import annotations

import sys
from pathlib import Path
from typing import Optional

from .util import IS_WINDOWS

KEY_OPEN = r"Software\Classes\*\shell\Satsuma"
KEY_CLEAN = r"Software\Classes\*\shell\SatsumaClean"
KEY_FOLDER = r"Software\Classes\Directory\shell\Satsuma"


def launcher_command() -> str:
    """Command line that starts the GUI, for both the packaged .exe and a source checkout."""
    if getattr(sys, "frozen", False):
        return f'"{sys.executable}"'
    exe = Path(sys.executable)
    pyw = exe.with_name("pythonw.exe")
    return f'"{pyw if pyw.exists() else exe}" -m satsuma'


def _entries(cmd: str) -> list[tuple[str, str, str, Optional[str]]]:
    return [
        (KEY_OPEN, "Convert with Satsuma...", f'{cmd} --gui "%1"', None),
        (KEY_CLEAN, "Satsuma: remove hidden data", f'{cmd} clean --quiet --notify "%1"', None),
        (KEY_FOLDER, "Open folder in Satsuma", f'{cmd} --gui "%1"', None),
    ]


def register(winreg_module=None, command: Optional[str] = None) -> list[str]:
    """Create the entries. *winreg_module* can be injected for testing."""
    winreg = winreg_module
    if winreg is None:
        if not IS_WINDOWS:
            raise OSError("Explorer integration is only available on Windows")
        import winreg  # type: ignore
    cmd = command or launcher_command()
    created = []
    for key, label, line, _ in _entries(cmd):
        with winreg.CreateKey(winreg.HKEY_CURRENT_USER, key) as k:
            winreg.SetValueEx(k, "", 0, winreg.REG_SZ, label)
            winreg.SetValueEx(k, "MUIVerb", 0, winreg.REG_SZ, label)
            winreg.SetValueEx(k, "Icon", 0, winreg.REG_SZ, cmd.split('"')[1] if cmd.startswith('"') else cmd)
        with winreg.CreateKey(winreg.HKEY_CURRENT_USER, key + r"\command") as k:
            winreg.SetValueEx(k, "", 0, winreg.REG_SZ, line)
        created.append(key)
    return created


def unregister(winreg_module=None) -> list[str]:
    winreg = winreg_module
    if winreg is None:
        if not IS_WINDOWS:
            raise OSError("Explorer integration is only available on Windows")
        import winreg  # type: ignore
    removed = []
    for key in (KEY_OPEN, KEY_CLEAN, KEY_FOLDER):
        for sub in (key + r"\command", key):
            try:
                winreg.DeleteKey(winreg.HKEY_CURRENT_USER, sub)
                removed.append(sub)
            except FileNotFoundError:
                pass
    return removed
