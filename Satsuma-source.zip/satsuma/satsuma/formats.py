"""File-type knowledge: which extension belongs to which family."""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from .util import ext_of

IMAGE = {"jpg", "jpeg", "jpe", "jfif", "png", "webp", "bmp", "tif", "tiff", "gif", "ico", "avif",
         "tga", "psd", "ppm", "pgm", "pbm", "heic", "heif",
         "cr2", "cr3", "nef", "arw", "dng", "orf", "rw2", "raf", "pef", "srw"}
AUDIO = {"mp3", "wav", "flac", "ogg", "oga", "opus", "m4a", "aac", "wma", "aiff", "aif", "ac3", "amr", "mka"}
VIDEO = {"mp4", "mkv", "avi", "mov", "webm", "flv", "wmv", "mpg", "mpeg", "m4v", "3gp", "mts", "m2ts", "ogv"}
PDF = {"pdf"}
OFFICE = {"doc", "docx", "odt", "rtf", "xls", "xlsx", "ods", "csv", "ppt", "pptx", "odp", "txt", "html", "htm", "svg"}
MARKUP = {"md", "markdown", "rst", "tex", "epub"}
EBOOK = {"mobi", "azw", "azw3", "fb2", "epub"}
ARCHIVE = {"zip", "tar", "gz", "tgz", "bz2", "xz", "7z", "rar"}
FONT = {"ttf", "otf", "woff", "woff2"}
MODEL3D = {"stl", "obj", "ply", "glb", "gltf", "off"}

CANON = {"jpeg": "jpg", "jpe": "jpg", "jfif": "jpg", "tif": "tiff", "htm": "html", "aif": "aiff",
         "heif": "heic", "markdown": "md", "mpeg": "mpg"}


def canon(ext: str) -> str:
    ext = ext.lower().lstrip(".")
    return CANON.get(ext, ext)


def full_ext(path) -> str:
    name = Path(path).name.lower()
    for double in ("tar.gz", "tar.bz2", "tar.xz"):
        if name.endswith("." + double):
            return double
    return ext_of(path)


def kind_of(path) -> str:
    e = full_ext(path)
    if e in ("tar.gz", "tar.bz2", "tar.xz"):
        return "archive"
    for name, group in (("pdf", PDF), ("image", IMAGE), ("video", VIDEO), ("audio", AUDIO),
                        ("office", OFFICE), ("markup", MARKUP), ("ebook", EBOOK),
                        ("archive", ARCHIVE), ("font", FONT), ("model3d", MODEL3D)):
        if e in group:
            return name
    return "unknown"


@dataclass(frozen=True)
class Target:
    ext: str
    backend: str
    available: bool = True
    missing: str = ""
