"""English / Arabic interface strings."""
from __future__ import annotations

STRINGS = {
    "en": {
        "app_title": "Satsuma", "drop_here": "Drop files or folders here", "add_files": "Add files...",
        "clear": "Clear", "what_to_do": "What do you want to do?", "convert_to": "Convert to",
        "options": "Options", "quality": "Quality", "target_size": "Maximum size", "no_limit": "No limit",
        "strip_meta": "Remove hidden data (location, author, camera...)", "output_folder": "Save in",
        "next_to_original": "Next to the original", "choose": "Choose...", "start": "Start", "cancel": "Cancel",
        "presets": "Presets", "history": "History", "components": "Components", "undo": "Undo",
        "open_folder": "Show in folder", "report": "Privacy report", "done": "Done", "failed": "Failed",
        "waiting": "Waiting", "working": "Working...", "ocr_langs": "OCR languages", "pages": "Pages (e.g. 1-3,5)",
        "password": "Password", "download_lang": "Download language data (one-time, needs internet)?",
        "missing": "Not installed", "ok": "Installed", "install_hint": "Install", "language": "Language",
        "size_before_after": "{a} -> {b}", "files_selected": "{n} file(s) selected", "no_actions": "No common actions for these files",
        "offline_note": "Everything runs on this computer. Your files are never uploaded.",
        "register_shell": "Add to right-click menu", "unregister_shell": "Remove from right-click menu",
        "watch": "Watch a folder", "preview_size": "Estimated size: {s}", "angle": "Rotation (degrees)",
        "max_side": "Longest side", "col_file": "File", "col_status": "Status", "col_result": "Result",
        "col_size": "Size", "col_date": "Date", "col_job": "Job", "col_files": "Files",
        "col_component": "Component", "col_purpose": "Purpose", "col_where": "Location / install command",
    },
    "ar": {
        "app_title": "ساتسوما", "drop_here": "أفلت الملفات أو المجلدات هنا", "add_files": "إضافة ملفات...",
        "clear": "مسح", "what_to_do": "ماذا تريد أن تفعل؟", "convert_to": "تحويل إلى",
        "options": "خيارات", "quality": "الجودة", "target_size": "الحجم الأقصى", "no_limit": "بلا حد",
        "strip_meta": "إزالة البيانات الخفية (الموقع، المؤلف، الكاميرا...)", "output_folder": "الحفظ في",
        "next_to_original": "بجانب الملف الأصلي", "choose": "اختيار...", "start": "ابدأ", "cancel": "إلغاء",
        "presets": "إعدادات جاهزة", "history": "السجل", "components": "المكوّنات", "undo": "تراجع",
        "open_folder": "إظهار في المجلد", "report": "تقرير الخصوصية", "done": "تم", "failed": "فشل",
        "waiting": "في الانتظار", "working": "جارٍ العمل...", "ocr_langs": "لغات التعرّف على النص",
        "pages": "الصفحات (مثال: 1-3,5)", "password": "كلمة المرور",
        "download_lang": "تنزيل بيانات اللغة (مرة واحدة، يحتاج إنترنت)؟",
        "missing": "غير مثبّت", "ok": "مثبّت", "install_hint": "التثبيت", "language": "اللغة",
        "size_before_after": "{a} ← {b}", "files_selected": "تم اختيار {n} ملف", "no_actions": "لا توجد إجراءات مشتركة لهذه الملفات",
        "offline_note": "كل شيء يعمل على جهازك. ملفاتك لا تُرفع إلى أي مكان.",
        "register_shell": "إضافة إلى قائمة النقر بزر الفأرة الأيمن", "unregister_shell": "إزالة من قائمة النقر الأيمن",
        "watch": "مراقبة مجلد", "preview_size": "الحجم المتوقع: {s}", "angle": "التدوير (درجات)",
        "max_side": "أطول ضلع", "col_file": "الملف", "col_status": "الحالة", "col_result": "النتيجة",
        "col_size": "الحجم", "col_date": "التاريخ", "col_job": "العملية", "col_files": "الملفات",
        "col_component": "المكوّن", "col_purpose": "الاستخدام", "col_where": "المكان / أمر التثبيت",
    },
}

ACTION_LABELS = {
    "en": {"convert": "Convert", "compress": "Make smaller", "strip_metadata": "Remove hidden data",
           "ocr": "Recognise text (OCR)", "transcribe": "Speech to text", "remove_bg": "Remove background",
           "upscale": "Enlarge image", "extract": "Extract archive", "archive": "Create archive",
           "pdf_merge": "Merge PDFs", "images_to_pdf": "Images to one PDF", "pdf_split": "Split into pages",
           "pdf_extract": "Extract / reorder pages", "pdf_rotate": "Rotate pages", "pdf_unlock": "Remove PDF password"},
    "ar": {"convert": "تحويل", "compress": "تصغير الحجم", "strip_metadata": "إزالة البيانات الخفية",
           "ocr": "التعرّف على النص (OCR)", "transcribe": "تحويل الصوت إلى نص", "remove_bg": "إزالة الخلفية",
           "upscale": "تكبير الصورة", "extract": "فك الأرشيف", "archive": "إنشاء أرشيف",
           "pdf_merge": "دمج ملفات PDF", "images_to_pdf": "صور إلى PDF واحد", "pdf_split": "تقسيم إلى صفحات",
           "pdf_extract": "استخراج / ترتيب الصفحات", "pdf_rotate": "تدوير الصفحات", "pdf_unlock": "إزالة كلمة سر PDF"},
}


def tr(lang: str, key: str, **kw) -> str:
    table = STRINGS.get(lang) or STRINGS["en"]
    text = table.get(key) or STRINGS["en"].get(key) or key
    return text.format(**kw) if kw else text


def action_label(lang: str, action: str) -> str:
    return (ACTION_LABELS.get(lang) or ACTION_LABELS["en"]).get(action, action)
