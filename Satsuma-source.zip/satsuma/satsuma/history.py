"""Job history, privacy reports and safe undo (undo only ever removes files Satsuma created)."""
from __future__ import annotations

import json
import os
import shutil
import sqlite3
import subprocess
import time
from pathlib import Path
from typing import Optional

from .model import Result
from .util import IS_WINDOWS, data_dir, sha256_file, size_of

SCHEMA = """CREATE TABLE IF NOT EXISTS jobs(
  id INTEGER PRIMARY KEY AUTOINCREMENT, ts REAL NOT NULL, label TEXT, sources TEXT, outputs TEXT,
  ok INTEGER, error TEXT, bytes_in INTEGER, bytes_out INTEGER, report TEXT, undone INTEGER DEFAULT 0)"""


def _connect() -> sqlite3.Connection:
    con = sqlite3.connect(data_dir() / "history.db", timeout=15)
    con.row_factory = sqlite3.Row
    con.execute(SCHEMA)
    return con


def build_report(result: Result, label: str) -> dict:
    """Plain-language privacy report for one job."""
    def entry(p: Path, hashed: bool) -> dict:
        try:
            size = size_of(p)
            sha = sha256_file(p) if hashed and p.is_file() and size < 512 * 1024 ** 2 else None
        except OSError:
            size, sha = None, None
        return {"name": p.name, "path": str(p), "bytes": size, "sha256": sha}

    return {
        "what": label,
        "processed_locally": True,
        "network_used": False,
        "tools": list(result.engines),
        "metadata_removed": list(result.report.get("metadata_removed", [])),
        "warnings": list(result.warnings),
        "inputs": [entry(p, True) for p in result.sources],
        "outputs": [entry(p, True) for p in result.outputs],
        "original_files_untouched": True,
    }


def record(result: Result, label: str) -> int:
    report = build_report(result, label)
    outs = [{"path": str(p), "size": size_of(p) if p.exists() else 0, "dir": p.is_dir()} for p in result.outputs]
    bytes_in = sum(i["bytes"] or 0 for i in report["inputs"])
    bytes_out = sum(o["bytes"] or 0 for o in report["outputs"])
    with _connect() as con:
        cur = con.execute(
            "INSERT INTO jobs(ts,label,sources,outputs,ok,error,bytes_in,bytes_out,report) VALUES(?,?,?,?,?,?,?,?,?)",
            (time.time(), label, json.dumps([str(s) for s in result.sources]), json.dumps(outs),
             int(result.ok), result.error, bytes_in, bytes_out, json.dumps(report)))
        return int(cur.lastrowid)


def recent(limit: int = 100) -> list[dict]:
    with _connect() as con:
        rows = con.execute("SELECT * FROM jobs ORDER BY id DESC LIMIT ?", (limit,)).fetchall()
    return [_row(r) for r in rows]


def get(job_id: int) -> Optional[dict]:
    with _connect() as con:
        r = con.execute("SELECT * FROM jobs WHERE id=?", (job_id,)).fetchone()
    return _row(r) if r else None


def _row(r: sqlite3.Row) -> dict:
    d = dict(r)
    for k in ("sources", "outputs", "report"):
        d[k] = json.loads(d[k]) if d.get(k) else []
    return d


def clear() -> None:
    with _connect() as con:
        con.execute("DELETE FROM jobs")


def move_to_trash(path: Path, job_id: int = 0) -> str:
    """Recycle Bin on Windows; ~/.local/share/satsuma/trash elsewhere. Returns where it went."""
    path = Path(path)
    if IS_WINDOWS:
        fn = "DeleteDirectory" if path.is_dir() else "DeleteFile"
        script = ("Add-Type -AssemblyName Microsoft.VisualBasic; "
                  f"[Microsoft.VisualBasic.FileIO.FileSystem]::{fn}($env:SATSUMA_TRASH,"
                  "'OnlyErrorDialogs','SendToRecycleBin')")
        proc = subprocess.run(["powershell", "-NoProfile", "-NonInteractive", "-Command", script],
                              env=dict(os.environ, SATSUMA_TRASH=str(path)), capture_output=True,
                              creationflags=subprocess.CREATE_NO_WINDOW)
        if proc.returncode == 0 and not path.exists():
            return "Recycle Bin"
    dest_dir = data_dir() / "trash" / str(job_id or int(time.time()))
    dest_dir.mkdir(parents=True, exist_ok=True)
    target = dest_dir / path.name
    n = 0
    while target.exists():
        n += 1
        target = dest_dir / f"{path.stem} ({n}){path.suffix}"
    shutil.move(str(path), str(target))
    return str(target)


def undo(job_id: int) -> dict:
    """Remove what a job created. Never touches originals; skips files changed since."""
    job = get(job_id)
    if not job:
        return {"removed": [], "skipped": [], "error": "Unknown job"}
    removed, skipped = [], []
    for o in job["outputs"]:
        p = Path(o["path"])
        if not p.exists():
            skipped.append((str(p), "already gone"))
        elif size_of(p) != o["size"]:
            skipped.append((str(p), "was modified after conversion - left in place"))
        else:
            try:
                removed.append((str(p), move_to_trash(p, job_id)))
            except OSError as exc:
                skipped.append((str(p), f"could not remove: {exc}"))
    with _connect() as con:
        con.execute("UPDATE jobs SET undone=1 WHERE id=?", (job_id,))
    return {"removed": removed, "skipped": skipped, "error": None}


def format_report(report: dict) -> str:
    lines = [f"Privacy report - {report.get('what', '')}", "=" * 40,
             "Processed on this computer only: yes", "Network used: no",
             "Original files modified: no"]
    if report.get("tools"):
        lines.append("Tools used: " + ", ".join(report["tools"]))
    removed = report.get("metadata_removed") or []
    lines.append("Hidden data removed: " + ("; ".join(removed) if removed else "none requested / none found"))
    for w in report.get("warnings", []):
        lines.append("Note: " + w)
    for label, key in (("Input", "inputs"), ("Output", "outputs")):
        for e in report.get(key, []):
            sha = f"  sha256 {e['sha256'][:16]}..." if e.get("sha256") else ""
            lines.append(f"{label}: {e['name']}  ({e['bytes']} bytes){sha}")
    return "\n".join(lines)
