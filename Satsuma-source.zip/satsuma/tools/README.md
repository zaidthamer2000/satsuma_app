# tools/

Optional: drop portable copies of external programs here and Satsuma will use them first,
without installing anything (it searches this folder, then PATH, then the usual install folders):

- `ffmpeg.exe`, `ffprobe.exe`        - audio / video
- `tesseract.exe` (+ its DLLs)        - OCR
- `pandoc.exe`                        - Markdown / EPUB / HTML
- `7z.exe`                            - RAR and other archives
- `realesrgan-ncnn-vulkan.exe`        - AI image enlargement (optional)

Subfolders are searched too (e.g. `tools/ffmpeg/bin/ffmpeg.exe`).
